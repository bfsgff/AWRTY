/* ===== بوابة تسجيل الدخول: المنطق ===== */
const G = window.__tgGate, root = G.root, host = G.host;
const $ = id => root.getElementById(id);
const gate = $('gate');

/* ====== ضع إعدادات مشروعك من Firebase هنا ====== */
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_APP_ID"
};
const configured = !firebaseConfig.apiKey.startsWith("YOUR_");

let fb = null, auth = null;
if (configured) {
  try {
    const appMod  = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js");
    const authMod = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js");
    fb = authMod;
    const _app = appMod.initializeApp(firebaseConfig);
    auth = authMod.getAuth(_app);
    window.__tgFB = { app: _app };
  } catch (e) { console.warn('Firebase failed to load', e); }
}
if (!window.__tgFB) window.__tgFB = false;
window.dispatchEvent(new Event('tg-fb-ready'));
const useFirebase = !!auth;

/* ----- المجسم ----- */
(function () {
  const N = 72;
  const tri = [[0,-0.95],[0.82,0.475],[-0.82,0.475]];
  const sq  = [[-0.75,-0.75],[0.75,-0.75],[0.75,0.75],[-0.75,0.75]];
  const cross = (a, b) => a[0]*b[1] - a[1]*b[0];
  function ray(verts, ang) {
    const d = [Math.cos(ang), Math.sin(ang)];
    let best = Infinity;
    for (let i = 0; i < verts.length; i++) {
      const p = verts[i], q = verts[(i+1) % verts.length];
      const e = [q[0]-p[0], q[1]-p[1]];
      const den = cross(d, e);
      if (Math.abs(den) < 1e-9) continue;
      const t = cross(p, e) / den, s = cross(p, d) / den;
      if (t > 0 && s >= -1e-9 && s <= 1 + 1e-9) best = Math.min(best, t);
    }
    return best;
  }
  function shape(fn) {
    const pts = [];
    for (let i = 0; i < N; i++) {
      const a = (i / N) * Math.PI * 2 - Math.PI / 2, r = fn(a);
      pts.push((50 + 50*r*Math.cos(a)).toFixed(2) + '% ' + (50 + 50*r*Math.sin(a)).toFixed(2) + '%');
    }
    return 'polygon(' + pts.join(',') + ')';
  }
  const square = shape(a => ray(sq, a)), triangle = shape(a => ray(tri, a)), circle = shape(() => 0.85);
  const el = $('bgShape');
  el.style.clipPath = square;
  if (el.animate) el.animate([
    { clipPath: square,   backgroundColor: '#ffffff', offset: 0 },
    { clipPath: square,   backgroundColor: '#ffffff', offset: 0.15 },
    { clipPath: triangle, backgroundColor: '#22d3ee', offset: 0.33 },
    { clipPath: triangle, backgroundColor: '#22d3ee', offset: 0.48 },
    { clipPath: circle,   backgroundColor: '#a78bfa', offset: 0.66 },
    { clipPath: circle,   backgroundColor: '#a78bfa', offset: 0.81 },
    { clipPath: square,   backgroundColor: '#ffffff', offset: 1 }
  ], { duration: 12000, iterations: Infinity, easing: 'ease-in-out' });
})();

/* ----- أدوات ----- */
async function sha(text, algo) {
  try {
    const buf = await crypto.subtle.digest(algo || 'SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  } catch (e) { return ''; }
}
function loadable(url) {
  return new Promise(res => { const i = new Image(); i.onload = () => res(true); i.onerror = () => res(false); i.src = url; });
}
function say(text, ok) { $('msg').textContent = text; $('msg').className = 'msg anim' + (ok ? ' ok' : ''); }

function showGate() {
  host.style.display = 'block';
  document.documentElement.style.overflow = 'hidden';
  gate.classList.remove('loading');
}
function hideGate() {
  host.style.display = 'none';
  document.documentElement.style.overflow = '';
}

/* الدخول للموقع: صورة الحساب تُؤخذ من الإيميل نفسه (Gravatar) أو من صورة الحساب إن وُجدت */
async function enter(email, uid, displayName, photoURL) {
  let photo = photoURL || '';
  if (!photo) {
    const h = await sha(email.trim().toLowerCase());
    if (h) {
      const url = 'https://gravatar.com/avatar/' + h + '?s=128&d=404';
      if (await loadable(url)) photo = url;
    }
  }
  const p = { id: 'email:' + uid, name: displayName || email.split('@')[0], provider: 'البريد الإلكتروني', photo, email };
  try { const ed = (JSON.parse(localStorage.getItem('toryakProfileEdits') || '{}'))[p.id]; if (ed) { if (ed.name) p.name = ed.name; if (ed.photo) p.photo = ed.photo; } } catch (_) {}
  try {
    let old = {}; try { old = JSON.parse(localStorage.getItem('toryakAuth') || '{}'); } catch (_) {}
    localStorage.setItem('toryakProfile', JSON.stringify(p));
    localStorage.setItem('toryakAuth', JSON.stringify({ loggedIn: true, role: old.role === 'owner' ? 'owner' : 'user', provider: p.provider, at: new Date().toISOString() }));
  } catch (_) {}
  try { window.tgRenderAccount && window.tgRenderAccount(); } catch (_) {}
  try { window.updatePublishAccessUI && window.updatePublishAccessUI(); } catch (_) {}
  hideGate();
  $('password').value = ''; $('confirm').value = '';
  window.__tgEntered = true; window.dispatchEvent(new Event('tg-entered'));
}

/* ----- واجهة النموذج ----- */
let mode = 'login';
function setMode(m) {
  mode = m;
  const signup = m === 'signup';
  $('title').textContent = signup ? 'إنشاء حساب' : 'تسجيل دخول';
  $('submitBtn').textContent = signup ? 'إنشاء الحساب' : 'دخول';
  $('confirmBox').classList.toggle('hidden', !signup);
  $('switchText').innerHTML = signup
    ? 'عندك حساب؟ <a id="switchLink">تسجيل دخول</a>'
    : 'ما عندك حساب؟ <a id="switchLink">إنشاء حساب</a>';
  $('switchLink').onclick = () => setMode(signup ? 'login' : 'signup');
  say('');
}
function errText(e) {
  const m = {
    'auth/email-already-in-use': 'هذا البريد مسجّل مسبقًا',
    'auth/invalid-email': 'البريد الإلكتروني غير صحيح',
    'auth/weak-password': 'كلمة المرور ضعيفة (6 أحرف على الأقل)',
    'auth/invalid-credential': 'البريد أو كلمة المرور غير صحيحة',
    'auth/user-not-found': 'البريد أو كلمة المرور غير صحيحة',
    'auth/wrong-password': 'البريد أو كلمة المرور غير صحيحة',
    'auth/too-many-requests': 'محاولات كثيرة، حاول بعد قليل',
    'auth/network-request-failed': 'تأكد من اتصال الإنترنت'
  };
  return m[e.code] || 'حدث خطأ: ' + (e.code || e.message);
}

/* حسابات محلية احتياطية: تعمل فقط إذا لم تُضبط إعدادات Firebase بعد */
const lUsers = () => { try { return JSON.parse(localStorage.getItem('gateUsers') || '{}'); } catch (e) { return {}; } };

let busy = false;
async function submit() {
  if (busy) return;
  const email = $('email').value.trim();
  const pass = $('password').value;
  if (!email || !pass) return say('أدخل البريد وكلمة المرور');
  busy = true; $('submitBtn').style.opacity = .6;
  try {
    if (useFirebase) {
      if (mode === 'signup') {
        if (pass !== $('confirm').value) return say('كلمتا المرور غير متطابقتين');
        const cred = await fb.createUserWithEmailAndPassword(auth, email, pass);
        await fb.sendEmailVerification(cred.user);
        await fb.signOut(auth);
        setMode('login');
        say('أرسلنا رسالة تأكيد إلى بريدك، افتحها واضغط على الرابط ثم سجّل دخولك', true);
        $('password').value = ''; $('confirm').value = '';
      } else {
        const cred = await fb.signInWithEmailAndPassword(auth, email, pass);
        if (!cred.user.emailVerified) {
          try { await fb.sendEmailVerification(cred.user); } catch (e) {}
          await fb.signOut(auth);
          say('بريدك غير مؤكد بعد. أرسلنا لك رسالة تأكيد جديدة، افتح الرابط ثم ادخل');
        }
        /* عند النجاح يتولى onAuthStateChanged إدخالك للموقع */
      }
    } else {
      if (!/^\S+@\S+\.\S+$/.test(email)) return say('البريد الإلكتروني غير صحيح');
      const users = lUsers(), key = email.toLowerCase(), h = await sha(pass) || btoa(unescape(encodeURIComponent(pass)));
      if (mode === 'signup') {
        if (pass.length < 6) return say('كلمة المرور 6 أحرف على الأقل');
        if (pass !== $('confirm').value) return say('كلمتا المرور غير متطابقتين');
        if (users[key]) return say('هذا البريد مسجّل مسبقًا');
        users[key] = h; localStorage.setItem('gateUsers', JSON.stringify(users));
        setMode('login'); say('تم إنشاء الحساب، سجّل دخولك الآن', true);
        $('password').value = ''; $('confirm').value = '';
      } else {
        if (!users[key] || users[key] !== h) return say('البريد أو كلمة المرور غير صحيحة');
        localStorage.setItem('gateSession', key);
        await enter(key, key, '', '');
      }
    }
  } catch (e) {
    say(errText(e));
  } finally {
    busy = false; $('submitBtn').style.opacity = 1;
  }
}
$('submitBtn').onclick = submit;
['email', 'password', 'confirm'].forEach(id => $(id).addEventListener('keydown', e => { if (e.key === 'Enter') submit(); }));

/* تسجيل الخروج من قائمة الحساب في الموقع */
window.addEventListener('toryak-logout', async () => {
  try { localStorage.removeItem('gateSession'); } catch (_) {}
  try { if (auth) await fb.signOut(auth); } catch (_) {}
  setMode('login');
  showGate();
});

/* ----- البداية ----- */
setMode('login');
if (useFirebase) {
  fb.onAuthStateChanged(auth, u => {
    if (u && u.emailVerified) enter(u.email, u.uid, u.displayName, u.photoURL);
    else showGate();
  });
} else {
  const s = localStorage.getItem('gateSession');
  let sp = null, sa = null;
  try { sp = JSON.parse(localStorage.getItem('toryakProfile') || 'null'); sa = JSON.parse(localStorage.getItem('toryakAuth') || 'null'); } catch (_) {}
  if (s && lUsers()[s]) enter(s, s, '', '');
  else if (sp && sp.id && sa && sa.loggedIn) { try { window.tgRenderAccount && window.tgRenderAccount(); } catch (_) {} hideGate(); }
  else showGate();
}
