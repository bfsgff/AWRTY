(function(){
  'use strict';
  const $=id=>document.getElementById(id),PK='toryakProfile';
  const getP=()=>{try{return JSON.parse(localStorage.getItem(PK)||'null');}catch(_){return null;}};
  const loginBtn=$('openAuthModalBtn'),card=document.querySelector('#authModal .auth-card');
  if(!loginBtn||!card) return;
  let provider='',photo='';
  const av=document.createElement('button');av.id='tgAvatar';av.type='button';av.hidden=true;av.title='حسابي';
  loginBtn.parentNode.insertBefore(av,loginBtn);
  const menu=document.createElement('div');menu.id='tgAcctMenu';menu.hidden=true;
  menu.innerHTML='<div class="tg-acct-name" id="tgAcctName"></div><button data-a="acct">الحساب</button><button data-a="game">استوديو جيم</button><button data-a="3d">مشروع 3D</button><button data-a="out">تسجيل خروج</button>';
  document.body.appendChild(menu);
  const panel=document.createElement('div');panel.id='tgWorks';
  panel.innerHTML='<div class="tg-works-card"><button class="tg-detail-close" id="tgWorksClose" type="button" style="left:12px;top:12px">✕</button><h2 id="tgWorksTitle" style="margin:0 0 16px"></h2><div id="tgWorksList"></div></div>';
  document.body.appendChild(panel);
  function render(){
    const p=getP();loginBtn.hidden=!!p;av.hidden=!p;
    if(!p){menu.hidden=true;return;}
    try{window.__joined(p.id);}catch(_){}
    av.replaceChildren();
    if(p.photo){const i=document.createElement('img');i.referrerPolicy='no-referrer';i.src=p.photo;i.alt='';av.appendChild(i);}else av.textContent=(p.name||'?').trim().charAt(0).toUpperCase();
    $('tgAcctName').textContent=p.name+' • '+p.provider;
  }
  /* تسجيل الدخول الحقيقي عبر Google / Microsoft (OAuth). ضع الـ Client ID هنا: */
  const OAUTH={google:'',microsoft:''};
  const redirect=location.origin+location.pathname;
  const msg=document.createElement('p');msg.style.cssText='margin:10px 0 0;font-size:.82rem;line-height:1.7;color:#ffd27a';msg.hidden=true;card.appendChild(msg);
  document.addEventListener('click',e=>{
    const b=e.target.closest&&e.target.closest('#googleLoginBtn,#microsoftLoginBtn');if(!b) return;
    e.preventDefault();e.stopImmediatePropagation();
    const g=b.id==='googleLoginBtn',id=g?OAUTH.google:OAUTH.microsoft,nm=g?'Google':'Microsoft';
    if(!/^https?:$/.test(location.protocol)||!id){showLocal(nm);return;}
    const q=new URLSearchParams(g?{client_id:id,redirect_uri:redirect,response_type:'token',scope:'openid profile email',state:'google',prompt:'select_account'}
      :{client_id:id,redirect_uri:redirect,response_type:'token',scope:'User.Read',response_mode:'fragment',state:'microsoft',prompt:'select_account'});
    location.href=(g?'https://accounts.google.com/o/oauth2/v2/auth?':'https://login.microsoftonline.com/common/oauth2/v2.0/authorize?')+q;
  },true);
  const lform=document.createElement('div');lform.hidden=true;lform.style.cssText='display:flex;flex-direction:column;gap:10px;margin-top:12px';
  lform.innerHTML='<input id="tgAuthName" type="text" maxlength="30" placeholder="اسم الحساب" style="padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#fff;font:inherit"><button type="button" class="auth-btn" id="tgAuthGo">متابعة</button>';
  card.appendChild(lform);
  function showLocal(nm){
    provider=nm;msg.textContent='الدخول الحقيقي عبر '+nm+' يحتاج ضبط Client ID وفتح الموقع من رابط http/https، وهذا غير جاهز بعد. سجّل دخولك الآن بحساب محلي على هذا المتصفح (يسمح لك بالنشر والحذف):';
    msg.hidden=false;lform.hidden=false;$('tgAuthName').focus();
  }
  $('tgAuthGo').addEventListener('click',()=>{
    const name=$('tgAuthName').value.trim();if(!name){$('tgAuthName').focus();return;}
    const p={id:'local:'+name.toLowerCase(),name,provider:provider||'محلي',photo};
    try{
      let old={};try{old=JSON.parse(localStorage.getItem('toryakAuth')||'{}');}catch(_){}
      localStorage.setItem(PK,JSON.stringify(p));
      localStorage.setItem('toryakAuth',JSON.stringify({loggedIn:true,role:old.role==='owner'?'owner':'user',provider:p.provider,at:new Date().toISOString()}));
    }catch(_){}
    lform.hidden=true;msg.hidden=true;$('tgAuthName').value='';photo='';
    $('authModal').classList.remove('active');render();
  });
  async function finishLogin(){
    const h=new URLSearchParams(location.hash.slice(1)),tok=h.get('access_token'),st=h.get('state');
    if(!tok||(st!=='google'&&st!=='microsoft')) return;
    history.replaceState(null,'',location.pathname+location.search);
    try{
      let p;
      if(st==='google'){
        const j=await (await fetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:'Bearer '+tok}})).json();
        p={id:'google:'+j.sub,name:j.name||j.email,provider:'Google',photo:j.picture||'',email:j.email||''};
      }else{
        const hd={Authorization:'Bearer '+tok},j=await (await fetch('https://graph.microsoft.com/v1.0/me',{headers:hd})).json();let photo='';
        try{const r=await fetch('https://graph.microsoft.com/v1.0/me/photo/$value',{headers:hd});
          if(r.ok){const bl=await r.blob();photo=await new Promise(res=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.readAsDataURL(bl);});}}catch(_){}
        p={id:'microsoft:'+j.id,name:j.displayName||j.userPrincipalName,provider:'Microsoft',photo,email:j.mail||j.userPrincipalName||''};
      }
      let old={};try{old=JSON.parse(localStorage.getItem('toryakAuth')||'{}');}catch(_){}
      localStorage.setItem(PK,JSON.stringify(p));
      localStorage.setItem('toryakAuth',JSON.stringify({loggedIn:true,role:old.role==='owner'?'owner':'user',provider:p.provider,at:new Date().toISOString()}));
      $('authModal').classList.remove('active');render();
    }catch(err){console.warn('OAuth',err);}
  }
  av.addEventListener('click',e=>{
    e.stopPropagation();const r=av.getBoundingClientRect();
    menu.style.top=(r.bottom+6)+'px';menu.style.left=Math.max(8,Math.min(innerWidth-196,r.left))+'px';menu.hidden=!menu.hidden;
  });
  document.addEventListener('click',e=>{if(!menu.contains(e.target)&&e.target!==av) menu.hidden=true;});

  /* ===== إدارة الحساب: الاسم والصورة ===== */
  const ap=document.createElement('div');ap.id='tgAcct';
  ap.innerHTML='<div class="tg-works-card" style="width:min(420px,100%)"><button class="tg-detail-close" id="tgAcctClose" type="button" style="left:12px;top:12px">✕</button><h2 style="margin:0 0 16px">الحساب</h2><div class="tg-acct-photo"><div id="tgAcctPrev"></div><label class="tg-works-btn" for="tgAcctFile">اختيار صورة</label><input type="file" id="tgAcctFile" accept="image/*" hidden></div><label class="tg-acct-lbl" for="tgAcctName2">اسم الحساب</label><input id="tgAcctName2" type="text" maxlength="30" class="tg-acct-inp"><button type="button" class="tg-works-btn" id="tgAcctSave" style="margin-top:14px;width:100%">حفظ</button></div>';
  document.body.appendChild(ap);
  let pendPhoto=null;
  function paintPrev(name,ph){const pv=$('tgAcctPrev');pv.replaceChildren();if(ph){const i=document.createElement('img');i.src=ph;i.alt='';pv.appendChild(i);}else pv.textContent=(name||'?').trim().charAt(0).toUpperCase();}
  function openAcct(){const p=getP();if(!p) return;pendPhoto=null;$('tgAcctName2').value=p.name||'';paintPrev(p.name,p.photo);ap.classList.add('active');}
  function squarePhoto(f){return new Promise(res=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const S=200,c=document.createElement('canvas');c.width=c.height=S;const m=Math.min(im.width,im.height),sx=(im.width-m)/2,sy=(im.height-m)/2;c.getContext('2d').drawImage(im,sx,sy,m,m,0,0,S,S);res(c.toDataURL('image/jpeg',.88));};im.onerror=()=>res('');im.src=r.result;};r.onerror=()=>res('');r.readAsDataURL(f);});}
  $('tgAcctFile').addEventListener('change',async e=>{const f=e.target.files&&e.target.files[0];if(!f) return;const d=await squarePhoto(f);if(d){pendPhoto=d;paintPrev($('tgAcctName2').value,d);}e.target.value='';});
  $('tgAcctName2').addEventListener('input',()=>{const p=getP();paintPrev($('tgAcctName2').value,pendPhoto!==null?pendPhoto:(p&&p.photo));});
  $('tgAcctSave').addEventListener('click',()=>{
    const p=getP();if(!p) return;const nm=$('tgAcctName2').value.trim();if(!nm){$('tgAcctName2').focus();return;}
    p.name=nm;if(pendPhoto!==null) p.photo=pendPhoto;
    try{
      localStorage.setItem(PK,JSON.stringify(p));
      let ed={};try{ed=JSON.parse(localStorage.getItem('toryakProfileEdits')||'{}');}catch(_){}
      ed[p.id]={name:p.name,photo:p.photo||''};localStorage.setItem('toryakProfileEdits',JSON.stringify(ed));
    }catch(_){}
    render();ap.classList.remove('active');
  });
  $('tgAcctClose').addEventListener('click',()=>ap.classList.remove('active'));
  ap.addEventListener('click',e=>{if(e.target===ap) ap.classList.remove('active');});
  async function remove3d(id){
    try{window.tgCloudDeleteModel&&window.tgCloudDeleteModel(id);}catch(_){}
    try{const l=JSON.parse(localStorage.getItem('toryakProjects')||'[]');localStorage.setItem('toryakProjects',JSON.stringify(l.filter(i=>i.id!==id)));}catch(_){}
    await new Promise(res=>{try{const q=indexedDB.open('toryakProjectDB',1);q.onsuccess=()=>{const db=q.result,t=db.transaction('projects','readwrite');t.objectStore('projects').delete(id);t.oncomplete=t.onerror=t.onabort=()=>{db.close();res();};};q.onerror=()=>res();}catch(_){res();}});
    document.querySelectorAll('.published-model-card[data-published-id="'+id+'"]').forEach(c=>c.remove());
  }
  window.tgShowDev=async function(rec,nm){
    let ov=document.getElementById('tgDevOv');if(ov) ov.remove();
    const urls=[];const closeOv=()=>{if(!ov||ov.dataset.closing) return;ov.dataset.closing='1';ov.classList.remove('active');const o=ov;setTimeout(()=>{o.remove();urls.forEach(u=>URL.revokeObjectURL(u));},320);};
    ov=document.createElement('div');ov.id='tgDevOv';
    ov.innerHTML='<button class="tg-detail-close" type="button" style="left:14px;top:14px;position:fixed">✕</button><div class="tg-dev-stage"><div class="tg-dev-col" data-s="a"></div><div class="tg-dev-center"><div class="tg-dev-big"></div><div class="tg-dev-nm"></div></div><div class="tg-dev-col" data-s="b"></div></div>';
    document.body.appendChild(ov);
    const big=ov.querySelector('.tg-dev-big'),center=ov.querySelector('.tg-dev-center');
    ov.querySelector('.tg-dev-nm').textContent=nm||'';
    const LBL={ar:['يستخدم الموقع منذ','بدأ في'],en:['Using the site since','Started'],fr:['Utilise le site depuis','Débuté le'],zh:['使用本站始于','开始于'],ur:['سائٹ استعمال کرنے کی تاریخ','آغاز']}[window.__tgLang()]||['يستخدم الموقع منذ','بدأ في'];
    const fmt=d=>{try{return new Date(d).toLocaleDateString(window.__tgLoc(),{year:'numeric',month:'long',day:'numeric'});}catch(_){return '';}};
    const tip=document.createElement('div');tip.className='tg-dev-tip';center.appendChild(tip);
    const mine=getP()&&getP().id===rec.owner,me=getP()||{},ph=mine?(me.photo||''):(rec.ownerPhoto||'');
    if(ph){const i=document.createElement('img');i.src=ph;i.alt='';big.appendChild(i);}else big.textContent=(nm||'?').trim().charAt(0).toUpperCase();
    let items=[];try{items=(await window.tgApi.list()).filter(r=>r.owner===rec.owner);}catch(_){}
    let p3=[];try{p3=JSON.parse(localStorage.getItem('toryakProjects')||'[]').filter(x=>mine?(!x.owner||x.owner===rec.owner):x.owner===rec.owner);}catch(_){}
    const cards=[];
    let joined=mine?window.__joined(rec.owner):(rec.ownerJoined||0);
    if(!joined){const ds=items.map(g=>+g.createdAt||0).filter(Boolean);joined=ds.length?Math.min(...ds):(rec.createdAt||Date.now());}
    tip.innerHTML='<b></b><span></span>';tip.firstChild.textContent=nm||'';tip.lastChild.textContent=LBL[0]+': '+fmt(joined);
    big.addEventListener('mouseenter',()=>tip.classList.add('on'));big.addEventListener('mouseleave',()=>tip.classList.remove('on'));
    items.forEach(g=>cards.push({name:g.name,blob:g.coverBlob,id:g.id,tag:'game',date:g.createdAt,open:()=>{closeOv();window.tgApi.open(g);}}));
    p3.forEach(x=>cards.push({name:x.name,blob:null,id:x.id,tag:'3D',date:x.createdAt,open:()=>{closeOv();try{window.tgApi.closeDetail();window.tgApi.hideGames();}catch(_){}try{window.openPublishedProjectDetail&&window.openPublishedProjectDetail(x.id);}catch(_){}}}));
    const cols=ov.querySelectorAll('.tg-dev-col');
    if(!cards.length){const e=document.createElement('p');e.className='tg-empty';e.textContent='لا يوجد حاليا';cols[1].appendChild(e);}
    cards.forEach((c,i)=>{
      const d=document.createElement('div');d.className='tg-dev-card';
      const im=document.createElement('div');im.className='tg-dev-card-img';
      if(c.blob){const u=URL.createObjectURL(c.blob);urls.push(u);const t=document.createElement('img');t.src=u;t.alt='';im.appendChild(t);}else im.textContent=c.tag;
      const n=document.createElement('b');n.textContent=c.name;
      const dt=document.createElement('small');dt.className='tg-dev-card-date';dt.textContent=c.date?LBL[1]+': '+fmt(c.date):'';
      d.append(im,n,dt);if(c.open){d.style.cursor='pointer';d.addEventListener('click',c.open);}
      if(mine){const x=document.createElement('button');x.type='button';x.className='tg-works-btn tg-dev-del';x.textContent='حذف';
        x.addEventListener('click',async e=>{e.stopPropagation();if(!(await window.__askConfirm('حذف «'+c.name+'» نهائيًا؟'))) return;
          if(c.tag==='3D') await remove3d(c.id); else await window.tgApi.remove(c.id);
          d.remove();});
        d.appendChild(x);}
      cols[i%2].appendChild(d);
    });
        ov.addEventListener('click',e=>{if(e.target===ov||e.target.classList.contains('tg-dev-stage')) closeOv();});
    ov.querySelector('.tg-detail-close').addEventListener('click',closeOv);
    requestAnimationFrame(()=>ov.classList.add('active'));
  };
  async function openWorks(kind){
    const p=getP();if(!p) return;
    $('tgWorksTitle').textContent=kind==='game'?'أعمالي في استوديو جيم':'مشاريعي ثلاثية الأبعاد';
    const list=$('tgWorksList');list.replaceChildren();panel.classList.add('active');
    let items=[];
    if(kind==='game'&&window.tgApi){try{items=(await window.tgApi.list()).filter(r=>!r.owner||r.owner===p.id);}catch(_){}}
    if(kind==='3d'){try{items=JSON.parse(localStorage.getItem('toryakProjects')||'[]').filter(x=>!x.owner||x.owner===p.id);}catch(_){}}
    if(!items.length){const e=document.createElement('p');e.className='tg-empty';e.textContent='لا يوجد حاليا';list.appendChild(e);return;}
    items.forEach((r,i)=>{
      const row=document.createElement('div');row.className='tg-work-row';row.style.animationDelay=(i*90)+'ms';
      const n=document.createElement('span');n.textContent=r.name;
      const x=document.createElement('button');x.className='tg-works-btn';x.type='button';x.textContent='حذف';
      x.addEventListener('click',async()=>{
        if(!(await window.__askConfirm('حذف «'+r.name+'» نهائيًا؟'))) return;
        if(kind==='game') await window.tgApi.remove(r.id);
        else{
          try{const all=JSON.parse(localStorage.getItem('toryakProjects')||'[]');localStorage.setItem('toryakProjects',JSON.stringify(all.filter(i=>i.id!==r.id)));}catch(_){}
          try{window.tgCloudDeleteModel&&window.tgCloudDeleteModel(r.id);}catch(_){}
          await new Promise(res=>{try{const q=indexedDB.open('toryakProjectDB',1);q.onsuccess=()=>{const db=q.result,t=db.transaction('projects','readwrite');t.objectStore('projects').delete(r.id);t.oncomplete=t.onerror=()=>{db.close();res();};};q.onerror=()=>res();}catch(_){res();}});
          document.querySelectorAll('.published-model-card[data-published-id="'+r.id+'"]').forEach(c=>c.remove());
        }
        openWorks(kind);
      });
      if(kind==='game'){
        const d=document.createElement('button');d.className='tg-works-btn';d.type='button';d.textContent='تطوير / إضافة';
        d.addEventListener('click',()=>{panel.classList.remove('active');window.tgApi.develop(r);});
        row.append(n,d,x);
      }else row.append(n,x);
      list.appendChild(row);
    });
  }
  menu.addEventListener('click',e=>{
    const a=e.target.dataset&&e.target.dataset.a;if(!a) return;menu.hidden=true;
    if(a==='out'){try{localStorage.removeItem(PK);localStorage.setItem('toryakAuth',JSON.stringify({loggedIn:false,role:'guest'}));}catch(_){}render();window.dispatchEvent(new Event('toryak-logout'));}
    else if(a==='acct') openAcct();
    else openWorks(a);
  });
  $('tgWorksClose').addEventListener('click',()=>panel.classList.remove('active'));
  panel.addEventListener('click',e=>{if(e.target===panel) panel.classList.remove('active');});
  window.tgRenderAccount=render;
  finishLogin();render();
})();
