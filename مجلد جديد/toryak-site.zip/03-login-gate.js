(function(){
  var host=document.getElementById('loginGate');
  var root=host.attachShadow({mode:'open'});
  root.innerHTML=`<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif}
.gate{position:fixed;inset:0;display:flex;direction:ltr;background:#000;color:#fff;overflow:hidden}
.left{flex:1;display:flex;justify-content:center;align-items:center;direction:rtl;padding:20px;transition:opacity .4s}
.gate.loading .left{opacity:0;pointer-events:none}
.panel{width:340px;max-width:100%;text-align:center}
.panel h2{margin-bottom:12px;font-size:28px}
.right{flex:1;display:flex;justify-content:center;align-items:center;position:relative}
.shape-wrap{width:min(36vw,70vh,460px);height:min(36vw,70vh,460px);filter:drop-shadow(0 0 40px rgba(255,255,255,.25))}
#bgShape{width:100%;height:100%;background:#fff;animation:spin 14s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.input-box{margin-bottom:18px}
.input-box input{width:100%;padding:13px;border:1px solid rgba(255,255,255,.4);border-radius:10px;outline:none;background:rgba(255,255,255,.08);color:#fff;font-size:15px;text-align:center;transition:.25s}
.input-box input::placeholder{color:rgba(255,255,255,.65)}
.input-box input:focus{border-color:#fff;background:rgba(255,255,255,.14);transform:scale(1.02)}
button{width:100%;padding:13px;border:none;border-radius:10px;background:#fff;color:#111;cursor:pointer;font-weight:bold;font-size:15px;transition:.25s}
button:hover{transform:translateY(-2px);opacity:.92}
.switch{margin-top:18px;font-size:14px}
a{color:#fff;cursor:pointer}
.msg{min-height:22px;margin-bottom:10px;font-size:14px;color:#fca5a5}
.msg.ok{color:#86efac}
.hidden{display:none}
.anim{opacity:0;animation:rise .7s cubic-bezier(.2,.8,.2,1) forwards;animation-delay:var(--d,0s)}
@keyframes rise{from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:none}}
@media (max-width:800px){
  .gate{flex-direction:column}
  .right{order:-1;flex:0 0 28vh}
  .shape-wrap{width:min(50vw,24vh);height:min(50vw,24vh)}
  .left{align-items:flex-start;padding-top:10px}
}
</style>
<div class="gate loading" id="gate">
  <div class="left">
    <div class="panel" id="authBox">
      <h2 class="anim" id="title" style="--d:.1s">تسجيل دخول</h2>
      <div class="msg anim" id="msg" style="--d:.15s"></div>
      <div class="input-box anim" style="--d:.25s"><input type="email" id="email" placeholder="البريد الإلكتروني" autocomplete="email"></div>
      <div class="input-box anim" style="--d:.4s"><input type="password" id="password" placeholder="كلمة المرور" autocomplete="current-password"></div>
      <div class="input-box hidden anim" id="confirmBox" style="--d:.1s"><input type="password" id="confirm" placeholder="تأكيد كلمة المرور" autocomplete="new-password"></div>
      <button class="anim" id="submitBtn" style="--d:.55s">دخول</button>
      <p class="switch anim" id="switchText" style="--d:.7s">ما عندك حساب؟ <a id="switchLink">إنشاء حساب</a></p>
    </div>
  </div>
  <div class="right"><div class="shape-wrap"><div id="bgShape"></div></div></div>
</div>`;
  window.__tgGate={root:root,host:host};
  document.documentElement.style.overflow='hidden';
  setTimeout(function(){var g=root.getElementById('gate');if(g)g.classList.remove('loading');},8000);
})();
