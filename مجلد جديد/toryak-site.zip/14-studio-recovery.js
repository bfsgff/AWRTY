(function(){
  function status(message){var el=document.getElementById('aiStatus');if(el)el.textContent=message;}
  window.addEventListener('error',function(e){
    if(document.getElementById('studioView')?.classList.contains('active')){
      console.error('TORYAK studio runtime error:',e.error||e.message);
      if(typeof THREE==='undefined') status('تعذر تشغيل محرك 3D: تحقق من اتصال الإنترنت ثم أعد فتح الملف.');
    }
  });
  window.addEventListener('unhandledrejection',function(e){
    if(document.getElementById('studioView')?.classList.contains('active')){
      console.error('TORYAK studio async error:',e.reason);
    }
  });
  document.addEventListener('click',function(e){
    var btn=e.target.closest('.studio-model-quick-btn');
    if(!btn)return;
    e.preventDefault();e.stopPropagation();
    var query=btn.getAttribute('data-model-query')||btn.textContent.trim();
    if(typeof window.loadProductModel==='function'){
      try{window.loadProductModel(query);}catch(err){console.error(err);status('حدث خطأ عند تحميل النموذج: '+(err.message||err));}
    } else {
      status(typeof THREE==='undefined'?'محرك 3D لم يُحمّل. افتح الملف مع اتصال بالإنترنت.':'تعذر تهيئة أدوات الاستوديو؛ أعد تحميل الصفحة وجرب مرة أخرى.');
    }
  },true);
  window.addEventListener('resize',function(){
    var c=document.getElementById('canvas-container');
    if(c&&window.renderer&&typeof window.renderStudioFrame==='function')window.renderStudioFrame();
  });
})();
