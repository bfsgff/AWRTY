(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const home=$('mainHomePage'),searchInput=$('mainSearchBox'),searchButton=$('mainSearchBtn'),
    searchHint=document.querySelector('#mainHomePage .search-hint'),arc=$('mainSearchArc'),
    moon=$('toggleMoonBubbles'),moonWrapper=$('moonWrapper'),bubbles=$('sideBubbles'),
    modeBubble=$('openCarModal'),studioBubble=$('openStudioBtn'),gamesPage=$('toryakGamesPage'),
    gamesGrid=$('toryakGamesGrid'),gamesEmpty=$('toryakGamesEmpty'),gameStudio=$('toryakGameStudio'),gamePlayer=$('toryakGamePlayer');
  if(!home||!searchInput||!searchButton||!modeBubble||!studioBubble||!gamesPage||!gameStudio) return;

  let editRec=null,searchMode='models',gameStudioReturnToGames=false,activePlayerObjectUrl=null,arcRaf=0;
  const DB_NAME='TORYAK_WR_PUBLISHED_GAMES',DB_VERSION=2;
  const PH_MODELS='ما الشيء الذي تريد البحث عنه؟ مثل: نماذج ثلاثية الأبعاد أو ساعة أو بطة...';

  /* ---------- الخط الأبيض: يدور حول الشريط بنفس دورة القمر (زاوية التدرج تدور، لا العنصر) ---------- */
  function playSearchArc(){
    if(!arc) return;
    cancelAnimationFrame(arcRaf);
    const D=900,t0=performance.now();
    (function step(now){
      const t=Math.min(1,(now-t0)/D),e=t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
      arc.style.setProperty('--a',(e*360)+'deg');
      arc.style.opacity=t<.08?String(t/.08):t>.88?String(Math.max(0,(1-t)/.12)):'1';
      if(t<1) arcRaf=requestAnimationFrame(step);
      else{arc.style.opacity='0';arc.style.setProperty('--a','0deg');}
    })(t0);
  }

  /* ---------- تغيير الأسماء بأنيميشن (تلاشي ثم ظهور) ---------- */
  function updateModeLabels(mode){
    const g=mode==='games';
    const mt=modeBubble.querySelector('.bubble-text'),st=studioBubble.querySelector('.bubble-text');
    if(mt) mt.textContent=g?'مجسمات ثلاثية الأبعاد':'الألعاب';
    if(st) st.textContent=g?'استوديو جيم':'إنشاء مشروع (3D)';
    searchInput.placeholder=g?'ابحث عن أي لعبة تريدها...':PH_MODELS;
    searchInput.setAttribute('aria-label',g?'ابحث عن أي لعبة تريدها':'ما الشيء الذي تريد البحث عنه؟');
    if(searchHint) searchHint.textContent=g?'اكتب اسم اللعبة واضغط بحث للانتقال إلى صفحة الألعاب':'اكتب اسم النموذج واضغط Enter للانتقال إلى صفحة النماذج ثلاثية الأبعاد';
    const sg=$('mainSearchSuggestions');
    if(sg){sg.classList.remove('active');searchInput.setAttribute('aria-expanded','false');}
  }
  function switchSearchMode(){
    const next=searchMode==='models'?'games':'models';
    searchMode=next;
    if(bubbles) bubbles.classList.remove('active');
    playSearchArc();
    const els=[modeBubble.querySelector('.bubble-text'),studioBubble.querySelector('.bubble-text'),searchHint].filter(Boolean);
    searchInput.classList.add('ph-out');
    els.forEach(el=>el.classList.add('tg-swap','out'));
    setTimeout(()=>{
      if(searchMode===next) updateModeLabels(next);
      searchInput.classList.remove('ph-out');
      els.forEach(el=>el.classList.remove('out'));
    },450);
  }
  if(moon) moon.addEventListener('click',()=>setTimeout(()=>moonWrapper&&moonWrapper.classList.remove('animate'),850));

  /* التقاط النقرات على مستوى document حتى لا يفتح استوديو 3D في وضع الألعاب */
  document.addEventListener('click',function(e){
    const t=e.target;if(!t||!t.closest) return;
    if(t.closest('#openCarModal')){e.preventDefault();e.stopImmediatePropagation();switchSearchMode();return;}
    if(searchMode==='games'&&t.closest('#openStudioBtn')){e.preventDefault();e.stopImmediatePropagation();openGameStudio();}
  },true);

  function normalize(v){
    return String(v||'').toLowerCase().normalize('NFKC').replace(/[\u064B-\u065F\u0670]/g,'').replace(/ـ/g,'')
      .replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[^\p{L}\p{N}]+/gu,' ').replace(/\s+/g,' ').trim();
  }
  function filterGames(q){
    let n=0;
    gamesGrid.querySelectorAll('.toryak-game-card').forEach(c=>{
      const h=normalize((c.getAttribute('data-game-search')||'')+' '+c.textContent);
      const show=!q||h.includes(q)||q.split(' ').some(w=>w.length>1&&h.includes(w));
      c.style.display=show?'':'none';if(show) n++;
    });
    gamesEmpty.classList.toggle('active',n===0);
  }
  function showGamesPage(query){
    gamesPage.classList.add('active');gamesPage.setAttribute('aria-hidden','false');
    $('toryakGamesMenu')?.classList.remove('active');$('toryakGamesDots')?.setAttribute('aria-expanded','false');
    filterGames(normalize(query));loadPublishedGames();try{window.tgSyncGames&&window.tgSyncGames();}catch(_){}
  }
  async function renderGameSuggestions(){
    const panel=$('mainSearchSuggestions');if(!panel) return;
    const raw=searchInput.value.trim();panel.replaceChildren();
    if(!raw){panel.classList.remove('active');searchInput.setAttribute('aria-expanded','false');return;}
    const q=normalize(raw);let games=[BUILTIN.xo,BUILTIN.puzzle];
    try{games=games.concat(await getAllGameRecords());}catch(_){}
    if(searchMode!=='games'||searchInput.value.trim()!==raw) return;
    panel.replaceChildren();
    const generic=/^(لعبه|العاب|الالعاب|game|games)$/.test(q);
    const res=games.map(g=>{const n=normalize(g.name),h=normalize(g.name+' '+(g.description||''));
      const sc=generic?0:n.startsWith(q)?0:n.includes(q)?1:h.includes(q)?2:q.split(' ').some(w=>w.length>1&&h.includes(w))?3:null;
      return {g,sc};}).filter(x=>x.sc!==null).sort((a,b)=>a.sc-b.sc);
    const add=(title,sub,all)=>{
      const b=document.createElement('button');b.type='button';b.className='main-search-suggestion'+(all?' main-search-all':'');b.setAttribute('role','option');
      const t=document.createElement('span');t.className='main-search-suggestion-title';t.textContent=title;b.appendChild(t);
      if(sub){const u=document.createElement('span');u.className='main-search-suggestion-subtitle';u.textContent=sub;b.appendChild(u);}
      b.addEventListener('click',()=>{const v=all?'':title;searchInput.value=v;panel.classList.remove('active');searchInput.setAttribute('aria-expanded','false');showGamesPage(v);});
      panel.appendChild(b);
    };
    if(generic) add('عرض جميع الألعاب ('+games.length+')','افتح صفحة الألعاب الموجودة في الموقع',true);
    if(res.length) res.slice(0,generic?5:7).forEach(x=>add(x.g.name,x.g.description||'لعبة في الموقع'));
    else{const e=document.createElement('div');e.className='main-search-suggestion-empty';e.textContent='غير موجود في الموقع: «'+raw+'»';panel.appendChild(e);}
    panel.classList.add('active');searchInput.setAttribute('aria-expanded','true');
    try{window.tgAugmentSearch&&window.tgAugmentSearch(raw,'game');}catch(_){}
  }
  searchInput.addEventListener('input',function(e){
    if(searchMode==='games'){e.stopImmediatePropagation();renderGameSuggestions();}
  },true);
  function submitSelectedSearch(e){
    if(searchMode!=='games') return;
    if(e){e.preventDefault();e.stopImmediatePropagation();}
    $('mainSearchSuggestions')?.classList.remove('active');searchInput.setAttribute('aria-expanded','false');
    showGamesPage(searchInput.value.trim());
  }
  searchButton.addEventListener('click',submitSelectedSearch,true);
  searchInput.addEventListener('keydown',e=>{if(searchMode==='games'&&e.key==='Enter') submitSelectedSearch(e);},true);

  /* ---------- استوديو جيم ---------- */
  function openGameStudio(){
    gameStudioReturnToGames=gamesPage.classList.contains('active');
    gameStudio.classList.add('active');gameStudio.setAttribute('aria-hidden','false');
    if(bubbles) bubbles.classList.remove('active');
    $('toryakGamesMenu')?.classList.remove('active');
    updateLivePreview();
  }
  function closeGameStudio(){
    gameStudio.classList.remove('active');gameStudio.setAttribute('aria-hidden','true');
    if(editRec){exitDev();$('toryakGameForm').reset();resetCover();resetVideo();updateLivePreview();}
    if(gameStudioReturnToGames){gamesPage.classList.add('active');gamesPage.setAttribute('aria-hidden','false');}
  }
  $('toryakGamesDots').addEventListener('click',function(){
    const open=$('toryakGamesMenu').classList.toggle('active');this.setAttribute('aria-expanded',String(open));
  });
  $('toryakOpenGameStudio').addEventListener('click',openGameStudio);
  document.addEventListener('pointerdown',e=>{
    const w=document.querySelector('.toryak-games-menu-wrap');
    if(w&&!w.contains(e.target)){$('toryakGamesMenu').classList.remove('active');$('toryakGamesDots').setAttribute('aria-expanded','false');}
  });
  $('toryakGameStudioBack').addEventListener('click',closeGameStudio);
  $('toryakOpenXoGame').addEventListener('click',()=>$('openXoModal')?.click());
  $('toryakOpenPuzzleGame').addEventListener('click',()=>$('openPuzzleModal')?.click());

  /* ---------- التخزين ---------- */
  function openDatabase(){
    return new Promise((res,rej)=>{
      if(!('indexedDB' in window)){rej(new Error('التخزين غير متاح'));return;}
      const r=indexedDB.open(DB_NAME,DB_VERSION);
      r.onupgradeneeded=()=>{
        const db=r.result;
        if(!db.objectStoreNames.contains('games')) db.createObjectStore('games',{keyPath:'id'});
        if(!db.objectStoreNames.contains('comments')) db.createObjectStore('comments',{keyPath:'id'}).createIndex('gameId','gameId');
      };
      r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error||new Error('تعذر فتح التخزين'));
    });
  }
  async function dbTx(store,mode,fn){
    const db=await openDatabase();
    return new Promise((res,rej)=>{
      const t=db.transaction(store,mode),r=fn(t.objectStore(store));
      t.oncomplete=()=>{db.close();res(r&&r.result);};
      t.onerror=t.onabort=()=>{const e=t.error;db.close();rej(e||new Error('db'));};
    });
  }
  const saveGameRecord=r=>dbTx('games','readwrite',s=>s.put(r));
  const getAllGameRecords=()=>dbTx('games','readonly',s=>s.getAll()).then(r=>r||[]);
  const saveComment=async c=>{await dbTx('comments','readwrite',s=>s.put(c));if(window.tgCloud){try{if(await tgCloud.ok()) await tgCloud.putComment(c);}catch(e){console.warn('cloud comment',e);}}};
  const getComments=async id=>{
    const loc=(await dbTx('comments','readonly',s=>s.index('gameId').getAll(id)))||[];
    if(window.tgCloud){try{const rem=await tgCloud.getComments(id);if(rem){const m=new Map(loc.map(c=>[c.id,c]));rem.forEach(c=>m.set(c.id,c));return Array.from(m.values());}}catch(e){console.warn(e);}}
    return loc;
  };

  $('tgGamesBack').addEventListener('click',()=>{gamesPage.classList.remove('active');gamesPage.setAttribute('aria-hidden','true');});
  /* ---------- بطاقات الألعاب (صورة شفافة + فيديو عند التمرير) ---------- */
  function setCoverNode(host,blob,urls){
    host.replaceChildren();
    if(!blob){const s=document.createElement('span');s.textContent='لا توجد صورة للعبة';host.appendChild(s);return;}
    const u=URL.createObjectURL(blob);urls.push(u);
    const n=blob.type&&blob.type.startsWith('video/')?document.createElement('video'):document.createElement('img');
    n.src=u;
    if(n.tagName==='VIDEO'){n.autoplay=true;n.loop=true;n.muted=true;n.playsInline=true;}
    n.alt='صورة اللعبة';host.appendChild(n);
  }
  async function tgEnsure(rec,roles){
    if(!rec||!rec.cloud||!window.tgCloud) return;let ch=false;
    for(const r of roles){
      if(r==='extras'){const m=rec.cloud.extras||[];if(m.length&&(!rec.extras||rec.extras.length<m.length||rec.extras.some(x=>!x))){rec.extras=await Promise.all(m.map((x,i)=>(rec.extras&&rec.extras[i])||tgCloud.getBlob(x)));ch=true;}}
      else{const k=r==='file'?'sourceBlob':r+'Blob';if(!rec[k]&&rec.cloud[r]){rec[k]=await tgCloud.getBlob(rec.cloud[r]);ch=true;}}
    }
    if(ch){try{await saveGameRecord(rec);}catch(_){}}
  }
  const dlLabel=r=>(r.sourceBlob||(r.cloud&&r.cloud.file))?'⬇ تنزيل اللعبة':r.url?'فتح رابط اللعبة':'تنزيل اللعبة';
  async function downloadGame(r){
    if(!r.sourceBlob&&r.cloud&&r.cloud.file){try{await tgEnsure(r,['file']);}catch(e){alert('تعذر تنزيل ملف اللعبة، حاول مرة أخرى.');return;}}
    if(r.sourceBlob){const u=URL.createObjectURL(r.sourceBlob),a=document.createElement('a');a.href=u;a.download=r.fileName||r.name||'game';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),4000);}
    else if(r.url) window.open(r.url,'_blank','noopener');
  }
  function addPublishedCard(rec){
    const old=gamesGrid.querySelector('[data-published-game="'+CSS.escape(rec.id)+'"]');
    if(old){(old._urls||[]).forEach(u=>URL.revokeObjectURL(u));old.remove();}
    const card=document.createElement('article');
    card.className='toryak-game-card';card.dataset.publishedGame=rec.id;card._urls=[];
    card.setAttribute('data-game-search',normalize(rec.name+' '+(rec.description||'')));
    const cover=document.createElement('div');cover.className='toryak-game-card-preview';
    setCoverNode(cover,rec.coverBlob,card._urls);
    if(rec.videoBlob||(rec.cloud&&rec.cloud.video)){
      const v=document.createElement('video');v.className='tg-hover-video';v.loop=true;v.playsInline=true;v.preload='metadata';
      cover.appendChild(v);
      const prep=async()=>{if(v.src) return;await tgEnsure(rec,['video']);if(rec.videoBlob){const u=URL.createObjectURL(rec.videoBlob);card._urls.push(u);v.src=u;}};
      if(rec.videoBlob) prep();
      card.addEventListener('mouseenter',async()=>{
        try{await prep();}catch(_){return;}
        v.currentTime=0;v.muted=false;
        const p=v.play();if(p&&p.catch) p.catch(()=>{v.muted=true;v.play().catch(()=>{});});
      });
      card.addEventListener('mouseleave',()=>v.pause());
    }
    const info=document.createElement('div');info.className='toryak-game-card-info';
    const h=document.createElement('h2');h.textContent=rec.name;
    const p=document.createElement('p');p.textContent=rec.description||'لعبة منشورة على الموقع';
    const b=document.createElement('button');b.type='button';b.className='toryak-game-open';b.textContent=dlLabel(rec);
    b.addEventListener('click',()=>downloadGame(rec));
    info.append(h,p,b);card.append(cover,info);
    card.addEventListener('click',e=>{if(!e.target.closest('button')) openDetail(rec);});
    gamesGrid.appendChild(card);
  }
  async function loadPublishedGames(){
    try{(await getAllGameRecords()).forEach(addPublishedCard);filterGames(normalize(searchInput.value));}
    catch(e){console.warn('TORYAK games storage:',e);}
  }

  /* ---------- نافذة تفاصيل اللعبة ---------- */
  const BUILTIN={
    xo:{id:'builtin-xo',builtin:true,cardId:'toryakXoGameCard',name:'لعبة إكس - أو',description:'تحدَّ الذكاء الاصطناعي في لعبة إكس - أو الكلاسيكية.',
      specs:[['النوع','لعبة ذكاء'],['اللاعبون','لاعب واحد ضد الذكاء الاصطناعي'],['التحكم','النقر على المربعات'],['التشغيل','مباشرة داخل المتصفح']],play:()=>$('openXoModal')?.click()},
    puzzle:{id:'builtin-puzzle',builtin:true,cardId:'toryakPuzzleGameCard',name:'الألغاز السريعة',description:'أجب عن الأسئلة وانتقل إلى اللغز التالي.',
      specs:[['النوع','ألغاز وأسئلة'],['اللاعبون','لاعب واحد'],['التحكم','اختيار الإجابة'],['التشغيل','مباشرة داخل المتصفح']],play:()=>$('openPuzzleModal')?.click()}
  };
  $('toryakXoGameCard').addEventListener('click',e=>{if(!e.target.closest('button')) openDetail(BUILTIN.xo);});
  $('toryakPuzzleGameCard').addEventListener('click',e=>{if(!e.target.closest('button')) openDetail(BUILTIN.puzzle);});

  const detail=$('tgDetail');let detailUrls=[],currentRec=null;
  const mkUrl=b=>{const u=URL.createObjectURL(b);detailUrls.push(u);return u;};
  const fmtSize=n=>n>1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB';
  function setTab(name){
    detail.querySelectorAll('.tg-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));
    $('tgTabSpecs').hidden=name!=='specs';$('tgTabComments').hidden=name!=='comments';
    if(name==='comments') renderComments();
  }
  function specRows(r){
    if(r.builtin) return r.specs;
    const isHtml=/\.html?$/i.test(r.fileName||'')||(r.sourceBlob&&r.sourceBlob.type==='text/html');
    const rows=[['النوع',r.url?'رابط ويب (يعمل داخل الصفحة)':isHtml?'ملف HTML (يعمل داخل الصفحة)':r.fileName?'ملف قابل للتنزيل':'—']];
    if(r.fileName) rows.push(['اسم الملف',r.fileName]);
    if(r.sourceBlob) rows.push(['الحجم',fmtSize(r.sourceBlob.size)]);else if(r.cloud&&r.cloud.file) rows.push(['الحجم',fmtSize(r.cloud.file.size)]);
    if(r.url) rows.push(['الرابط',r.url]);
    if(r.videoBlob||(r.cloud&&r.cloud.video)) rows.push(['فيديو',' مرفق']);
    rows.push(['تاريخ النشر',new Date(r.createdAt||Date.now()).toLocaleDateString(window.__tgLoc())]);
    return rows;
  }
  async function openDetail(rec){
    if(rec&&rec.cloud&&!rec.builtin){try{await tgEnsure(rec,['video','extras']);}catch(e){console.warn(e);}}
    openDetailNow(rec);
    if(rec&&!rec.builtin) pullStats(rec.id).then(()=>{if(currentRec&&currentRec.id===rec.id) renderStats();});
  }
  function openDetailNow(rec){
    currentRec=rec;detailUrls.forEach(u=>URL.revokeObjectURL(u));detailUrls=[];
    $('tgDetailTitle').textContent=rec.name;
    const m=$('tgDetailMedia');m.replaceChildren();m.classList.toggle('tg-art',!!rec.builtin);
    if(rec.builtin){const s=document.querySelector('#'+rec.cardId+' .toryak-game-card-preview > *');if(s) m.appendChild(s.cloneNode(true));}
    else if(rec.videoBlob){
      const v=document.createElement('video');v.src=mkUrl(rec.videoBlob);v.controls=true;v.loop=true;v.playsInline=true;
      if(rec.coverBlob&&!rec.coverBlob.type.startsWith('video/')) v.poster=mkUrl(rec.coverBlob);
      m.appendChild(v);const p=v.play();if(p&&p.catch) p.catch(()=>{});
    }else if(rec.coverBlob){
      const n=rec.coverBlob.type.startsWith('video/')?document.createElement('video'):document.createElement('img');
      n.src=mkUrl(rec.coverBlob);if(n.tagName==='VIDEO'){n.controls=true;n.autoplay=true;n.loop=true;}m.appendChild(n);
    }else{const s=document.createElement('span');s.textContent='لا توجد صورة للعبة';m.appendChild(s);}
    const sp=$('tgTabSpecs');sp.replaceChildren();
    const d=document.createElement('p');d.className='tg-specs-desc';d.textContent=rec.description||'لا يوجد وصف.';sp.appendChild(d);
    const dl=document.createElement('dl');
    specRows(rec).forEach(([k,v])=>{const a=document.createElement('dt'),b=document.createElement('dd');a.textContent=k;b.textContent=v;dl.append(a,b);});
    sp.appendChild(dl);
    if(rec.extras&&rec.extras.length){const g=document.createElement('div');g.className='tg-gallery';
      rec.extras.forEach(b=>{const n=(b.type||'').startsWith('video/')?document.createElement('video'):document.createElement('img');n.src=mkUrl(b);if(n.tagName==='VIDEO') n.controls=true;g.appendChild(n);});sp.appendChild(g);}
    setTab('specs');
    $('tgDetailPlay').textContent=rec.builtin?'▶ العب الآن':dlLabel(rec);
    $('tgDetailDev').hidden=!(!rec.builtin&&rec.owner&&rec.owner===userKey());
    bumpView(rec);renderStats();
    (function(){const av=$('tgDevAvatar');if(!av) return;av.replaceChildren();
      if(rec.builtin||!rec.owner){av.hidden=true;return;}
      const mine=rec.owner===userKey(),me=window.__me(),nm=mine?(me.name||rec.ownerName||''):(rec.ownerName||''),ph=mine?(me.photo||''):(rec.ownerPhoto||'');
      if(ph){const i=document.createElement('img');i.src=ph;i.alt='';av.appendChild(i);}else av.textContent=(nm||'?').trim().charAt(0).toUpperCase();
      av.title=nm;av.hidden=false;av.onclick=()=>{try{window.tgShowDev&&window.tgShowDev(rec,nm);}catch(_){}};})();
    detail.classList.add('active');detail.setAttribute('aria-hidden','false');
  }
  function closeDetail(){
    detail.classList.remove('active');detail.setAttribute('aria-hidden','true');
    $('tgDetailMedia').replaceChildren();detailUrls.forEach(u=>URL.revokeObjectURL(u));detailUrls=[];
  }
  $('tgDetailClose').addEventListener('click',closeDetail);
  detail.addEventListener('click',e=>{if(e.target===detail) closeDetail();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&detail.classList.contains('active')) closeDetail();});
  detail.querySelectorAll('.tg-tabs button').forEach(b=>b.addEventListener('click',()=>setTab(b.dataset.tab)));
  $('tgDetailPlay').addEventListener('click',()=>{
    const r=currentRec;if(!r) return;
    if(r.builtin){closeDetail();r.play();}else downloadGame(r);
  });
  $('tgDetailDev').addEventListener('click',()=>{const r=currentRec;closeDetail();if(r) startDevelop(r);});

  /* ---------- العدادات: مشاهدات / تقييمات / مستخدمون ---------- */
  const SK='tgStats';
  const getStats=()=>{try{return JSON.parse(localStorage.getItem(SK)||'{}');}catch(_){return {};}};
  function userKey(){try{const p=JSON.parse(localStorage.getItem('toryakProfile')||'null');return p?p.id:'guest';}catch(_){return 'guest';}}
  const WORDS={ar:['مشاهدة','تقييم','مستخدم'],en:['views','ratings','users'],fr:['vues','avis','utilisateurs'],zh:['次浏览','个评分','位用户'],ur:['مشاہدات','ریٹنگز','صارفین']};
  const IC={eye:'<svg viewBox="0 0 24 24"><path d="M12 5C6.5 5 2.2 8.6 1 12c1.2 3.4 5.5 7 11 7s9.8-3.6 11-7c-1.2-3.4-5.5-7-11-7zm0 11.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-7a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z"/></svg>',star:'<svg viewBox="0 0 24 24"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>',users:'<svg viewBox="0 0 24 24"><path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm8 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM9 13c-3.3 0-7 1.7-7 4v3h14v-3c0-2.3-3.7-4-7-4zm8 .5c-.5 0-1 .1-1.5.2 1.1.9 1.5 2 1.5 3.3V20h5v-2.5c0-2-2.7-4-5-4z"/></svg>'};
  function touch(id,fn){const o=getStats(),s=o[id]||{v:0,r:{},u:[]};fn(s);if(userKey()!=='guest'&&!s.u.includes(userKey())) s.u.push(userKey());o[id]=s;try{localStorage.setItem(SK,JSON.stringify(o));}catch(_){}}
  const bumpViewLocal=rec=>touch(rec.id,s=>{s.vw=s.vw||[];const k=userKey();if(k==='guest'||s.vw.includes(k)) return;s.vw.push(k);s.v++;});
  const bumpView=rec=>{bumpViewLocal(rec);pushStat(rec.id,{view:true});};
  function pushStat(id,p){if(!window.tgCloud||userKey()==='guest') return;tgCloud.putStat(id,userKey(),p).catch(e=>console.warn(e));}
  function touchRaw(id,fn){const o=getStats(),s=o[id]||{v:0,r:{},u:[]};fn(s);o[id]=s;try{localStorage.setItem(SK,JSON.stringify(o));}catch(_){}}
  async function pullStats(id){
    if(!window.tgCloud) return;
    try{const d=await tgCloud.getStat(id);if(!d) return;
      touchRaw(id,s=>{s.vw=Array.from(new Set([...(s.vw||[]),...(d.vw||[])]));s.u=Array.from(new Set([...(s.u||[]),...(d.u||[])]));s.r=Object.assign({},d.r||{},s.r||{});s.v=s.vw.length;});
    }catch(e){console.warn(e);}
  }
  function renderStats(){
    if(!currentRec) return;const s=getStats()[currentRec.id]||{v:0,r:{},u:[]},rs=Object.values(s.r);
    const avg=rs.length?(rs.reduce((a,b)=>a+b,0)/rs.length).toFixed(1):'—';
    const W=WORDS[window.__tgLang()]||WORDS.ar,nu=s.u.filter(x=>x!=='guest').length;$('tgStatsText').innerHTML=IC.eye+' '+s.v+' '+W[0]+' &nbsp; '+IC.star+' '+avg+' ('+rs.length+' '+W[1]+') &nbsp; '+IC.users+' '+nu+' '+W[2];
    const me=s.r[userKey()]||0;$('tgStars').querySelectorAll('button').forEach(b=>b.classList.toggle('on',+b.dataset.n<=me));
  }
  window.__tgRenderStats=renderStats;
  $('tgStars').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{if(!currentRec) return;touch(currentRec.id,s=>{s.r[userKey()]=+b.dataset.n;});pushStat(currentRec.id,{rate:+b.dataset.n});renderStats();}));

  /* ---------- التعليقات ---------- */
  let commentUrls=[];
  async function renderComments(){
    const list=$('tgCommentList'),cork=$('tgCork');commentUrls.forEach(u=>URL.revokeObjectURL(u));commentUrls=[];
    if(!currentRec) return;
    const id=currentRec.id;list.replaceChildren();cork.replaceChildren();
    let items=[];try{items=await getComments(id);}catch(_){}
    if(!currentRec||currentRec.id!==id) return;
    items.sort((a,b)=>b.createdAt-a.createdAt);
    const cols=['#fff4a3','#ffd1dc','#c9f0ff','#d8ffc9','#ffe0b5'];
    if(!items.length){const h=document.createElement('div');h.className='tg-cork-hint';h.textContent='لوحة الفلين فارغة — علّق ليظهر تعليقك هنا';cork.appendChild(h);}
    items.slice().sort(()=>Math.random()-.5).slice(0,8).forEach((c,i)=>{
      const n=document.createElement('div');n.className='tg-note';n.style.background=cols[i%cols.length];
      n.style.transform='rotate('+(Math.random()*14-7).toFixed(1)+'deg)';n.style.left=(3+(i%4)*24.5)+'%';n.style.top=(6+Math.floor(i/4)*46)+'%';
      if(c.imageBlob){const u=URL.createObjectURL(c.imageBlob);commentUrls.push(u);const im=document.createElement('img');im.src=u;im.alt='';n.classList.add('tg-note-img');n.appendChild(im);
        if(c.text){const t=document.createElement('span');t.textContent=c.text.slice(0,40);n.appendChild(t);}}
      else n.textContent=(c.text||'').slice(0,70);
      cork.appendChild(n);
    });
    list.hidden=items.length>0;
    if(!items.length){const p=document.createElement('p');p.className='tg-empty';p.textContent='لا توجد تعليقات بعد. كن أول من يعلّق!';list.appendChild(p);list.hidden=false;}
    items.forEach(c=>{
      const box=document.createElement('div');box.className='tg-comment';
      const n=document.createElement('b');n.textContent=c.name||'زائر';
      const t=document.createElement('small');t.textContent=new Date(c.createdAt).toLocaleString(window.__tgLoc());box.append(n,t);
      if(c.text){const p=document.createElement('p');p.textContent=c.text;box.appendChild(p);}
      if(c.imageBlob){const u=URL.createObjectURL(c.imageBlob);commentUrls.push(u);const im=document.createElement('img');im.src=u;im.alt='صورة مرفقة';box.appendChild(im);}
      list.appendChild(box);
    });
  }
  $('tgCork').addEventListener('click',()=>{const l=$('tgCommentList');l.hidden=false;l.scrollIntoView({behavior:'smooth',block:'nearest'});});
  let cPrevUrl=null;
  $('tgCImg').addEventListener('change',function(){
    const f=this.files[0],pv=$('tgCPrev');if(cPrevUrl){URL.revokeObjectURL(cPrevUrl);cPrevUrl=null;}
    if(!f){pv.hidden=true;return;}cPrevUrl=URL.createObjectURL(f);pv.src=cPrevUrl;pv.hidden=false;
  });
  $('tgCommentForm').addEventListener('submit',async function(e){
    e.preventDefault();if(!currentRec) return;
    const text=$('tgCText').value.trim(),img=$('tgCImg').files[0]||null;
    if(!text&&!img) return;
    try{
      await saveComment({id:'c-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),gameId:currentRec.id,name:$('tgCName').value.trim(),text,imageBlob:img,createdAt:Date.now()});
      touch(currentRec.id,()=>{});renderStats();$('tgCText').value='';$('tgCImg').value='';$('tgCPrev').hidden=true;renderComments();
    }catch(err){console.error(err);alert('تعذر حفظ التعليق في هذا المتصفح.');}
  });

  /* ---------- مشغّل اللعبة ---------- */
  function showPlayer(r){
    const frame=$('toryakGameFrame'),box=$('toryakGameDownload'),link=$('toryakGameDownloadLink'),ext=$('toryakGameExternalLink');
    $('toryakGamePlayerTitle').textContent=r.name||'اللعبة';
    frame.removeAttribute('src');frame.style.display='block';box.hidden=true;ext.hidden=true;ext.removeAttribute('href');
    if(activePlayerObjectUrl){URL.revokeObjectURL(activePlayerObjectUrl);activePlayerObjectUrl=null;}
    if(r.url){frame.src=r.url;ext.href=r.url;ext.hidden=false;}
    else if(r.sourceBlob){
      const isHtml=/\.html?$/.test((r.fileName||'').toLowerCase())||r.sourceBlob.type==='text/html';
      activePlayerObjectUrl=URL.createObjectURL(r.sourceBlob);
      if(isHtml) frame.src=activePlayerObjectUrl;
      else{frame.style.display='none';box.hidden=false;link.href=activePlayerObjectUrl;link.download=r.fileName||'game-file';}
    }
    gamePlayer.classList.add('active');gamePlayer.setAttribute('aria-hidden','false');
  }
  async function openPublishedGame(r){
    try{showPlayer((await getAllGameRecords()).find(i=>i.id===r.id)||r);}catch(_){showPlayer(r);}
  }
  $('toryakCloseGamePlayer').addEventListener('click',()=>{
    gamePlayer.classList.remove('active');gamePlayer.setAttribute('aria-hidden','true');
    const f=$('toryakGameFrame');f.removeAttribute('src');f.style.display='block';
    if(activePlayerObjectUrl){URL.revokeObjectURL(activePlayerObjectUrl);activePlayerObjectUrl=null;}
  });

  /* ---------- محرر صورة اللعبة ---------- */
  const cv=$('tgEditCanvas'),cx=cv.getContext('2d'),host=$('toryakGameCoverPreview');
  const DEF={zoom:1,x:0,y:0,b:100,c:100,s:100,d:60};let S={...DEF},img=null,imgUrl=null,prevRaf=0;
  const PH='صورة أو فيديو اللعبة';
  function resetHost(){host.replaceChildren(Object.assign(document.createElement('span'),{textContent:PH}));}
  function syncSliders(){$('tgEditor').querySelectorAll('input[type=range]').forEach(r=>{r.value=S[r.dataset.k];});}
  function drawEditor(){
    const W=cv.width,H=cv.height;cx.clearRect(0,0,W,H);cx.fillStyle='#0b0f19';cx.fillRect(0,0,W,H);
    if(!img) return;
    const k=Math.max(W/img.width,H/img.height)*S.zoom,w=img.width*k,h=img.height*k;
    cx.save();if('filter' in cx) cx.filter='brightness('+S.b+'%) contrast('+S.c+'%) saturate('+S.s+'%)';
    cx.drawImage(img,(W-w)*(S.x+1)/2,(H-h)*(S.y+1)/2,w,h);cx.restore();
    const d=S.d/100;
    if(d>0){
      let g=cx.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,W*.72);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,'+(.7*d)+')');cx.fillStyle=g;cx.fillRect(0,0,W,H);
      g=cx.createLinearGradient(0,H*.5,0,H);g.addColorStop(0,'rgba(5,8,20,0)');g.addColorStop(1,'rgba(5,8,20,'+(.8*d)+')');cx.fillStyle=g;cx.fillRect(0,0,W,H);
      g=cx.createLinearGradient(0,0,W*.6,H*.6);g.addColorStop(0,'rgba(255,255,255,'+(.2*d)+')');g.addColorStop(.5,'rgba(255,255,255,0)');cx.fillStyle=g;cx.fillRect(0,0,W,H);
      cx.strokeStyle='rgba(255,255,255,'+(.3*d)+')';cx.lineWidth=4;cx.strokeRect(2,2,W-4,H-4);
    }
    cancelAnimationFrame(prevRaf);
    prevRaf=requestAnimationFrame(()=>{
      let i=host.querySelector('img');if(!i){host.replaceChildren();i=document.createElement('img');i.alt='معاينة';host.appendChild(i);}
      i.src=cv.toDataURL('image/jpeg',.8);
    });
  }
  $('tgEditor').querySelectorAll('input[type=range]').forEach(r=>r.addEventListener('input',()=>{S[r.dataset.k]=+r.value;drawEditor();}));
  let drag=null;
  cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY};cv.setPointerCapture(e.pointerId);cv.style.cursor='grabbing';});
  cv.addEventListener('pointerup',()=>{drag=null;cv.style.cursor='grab';});
  cv.addEventListener('pointermove',e=>{
    if(!drag||!img) return;
    const sc=cv.width/cv.getBoundingClientRect().width,k=Math.max(cv.width/img.width,cv.height/img.height)*S.zoom;
    const ow=cv.width-img.width*k,oh=cv.height-img.height*k;
    if(ow) S.x=Math.max(-1,Math.min(1,S.x+2*(e.clientX-drag.x)*sc/ow));
    if(oh) S.y=Math.max(-1,Math.min(1,S.y+2*(e.clientY-drag.y)*sc/oh));
    drag={x:e.clientX,y:e.clientY};syncSliders();drawEditor();
  });
  function resetCover(){
    img=null;if(imgUrl){URL.revokeObjectURL(imgUrl);imgUrl=null;}S={...DEF};syncSliders();
    $('toryakGameCover').value='';$('tgEditor').hidden=true;$('tgCoverTile').hidden=false;resetHost();
  }
  $('toryakGameCover').addEventListener('change',function(){
    const f=this.files[0];if(!f) return;
    if(imgUrl) URL.revokeObjectURL(imgUrl);imgUrl=URL.createObjectURL(f);
    const im=new Image();
    im.onload=()=>{img=im;S={...DEF};syncSliders();$('tgEditor').hidden=false;$('tgCoverTile').hidden=true;drawEditor();};
    im.onerror=()=>{resetCover();$('toryakGameStatus').textContent='تعذر قراءة الصورة.';};
    im.src=imgUrl;
  });
  $('tgEdReset').addEventListener('click',()=>{S={...DEF};syncSliders();drawEditor();});
  $('tgEdRemove').addEventListener('click',resetCover);

  /* ---------- فيديو اللعبة ---------- */
  let vidUrl=null;
  function resetVideo(){
    if(vidUrl){URL.revokeObjectURL(vidUrl);vidUrl=null;}
    $('toryakGameVideo').value='';const p=$('tgVideoPrev');p.hidden=true;p.removeAttribute('src');$('tgVideoName').textContent='أضف فيديو';
  }
  $('toryakGameVideo').addEventListener('change',function(){
    const f=this.files[0];if(!f){resetVideo();return;}
    if(vidUrl) URL.revokeObjectURL(vidUrl);vidUrl=URL.createObjectURL(f);
    const p=$('tgVideoPrev');p.src=vidUrl;p.hidden=false;$('tgVideoName').textContent='✓ '+f.name+' (اضغط لتغييره)';
  });

  /* ---------- معاينة ونشر ---------- */
  function updateLivePreview(){
    $('toryakGamePreviewName').textContent=$('toryakGameName').value.trim()||'اسم اللعبة';
    $('toryakGamePreviewDescription').textContent=$('toryakGameDescription').value.trim()||'سيظهر وصف اللعبة هنا.';
  }
  $('toryakGameName').addEventListener('input',updateLivePreview);
  $('toryakGameDescription').addEventListener('input',updateLivePreview);
  window.tgNameKey=n=>String(n||'').toLowerCase().normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[^\p{L}\p{N}]+/gu,'');
  async function tgNameTaken(name,exceptId){
    const k=window.tgNameKey(name);if(!k) return false;
    if([BUILTIN.xo.name,BUILTIN.puzzle.name].some(n=>window.tgNameKey(n)===k)) return true;
    try{if((await getAllGameRecords()).some(g=>g.id!==exceptId&&window.tgNameKey(g.name)===k)) return true;}catch(_){}
    try{if(JSON.parse(localStorage.getItem('toryakProjects')||'[]').some(p=>String(p.id)!==String(exceptId)&&window.tgNameKey(p.name)===k)) return true;}catch(_){}
    try{if(window.tgCloud&&await tgCloud.nameTaken(name,exceptId)) return true;}catch(_){}
    return false;
  }
  window.tgNameTaken=tgNameTaken;
  async function pushGame(rec){
    const m=await tgCloud.putGame(rec);rec.cloud=m.cloud;rec.cloudSynced=true;rec.updatedAt=m.updatedAt;await saveGameRecord(rec);return rec;
  }
  let syncingG=false;
  async function syncGames(){
    if(syncingG||!window.tgCloud) return;syncingG=true;
    try{
      const remote=await tgCloud.listGames();if(!remote) return;
      const local=await getAllGameRecords(),lm=new Map(local.map(r=>[r.id,r])),rm=new Set();let changed=false;
      for(const {id,data} of remote){
        rm.add(id);const l=lm.get(id);
        if(l&&l.cloud&&(l.updatedAt||0)>=(data.updatedAt||0)) continue;
        const rec={...(l||{}),id,name:data.name,description:data.description,url:data.url,fileName:data.fileName,owner:data.owner,ownerName:data.ownerName,ownerPhoto:data.ownerPhoto,ownerJoined:data.ownerJoined,createdAt:data.createdAt,updatedAt:data.updatedAt,cloud:data.cloud,cloudSynced:true};
        const cm=data.cloud&&data.cloud.cover;
        if(cm&&!(l&&l.coverBlob&&l.cloud&&l.cloud.cover&&l.cloud.cover.sig===cm.sig)){try{rec.coverBlob=await tgCloud.getBlob(cm);}catch(e){console.warn(e);}}
        if(l&&l.cloud){
          for(const [role,key] of [['video','videoBlob'],['file','sourceBlob']]){const a=l.cloud[role],b=data.cloud&&data.cloud[role];if(!b||(a&&a.sig!==b.sig)) delete rec[key];}
          const sg=x=>JSON.stringify(((x&&x.extras)||[]).map(e=>e.sig));
          if(sg(l.cloud)!==sg(data.cloud)) rec.extras=[];
        }
        await saveGameRecord(rec);changed=true;
      }
      for(const l of local){if(l.cloudSynced&&!rm.has(l.id)){await dbTx('games','readwrite',s=>s.delete(l.id));changed=true;}}
      const me=window.__me()||{};
      if(userKey()!=='guest') for(const l of local){
        if(l.cloudSynced||rm.has(l.id)) continue;
        if(l.owner&&l.owner!==userKey()) continue;
        if(!l.owner){l.owner=userKey();l.ownerName=me.name||'';l.ownerPhoto=me.photo||'';l.ownerJoined=window.__joined(userKey());}
        try{await pushGame(l);changed=true;}catch(e){console.warn('game upload',e);}
      }
      if(changed){gamesGrid.querySelectorAll('[data-published-game]').forEach(c=>{(c._urls||[]).forEach(u=>URL.revokeObjectURL(u));c.remove();});await loadPublishedGames();}
    }finally{syncingG=false;}
  }
  window.tgSyncGames=syncGames;
  let nmT=0;
  $('toryakGameName').addEventListener('input',()=>{clearTimeout(nmT);nmT=setTimeout(async()=>{
    const v=$('toryakGameName').value.trim(),st=$('toryakGameStatus');if(!v) return;
    if(await tgNameTaken(v,editRec?editRec.id:null)) st.textContent='⚠ هذا الاسم مطابق لاسم لعبة أو مجسم موجود. اختر اسمًا آخر.';
    else if(st.textContent.startsWith('⚠')) st.textContent='';
  },450);});
  $('toryakGameForm').addEventListener('submit',async function(e){
    e.preventDefault();
    const st=$('toryakGameStatus'),name=$('toryakGameName').value.trim(),description=$('toryakGameDescription').value.trim(),
      rawUrl=$('toryakGameUrl').value.trim(),sourceFile=$('toryakGameFile').files[0]||null,videoFile=$('toryakGameVideo').files[0]||null;
    if(!name){st.textContent='اكتب اسم اللعبة أولًا.';return;}
    const prev=editRec;
    if(await tgNameTaken(name,prev?prev.id:null)){st.textContent='⚠ هذا الاسم مطابق لاسم لعبة أو مجسم موجود. اختر اسمًا آخر.';return;}
    if(!rawUrl&&!sourceFile&&!(prev&&(prev.url||prev.sourceBlob))){st.textContent='أضف رابط اللعبة أو اختر ملفًا.';return;}
    if(rawUrl&&!/^https?:\/\//i.test(rawUrl)){st.textContent='استخدم رابطًا يبدأ بـ https:// أو http://';return;}
    let coverBlob=prev?prev.coverBlob:null;
    if(img) coverBlob=await new Promise(r=>cv.toBlob(r,'image/jpeg',.92));
    const extras=(prev&&prev.extras?prev.extras.slice():[]).concat(Array.from($('toryakGameExtras').files||[]));
    const rec=prev?{...prev,name,description,url:rawUrl,coverBlob,videoBlob:videoFile||prev.videoBlob,extras,updatedAt:Date.now()}
      :{id:'game-'+Date.now()+'-'+Math.random().toString(36).slice(2,8),name,description,url:rawUrl||'',fileName:sourceFile?sourceFile.name:'',sourceBlob:sourceFile,coverBlob,videoBlob:videoFile,extras,owner:userKey(),ownerName:window.__me().name||'',ownerPhoto:window.__me().photo||'',ownerJoined:window.__joined(userKey()),createdAt:Date.now()};
    if(prev&&sourceFile){rec.sourceBlob=sourceFile;rec.fileName=sourceFile.name;}
    st.textContent='جارٍ حفظ اللعبة...';
    try{
      await saveGameRecord(rec);addPublishedCard(rec);
      let msg=prev?'تم تحديث اللعبة وحفظ إضافاتك بدون حذفها.':'تم حفظ اللعبة.';
      if(window.tgCloud&&await tgCloud.ok()){
        st.textContent='جارٍ النشر للجميع...';
        try{await pushGame(rec);addPublishedCard(rec);msg=prev?'تم تحديث اللعبة ونُشرت للجميع.':'تم نشر اللعبة للجميع.';}
        catch(ce){console.warn(ce);
          if(ce.message==='name-taken'&&!prev){await dbTx('games','readwrite',s=>s.delete(rec.id));const cc=gamesGrid.querySelector('[data-published-game="'+CSS.escape(rec.id)+'"]');if(cc) cc.remove();st.textContent='⚠ هذا الاسم مطابق لاسم لعبة أو مجسم موجود. اختر اسمًا آخر.';return;}
          msg=ce.message==='too-large'?'حُفظت على جهازك فقط: أحد الملفات أكبر من 25 ميجا.':'حُفظت على جهازك فقط، تعذر النشر للجميع ['+(ce.code||ce.message)+'] اضغط على ⚠ أسفل الشاشة لمعرفة السبب.';}
      }else msg+=' (على هذا الجهاز فقط: النشر للجميع غير مفعّل)';
      st.textContent=msg;
      this.reset();resetCover();resetVideo();exitDev();updateLivePreview();
    }catch(err){console.error(err);st.textContent='تعذر الحفظ في هذا المتصفح. جرّب ملفًا أصغر أو افتح الموقع عبر خادم ويب.';}
  });

  /* ---------- التطوير: تعديل لعبة منشورة بدون حذفها ---------- */
  $('toryakGameExtras').addEventListener('change',function(){$('tgExtrasName').textContent=this.files.length?'✓ '+this.files.length+' ملف':'أضف صورًا أو ملصقات أو فيديو';});
  function exitDev(){
    editRec=null;$('tgDevBanner').hidden=true;$('tgExtrasName').textContent='أضف صورًا أو ملصقات أو فيديو';
    gameStudio.querySelector('.toryak-game-publish').textContent='نشر اللعبة';
  }
  function startDevelop(rec){
    openGameStudio();editRec=rec;
    $('toryakGameName').value=rec.name||'';$('toryakGameDescription').value=rec.description||'';$('toryakGameUrl').value=rec.url||'';
    const bn=$('tgDevBanner');bn.textContent='وضع التطوير: «'+rec.name+'» — عدّل أو أضف أشياء جديدة ولن تُحذف اللعبة.';bn.hidden=false;
    gameStudio.querySelector('.toryak-game-publish').textContent='حفظ التطوير';
    const u=[];setCoverNode(host,rec.coverBlob,u);updateLivePreview();
  }
  window.tgApi={open:openDetail,closeDetail:closeDetail,hideGames:()=>{gamesPage.classList.remove('active');gamesPage.setAttribute('aria-hidden','true');},develop:startDevelop,list:getAllGameRecords,remove:async id=>{
    let old=null;try{old=(await getAllGameRecords()).find(r=>r.id===id);}catch(_){}
    await dbTx('games','readwrite',s=>s.delete(id));
    if(old&&old.cloudSynced&&window.tgCloud){try{await tgCloud.deleteGame(old);}catch(e){console.warn('cloud delete',e);}}
    const c=gamesGrid.querySelector('[data-published-game="'+CSS.escape(id)+'"]');if(c){(c._urls||[]).forEach(u=>URL.revokeObjectURL(u));c.remove();}}};
  window.toryakShowGamesPage=showGamesPage;
  window.toryakSetGamesMode=()=>switchSearchMode();
  loadPublishedGames();
})();
