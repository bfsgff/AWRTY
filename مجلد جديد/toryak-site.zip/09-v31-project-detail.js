/* Unified viewer handles built-in and published project pages. */
