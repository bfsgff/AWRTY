/* ===== النشر المشترك بين كل المستخدمين (Firebase Firestore) ===== */
const FS_URL='https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
let db=null,F=null,tried=false;
async function init(){
  if(db) return true; if(tried) return false;
  if(window.__tgFB===undefined) await new Promise(r=>window.addEventListener('tg-fb-ready',r,{once:true}));
  tried=true;
  if(!window.__tgFB||!window.__tgFB.app) return false;
  try{F=await import(FS_URL);db=F.getFirestore(window.__tgFB.app);return true;}catch(e){console.warn('Firestore',e);return false;}
}
const C=600000,LIM=25*1024*1024;
const b64=blob=>new Promise(r=>{const f=new FileReader();f.onload=()=>r(String(f.result).split(',')[1]||'');f.readAsDataURL(blob);});
const sig=b=>b?(b.size+':'+(b.type||'')+':'+(b.lastModified||0)):'';
async function putBlob(key,blob){
  if(blob.size>LIM) throw new Error('too-large');
  const n=Math.max(1,Math.ceil(blob.size/C));
  for(let i=0;i<n;i+=3){
    await Promise.all(Array.from({length:Math.min(3,n-i)},(_,j)=>{const k=i+j;return b64(blob.slice(k*C,(k+1)*C)).then(d=>F.setDoc(F.doc(db,'chunks',key+'_'+k),{d}));}));
  }
  return {key,n,size:blob.size,type:blob.type||'application/octet-stream',sig:sig(blob)};
}
async function getBlob(m){
  const parts=[];
  for(let i=0;i<m.n;i+=4){
    const g=await Promise.all(Array.from({length:Math.min(4,m.n-i)},(_,j)=>F.getDoc(F.doc(db,'chunks',m.key+'_'+(i+j))).then(s=>fetch('data:application/octet-stream;base64,'+s.data().d).then(r=>r.blob()))));
    parts.push(...g);
  }
  return new Blob(parts,{type:m.type});
}
async function delBlob(m){if(!m) return;for(let i=0;i<m.n;i++){try{await F.deleteDoc(F.doc(db,'chunks',m.key+'_'+i));}catch(_){}}}
let namesCache={t:0,list:[]};
const uidOf=o=>String(o||'').replace(/^email:/,'');
async function claimName(name,id,owner){
  const k=window.tgNameKey(name),ref=F.doc(db,'names',k),s=await F.getDoc(ref);
  if(s.exists()&&s.data().id!==id) throw new Error('name-taken');
  await F.setDoc(ref,{id,owner,name});return k;
}
async function releaseName(name,id){
  try{const ref=F.doc(db,'names',window.tgNameKey(name)),s=await F.getDoc(ref);if(s.exists()&&s.data().id===id) await F.deleteDoc(ref);}catch(_){}
}

window.tgCloud={
  ok:()=>init(),
  async nameTaken(name,exceptId){
    if(!await init()) return false;
    const s=await F.getDoc(F.doc(db,'names',window.tgNameKey(name)));
    return s.exists()&&s.data().id!==exceptId;
  },
  getBlob:m=>getBlob(m),
  async searchNames(q){
    if(!await init()) return [];
    if(Date.now()-namesCache.t>10000){const s=await F.getDocs(F.collection(db,'names'));namesCache={t:Date.now(),list:s.docs.map(d=>d.data())};}
    const k=window.tgNameKey(q);return namesCache.list.filter(n=>n&&n.name&&window.tgNameKey(n.name).includes(k));
  },
  /* ---- الألعاب ---- */
  async listGames(){
    if(!await init()) return null;
    const q=await F.getDocs(F.collection(db,'games'));return q.docs.map(d=>({id:d.id,data:d.data()}));
  },
  async putGame(rec){
    if(!await init()) throw new Error('no-cloud');
    const old=(await F.getDoc(F.doc(db,'games',rec.id))).data()||{},oc=old.cloud||{},cloud={};
    await claimName(rec.name,rec.id,rec.owner);
    if(old.name&&window.tgNameKey(old.name)!==window.tgNameKey(rec.name)) await releaseName(old.name,rec.id);
    const up=async(role,blob)=>{
      const o=oc[role];
      if(!blob) return o||null;
      if(o&&o.sig===sig(blob)) return o;
      const m=await putBlob(rec.id+'_'+role+'_'+Date.now(),blob);
      if(o) await delBlob(o);return m;
    };
    cloud.cover=await up('cover',rec.coverBlob);cloud.video=await up('video',rec.videoBlob);cloud.file=await up('file',rec.sourceBlob);
    const ex=[],oe=oc.extras||[];
    for(let i=0;i<(rec.extras||[]).length;i++){
      const b=rec.extras[i],o=oe[i];
      if(!b) {if(o) ex.push(o);continue;}
      if(o&&o.sig===sig(b)) ex.push(o);else{const m=await putBlob(rec.id+'_x'+i+'_'+Date.now(),b);if(o) await delBlob(o);ex.push(m);}
    }
    cloud.extras=ex;
    const updatedAt=Date.now();
    await F.setDoc(F.doc(db,'games',rec.id),{id:rec.id,name:rec.name,description:rec.description||'',url:rec.url||'',fileName:rec.fileName||'',
      owner:rec.owner||'',ownerUid:uidOf(rec.owner),ownerName:rec.ownerName||'',ownerPhoto:(rec.ownerPhoto||'').slice(0,60000),ownerJoined:rec.ownerJoined||0,
      createdAt:rec.createdAt||updatedAt,updatedAt,cloud});
    return {updatedAt,cloud};
  },
  async deleteGame(rec){
    if(!await init()) return;
    const s=await F.getDoc(F.doc(db,'games',rec.id)),d=s.data();if(!d) return;
    for(const k of ['cover','video','file']) await delBlob(d.cloud&&d.cloud[k]);
    for(const m of (d.cloud&&d.cloud.extras)||[]) await delBlob(m);
    try{const c=await F.getDocs(F.collection(db,'games',rec.id,'comments'));for(const x of c.docs) await F.deleteDoc(x.ref);}catch(_){}
    try{await F.deleteDoc(F.doc(db,'stats',rec.id));}catch(_){}
    await F.deleteDoc(F.doc(db,'games',rec.id));await releaseName(d.name,rec.id);
  },
  /* ---- التعليقات والعدادات ---- */
  async putComment(c){
    if(!await init()) return;
    let image='';if(c.imageBlob) image=await new Promise(r=>{const f=new FileReader();f.onload=()=>r(String(f.result));f.readAsDataURL(c.imageBlob);});
    if(image.length>900000) image='';
    await F.setDoc(F.doc(db,'games',c.gameId,'comments',c.id),{id:c.id,gameId:c.gameId,name:c.name||'',text:c.text||'',image,createdAt:c.createdAt});
  },
  async getComments(gameId){
    if(!await init()) return null;
    const q=await F.getDocs(F.collection(db,'games',gameId,'comments'));
    return Promise.all(q.docs.map(async d=>{const x=d.data();let imageBlob=null;if(x.image){try{imageBlob=await (await fetch(x.image)).blob();}catch(_){}}
      return {id:x.id,gameId:x.gameId,name:x.name,text:x.text,imageBlob,createdAt:x.createdAt};}));
  },
  async putStat(id,key,p){
    if(!await init()) return;
    const o={u:F.arrayUnion(key)};if(p.view) o.vw=F.arrayUnion(key);if(p.rate) o.r={[key]:p.rate};
    await F.setDoc(F.doc(db,'stats',id),o,{merge:true});
  },
  async getStat(id){
    if(!await init()) return null;
    const s=await F.getDoc(F.doc(db,'stats',id));return s.exists()?s.data():null;
  },
  /* ---- المجسمات ثلاثية الأبعاد ---- */
  async putModel(rec){
    if(!await init()) throw new Error('no-cloud');
    await claimName(rec.name,String(rec.id),rec.owner);
    const m=await putBlob('m'+rec.id+'_'+Date.now(),rec.modelBlob);
    await F.setDoc(F.doc(db,'models',String(rec.id)),{id:String(rec.id),name:rec.name,description:rec.description||'',fileName:rec.fileName||'',modelExt:rec.modelExt||'glb',
      owner:rec.owner||'',ownerUid:uidOf(rec.owner),ownerName:rec.ownerName||'',ownerPhoto:(rec.ownerPhoto||'').slice(0,60000),
      frames:JSON.stringify(rec.animationFrames||[]),createdAt:rec.createdAt||new Date().toISOString(),cloud:{model:m}});
    return m;
  },
  async deleteModel(id){
    if(!await init()) return;
    const s=await F.getDoc(F.doc(db,'models',String(id))),d=s.data();if(!d) return;
    await delBlob(d.cloud&&d.cloud.model);await F.deleteDoc(F.doc(db,'models',String(id)));await releaseName(d.name,String(id));
  },
  async listModels(){
    if(!await init()) return null;
    const q=await F.getDocs(F.collection(db,'models'));return q.docs.map(d=>d.data());
  }
};
window.tgCloudDeleteModel=id=>{try{window.tgCloud.deleteModel(id).catch(e=>console.warn('cloud delete',e));}catch(_){}};

/* مزامنة المجسمات: ما ينشره أي شخص يظهر عند الجميع */
const IDBN='toryakProjectDB';
const idb=(mode,fn)=>new Promise((res,rej)=>{const q=indexedDB.open(IDBN,1);q.onupgradeneeded=()=>{if(!q.result.objectStoreNames.contains('projects')) q.result.createObjectStore('projects',{keyPath:'id'});};
  q.onsuccess=()=>{const d=q.result,t=d.transaction('projects',mode),r=fn(t.objectStore('projects'));t.oncomplete=()=>{d.close();res(r&&r.result);};t.onerror=t.onabort=()=>{d.close();rej(t.error);};};q.onerror=()=>rej(q.error);});
const lsProjects=()=>{try{return JSON.parse(localStorage.getItem('toryakProjects')||'[]');}catch(_){return [];}};
let syncingM=false;
async function syncModels(){
  if(syncingM||!await init()) return;syncingM=true;
  try{
    const rem=await window.tgCloud.listModels();if(!rem) return;
    let local=lsProjects(),changed=false;const rids=new Set(rem.map(d=>Number(d.id)));
    for(const d of rem){
      const id=Number(d.id);if(local.some(p=>Number(p.id)===id)) continue;
      try{
        const blob=await getBlob(d.cloud.model);
        const frames=(()=>{try{return JSON.parse(d.frames||'[]');}catch(_){return [];}})();
        await idb('readwrite',s=>s.put({id,name:d.name,description:d.description,fileName:d.fileName,modelExt:d.modelExt||'glb',modelBlob:blob,animationFrames:frames,createdAt:d.createdAt,owner:d.owner,ownerName:d.ownerName,ownerPhoto:d.ownerPhoto}));
        local=lsProjects();local.unshift({id,name:d.name,description:d.description,fileName:d.fileName,createdAt:d.createdAt,hasModel:true,animationFrames:frames,owner:d.owner,ownerName:d.ownerName,ownerPhoto:d.ownerPhoto,cloudSynced:true});
        localStorage.setItem('toryakProjects',JSON.stringify(local.slice(0,200)));changed=true;
      }catch(e){console.warn('model sync',e);}
    }
    local=lsProjects();
    for(const p of local.slice()){
      if(p.cloudSynced&&!rids.has(Number(p.id))){ /* حذفه صاحبه */
        local=local.filter(x=>Number(x.id)!==Number(p.id));try{await idb('readwrite',s=>s.delete(Number(p.id)));}catch(_){}changed=true;
      }
    }
    localStorage.setItem('toryakProjects',JSON.stringify(local));
    /* رفع مجسماتي القديمة التي لم تُنشر بعد */
    const me=(window.__me&&window.__me())||{};
    for(const p of local){
      if(p.cloudSynced||rids.has(Number(p.id))||!p.hasModel) continue;
      if(p.owner&&p.owner!==me.id) continue;
      try{
        const r=await idb('readonly',s=>s.get(Number(p.id)));if(!r||!r.modelBlob) continue;
        r.owner=me.id||'';r.ownerName=me.name||'';r.ownerPhoto=me.photo||'';
        if(await window.tgCloud.nameTaken(r.name,String(r.id))) continue;
        await window.tgCloud.putModel(r);p.owner=r.owner;p.ownerName=r.ownerName;p.ownerPhoto=r.ownerPhoto;p.cloudSynced=true;changed=true;
        await idb('readwrite',s=>s.put(r));
      }catch(e){console.warn('model upload',e);}
    }
    localStorage.setItem('toryakProjects',JSON.stringify(local));
    if(changed&&window.tgRenderModels) window.tgRenderModels();
  }finally{syncingM=false;}
}
window.tgSyncModels=syncModels;
async function syncAll(){
  try{if(window.tgSyncGames) await window.tgSyncGames();}catch(e){console.warn(e);}
  try{await syncModels();}catch(e){console.warn(e);}
}
window.tgSyncAll=syncAll;
window.tgAugmentSearch=async function(raw,kind){
  raw=String(raw||'').trim();if(!raw||!window.tgCloud) return;
  let list;try{list=await window.tgCloud.searchNames(raw);}catch(_){return;}
  const panel=document.getElementById('mainSearchSuggestions'),input=document.getElementById('mainSearchBox');
  if(!panel||!input||input.value.trim()!==raw) return;
  const have=new Set(Array.from(panel.querySelectorAll('.main-search-suggestion-title')).map(e=>window.tgNameKey(e.textContent)));
  const add=list.filter(n=>(String(n.id).startsWith('game-')?'game':'model')===kind&&!have.has(window.tgNameKey(n.name)));
  if(!add.length) return;
  panel.querySelectorAll('.main-search-suggestion-empty').forEach(e=>e.remove());
  add.slice(0,5).forEach(n=>{
    const b=document.createElement('button');b.type='button';b.className='main-search-suggestion';b.setAttribute('role','option');
    const a=document.createElement('span');a.className='main-search-suggestion-title';a.textContent=n.name;
    const s=document.createElement('span');s.className='main-search-suggestion-subtitle';s.textContent=kind==='game'?'لعبة منشورة من مستخدم آخر':'مجسم منشور من مستخدم آخر';
    b.append(a,s);
    b.addEventListener('click',async()=>{
      input.value=n.name;panel.classList.remove('active');input.setAttribute('aria-expanded','false');
      try{await syncAll();}catch(_){}
      if(kind==='game'){window.toryakShowGamesPage&&window.toryakShowGamesPage(n.name);}else{window.tgShowModels&&window.tgShowModels(n.name,true);}
    });
    panel.appendChild(b);
  });
  panel.classList.add('active');input.setAttribute('aria-expanded','true');
};
async function health(){
  const chip=document.createElement('div');chip.id='tgCloudChip';
  chip.style.cssText='position:fixed;bottom:12px;left:12px;z-index:9999;padding:6px 12px;border-radius:999px;font:12px Arial,sans-serif;background:rgba(0,0,0,.75);color:#fff;border:1px solid rgba(255,255,255,.3);cursor:pointer;transition:opacity .6s';
  let ok=false,msg='';
  if(!window.__tgFB) msg='النشر المشترك غير مفعّل: إعدادات Firebase غير مضبوطة داخل الملف، أو أنك سجّلت دخولًا محليًا بدون Firebase. بدونه ما يشوف الآخرون ما تنشره.';
  else if(!await init()) msg='تعذر تحميل قاعدة البيانات Firestore. تحقق من الاتصال بالإنترنت.';
  else{
    try{await F.setDoc(F.doc(db,'health','ping'),{t:Date.now()});await F.getDoc(F.doc(db,'health','ping'));ok=true;msg='النشر المشترك يعمل.';}
    catch(e){
      const c=String(e&&e.code||'');const m=String(e&&e.message||'');
      msg=c==='permission-denied'?'قواعد Firestore ترفض الوصول. الصق القواعد في Firestore ← Rules ثم اضغط Publish.'
        :(c==='failed-precondition'||c==='not-found'||/does not exist|NOT_FOUND/i.test(m))?'لم تُنشأ قاعدة Firestore بعد. من Firebase: Build ← Firestore Database ← Create database.'
        :c==='unavailable'?'تعذر الاتصال بـ Firestore (الإنترنت).':'خطأ في Firestore: '+(c||m);
    }
  }
  chip.textContent=ok?'☁ النشر المشترك يعمل':'⚠ النشر المشترك لا يعمل (اضغط)';
  chip.title=msg;chip.addEventListener('click',()=>alert(msg));
  document.body.appendChild(chip);
  if(ok) setTimeout(()=>{chip.style.opacity='0';setTimeout(()=>chip.remove(),700);},5000);
}
function start(){health();syncAll();setInterval(syncAll,20000);document.addEventListener('visibilitychange',()=>{if(!document.hidden) syncAll();});}
if(window.__tgEntered) start();else window.addEventListener('tg-entered',start,{once:true});
