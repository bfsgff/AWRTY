/*
 * Shared gallery preview engine:
 * - uses one WebGL context for non-weapon 3D gallery previews
 * - cards keep their existing HTML/CSS; their visible canvases are 2D targets
 * - loads models only near the viewport and pauses rendering when the gallery is hidden
 */
(function () {
  'use strict';
  const page = document.getElementById('modelsPage');
  if (!page) return;

  const specs = [];
  const state = { renderer:null, scratch:null, records:new Map(), frame:0, last:0, observer:null, lost:false, pageObserver:null };

  function setLoading(spec, message, done) {
    const host = document.querySelector(spec.host);
    const el = document.getElementById(spec.loading) || host?.querySelector('span');
    if (el) {
      if (message) el.textContent = message;
      el.classList?.toggle('hidden', !!done);
      if (done) el.style.display = 'none';
      else if (message) el.style.display = 'flex';
    }
    if (host) host.dataset.previewState = done ? 'ready' : (message ? 'error' : 'loading');
  }

  function ensureRenderer() {
    if (state.renderer) {
      try { if (!state.renderer.getContext().isContextLost()) return true; } catch (_) {}
      try { state.renderer.dispose(); } catch (_) {}
      state.renderer = null;
      state.scratch = null;
    }
    if (state.lost || typeof THREE === 'undefined' || !THREE.WebGLRenderer) return false;
    try {
      state.scratch = document.createElement('canvas');
      state.scratch.width = 320; state.scratch.height = 220;
      state.renderer = new THREE.WebGLRenderer({ canvas:state.scratch, alpha:true, antialias:false, powerPreference:'low-power', preserveDrawingBuffer:false });
      state.renderer.setPixelRatio(1);
      state.renderer.setClearColor(0x000000, 0);
      state.renderer.outputEncoding = THREE.sRGBEncoding;
      state.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      state.renderer.toneMappingExposure = 1.08;
      state.scratch.addEventListener('webglcontextlost', e => { e.preventDefault(); state.lost = true; stopLoop(); });
      state.scratch.addEventListener('webglcontextrestored', () => { state.lost = false; scheduleLoop(); refreshVisible(); });
      return true;
    } catch (error) {
      console.warn('Shared model-preview renderer unavailable', error);
      state.renderer = null; state.scratch = null;
      return false;
    }
  }

  function decodeGLB(data) {
    if (typeof data !== 'string' || !data) throw new Error('بيانات المجسم غير متوفرة');
    const comma = data.indexOf(',');
    const payload = data.startsWith('data:') ? data.slice(comma + 1) : data;
    if (!payload || comma === 0) throw new Error('صيغة بيانات المجسم غير صالحة');
    const binary = atob(payload);
    const bytes = new Uint8Array(binary.length);
    for (let i=0; i<binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }

  function disposeObject(root) {
    root?.traverse?.(node => {
      if (!node.isMesh) return;
      node.geometry?.dispose?.();
      const mats = Array.isArray(node.material) ? node.material : [node.material];
      mats.forEach(mat => {
        if (!mat) return;
        Object.values(mat).forEach(v => { if (v && v.isTexture) v.dispose(); });
        mat.dispose?.();
      });
    });
  }

  function nearViewport(host) {
    if (!host || !page.classList.contains('active') || document.hidden) return false;
    const r = host.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.bottom > -220 && r.top < innerHeight + 220;
  }

  function sizeFor(record) {
    const rawW = Math.round(record.host.clientWidth || 320);
    const rawH = Math.round(record.host.clientHeight || 210);
    const w = Math.min(480, Math.max(180, rawW));
    const h = Math.min(300, Math.max(150, rawH));
    if (record.canvas.width !== w) record.canvas.width = w;
    if (record.canvas.height !== h) record.canvas.height = h;
    record.camera.aspect = w / h;
    record.camera.updateProjectionMatrix();
    return { w, h };
  }

  function draw(record) {
    if (!record || !record.canvas.isConnected || !record.ctx || !state.renderer || state.lost) return;
    try {
      const {w,h} = sizeFor(record);
      state.renderer.setSize(w, h, false);
      state.renderer.setClearColor(0x000000, 0);
      state.renderer.render(record.scene, record.camera);
      record.ctx.clearRect(0,0,w,h);
      record.ctx.drawImage(state.scratch,0,0,w,h);
    } catch (error) {
      if (!state.lost) console.warn('Could not render model preview', record.spec.key, error);
    }
  }

  function onModelLoaded(spec, host, canvas, ctx, gltf) {
    if (!host.isConnected || !canvas.isConnected) {
      disposeObject(gltf.scene || gltf);
      return;
    }
    const loaded = gltf.scene || gltf;
    if (spec.pose && gltf.animations?.length && typeof THREE.AnimationMixer === 'function') {
      try {
        const mixer = new THREE.AnimationMixer(loaded);
        const action = mixer.clipAction(gltf.animations[0]);
        action.setLoop(THREE.LoopOnce, 1); action.clampWhenFinished = true; action.play();
        mixer.update(Math.min(0.05, Math.max(0.001, (gltf.animations[0].duration || 0.067) * 0.75)));
        action.paused = true;
      } catch (e) { console.warn('Could not apply embedded preview pose', e); }
    }
    const box = new THREE.Box3().setFromObject(loaded);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const maxSize = Math.max(size.x,size.y,size.z);
    if (!Number.isFinite(maxSize) || maxSize <= 0) {
      setLoading(spec, 'تعذّر قراءة المجسم', false);
      return;
    }
    loaded.position.sub(center);
    const root = new THREE.Group();
    root.add(loaded);
    root.scale.setScalar(Math.min(spec.scale / maxSize, 7));
    root.rotation.set(...spec.rotation);
    const scene = new THREE.Scene();
    scene.add(new THREE.HemisphereLight(0xffffff,0x20242c,1.5));
    const key = new THREE.DirectionalLight(0xffffff,2.1); key.position.set(3,4,5); scene.add(key);
    const fill = new THREE.DirectionalLight(0x82aaff,0.75); fill.position.set(-4,2,-3); scene.add(fill);
    scene.add(root);
    const camera = new THREE.PerspectiveCamera(32,1.5,0.01,1000);
    camera.position.set(0,0.10,3.7); camera.lookAt(0,0,0);
    loaded.traverse(node => { if (node.isMesh) { node.castShadow=false; node.receiveShadow=false; } });
    const record = { spec,host,canvas,ctx,scene,camera,root,visible:nearViewport(host) };
    const old = state.records.get(spec.key);
    if (old) disposeObject(old.root);
    state.records.set(spec.key,record);
    host.dataset.previewState = 'ready';
    host.classList.add('ready');
    const loading = document.getElementById(spec.loading) || host.querySelector('span');
    if (loading) { loading.classList?.add('hidden'); loading.style.display='none'; }
    draw(record);
    scheduleLoop();
  }

  function start(spec) {
    const host = document.querySelector(spec.host);
    const canvas = document.getElementById(spec.canvas);
    if (!host || !canvas || host.dataset.previewStarted === '1' || !nearViewport(host)) return;
    if (typeof THREE === 'undefined' || !THREE.GLTFLoader) {
      setLoading(spec,'تعذّر تحميل مكتبة المجسمات',false); return;
    }
    const data = (() => { try { return spec.data(); } catch (_) { return ''; } })();
    if (typeof data !== 'string' || !data) { setLoading(spec,'ملف المجسم غير متوفر',false); return; }
    const ctx = canvas.getContext('2d', { alpha:true });
    if (!ctx) { setLoading(spec,'تعذّر تجهيز المعاينة',false); return; }
    if (!ensureRenderer()) { setLoading(spec,'تعذّر تشغيل عرض 3D؛ تحقق من دعم WebGL',false); return; }
    host.dataset.previewStarted='1';
    host.dataset.previewState='loading';
    const loader = new THREE.GLTFLoader();
    try {
      loader.parse(decodeGLB(data),'', gltf => onModelLoaded(spec,host,canvas,ctx,gltf), error => {
        console.warn('Embedded model preview parse failed',spec.key,error);
        if (spec.embeddedFallback && typeof loader.load === 'function') {
          loader.load(spec.embeddedFallback,gltf=>onModelLoaded(spec,host,canvas,ctx,gltf),undefined,err=>setLoading(spec,'تعذّر تحميل المعاينة',false));
        } else setLoading(spec,'تعذّر تحميل المعاينة',false);
      });
    } catch (error) {
      console.warn('Model preview decode failed',spec.key,error);
      setLoading(spec,'تعذّر تحميل المعاينة',false);
    }
  }

  function refreshVisible() {
    if (!page.classList.contains('active') || document.hidden) return;
    for (const spec of specs) {
      const host = document.querySelector(spec.host);
      if (!host) continue;
      const r = state.records.get(spec.key);
      if (r) { r.visible = nearViewport(host); if (r.visible) draw(r); }
      else if (nearViewport(host)) start(spec);
    }
    scheduleLoop();
  }

  function stopLoop() {
    if (state.frame) cancelAnimationFrame(state.frame);
    state.frame = 0; state.last = 0;
  }
  function scheduleLoop() {
    const anyVisible = Array.from(state.records.values()).some(r => r.visible && r.canvas.isConnected);
    if (!page.classList.contains('active') || document.hidden || state.lost || !anyVisible) { stopLoop(); return; }
    if (!state.frame) state.frame = requestAnimationFrame(tick);
  }
  function tick(now) {
    state.frame = 0;
    if (!page.classList.contains('active') || document.hidden || state.lost) { state.last=0; return; }
    if (state.last && now-state.last < 40) { state.frame=requestAnimationFrame(tick); return; }
    const dt = state.last ? Math.min(0.08,(now-state.last)/1000) : 0.04;
    state.last=now;
    let anyVisible=false;
    for (const record of state.records.values()) {
      if (!record.canvas.isConnected) { disposeObject(record.root); state.records.delete(record.spec.key); continue; }
      record.visible=nearViewport(record.host);
      if (!record.visible) continue;
      anyVisible=true;
      record.root.rotation.y += Math.min(record.spec.speed,0.4) * dt;
      draw(record);
    }
    if (anyVisible) state.frame=requestAnimationFrame(tick); else state.last=0;
  }

  function setup() {
    if ('IntersectionObserver' in window) {
      state.observer = new IntersectionObserver(entries => {
        for (const entry of entries) {
          if (!entry.isIntersecting) {
            const record = state.records.get(entry.target.dataset.previewKey || '');
            if (record) record.visible=false;
            continue;
          }
          const spec=specs.find(x=>x.key===entry.target.dataset.previewKey || x.key===entry.target.dataset.preview);
          if (spec) start(spec);
        }
        scheduleLoop();
      }, { root:null, rootMargin:'180px 0px' });
      specs.forEach(spec => { const host=document.querySelector(spec.host); if(host) { host.dataset.previewKey=spec.key; state.observer.observe(host); } });
    }
    const refresh = () => {
      if (document.hidden || !page.classList.contains('active')) { stopLoop(); return; }
      refreshVisible();
      if (!state.observer) window.addEventListener('scroll',refreshVisible,{passive:true});
    };
    state.pageObserver = new MutationObserver(refresh);
    state.pageObserver.observe(page,{attributes:true,attributeFilter:['class']});
    document.addEventListener('visibilitychange',refresh);
    window.addEventListener('resize',refreshVisible,{passive:true});
    window.refreshAllModelPreviews = refreshVisible;
    window.refreshLighterThumbnail = refreshVisible;
    window.refreshCircuitThumbnail = refreshVisible;
    window.refreshJerrycanThumbnail = refreshVisible;
    window.refreshRifleThumbnail = window.refreshRifleThumbnail || refreshVisible;
    window.refreshBonnieThumbnail = refreshVisible;
    if (page.classList.contains('active')) refreshVisible();
  }

  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',setup,{once:true});
  else setup();
})();
