(function(){
  function start(){
    try{
      if(typeof ensureReleaseNotifications==='function') ensureReleaseNotifications();
      if(typeof showPendingReleaseNotifications==='function') showPendingReleaseNotifications();
    }catch(e){ console.warn('release notifier init failed', e); }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
