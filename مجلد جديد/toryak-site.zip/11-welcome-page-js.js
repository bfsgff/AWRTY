(function(){
  const page=document.getElementById('welcomePage');
  if(page) page.remove();
  document.body.classList.remove('welcome-open');
  const greetingNode=document.getElementById('welcomeGreeting');
  if(greetingNode) greetingNode.remove();
  // The user requested no welcome overlay or greeting animation.
  return;
  const card=page.querySelector('.welcome-card');
  const greeting=document.getElementById('welcomeGreeting');
  const screens=[1,2,3].map(i=>document.getElementById('welcomeScreen'+i));
  const storageKey='toryak-welcome-state-v2';
  const publishRequestsKey='toryak-content-requests';
  const langData={
    ar:{badge:'TORYAK WR • مساحة للإبداع والنشر',title:'مرحبًا بك في TORYAK WR',lead:'مكان تعرض فيه أفكارك ومشاريعك، من أول محاولة إلى العمل الذي تفتخر به.',sub:'نماذج ثلاثية الأبعاد، رسومات ورقية، رسم رقمي، فيديوهات، وروابط من YouTube وInstagram وTikTok. لا تحتاج أن تكون محترفًا حتى تبدأ.',newQ:'هل أنت مستخدم جديد؟',yes:'نعم، أنا جديد',no:'لا، أريد المتابعة',search:'بحث',placeholder:'ابحث عن أي نموذج أو مشروع...',start2:'بداية جديدة'},
    en:{badge:'TORYAK WR • A space to create and publish',title:'Welcome to TORYAK WR',lead:'A place to show your ideas and projects, from the first attempt to the work you are proud of.',sub:'3D models, paper drawings, digital art, videos, and links from YouTube, Instagram, and TikTok. You do not need to be a professional to begin.',newQ:'Are you a new user?',yes:'Yes, I am new',no:'No, continue',search:'Search',placeholder:'Search for any model or project...',start2:'A fresh start'},
    zh:{badge:'TORYAK WR • 创作与发布空间',title:'欢迎来到 TORYAK WR',lead:'这里可以展示你的想法和项目，从第一次尝试到你引以为傲的作品。',sub:'3D模型、纸上绘画、数字艺术、视频，以及来自 YouTube、Instagram 和 TikTok 的链接。无需成为专业人士也可以开始。',newQ:'你是新用户吗？',yes:'是，我是新用户',no:'不是，继续',search:'搜索',placeholder:'搜索模型或项目...',start2:'全新开始'},
    ur:{badge:'TORYAK WR • تخلیق اور اشاعت کی جگہ',title:'TORYAK WR میں خوش آمدید',lead:'یہ آپ کے خیالات اور منصوبوں کو دکھانے کی جگہ ہے، پہلی کوشش سے قابلِ فخر کام تک۔',sub:'3D ماڈلز، کاغذی ڈرائنگ، ڈیجیٹل آرٹ، ویڈیوز اور YouTube، Instagram اور TikTok کے لنکس۔ شروع کرنے کے لیے ماہر ہونا ضروری نہیں۔',newQ:'کیا آپ نئے صارف ہیں؟',yes:'ہاں، میں نیا ہوں',no:'نہیں، جاری رکھیں',search:'تلاش',placeholder:'کسی ماڈل یا پروجیکٹ کو تلاش کریں...',start2:'نئی شروعات'},
    fr:{badge:'TORYAK WR • Espace de création et de publication',title:'Bienvenue sur TORYAK WR',lead:'Un espace pour montrer vos idées et projets, de la première tentative au travail dont vous êtes fier.',sub:'Modèles 3D, dessins sur papier, art numérique, vidéos et liens YouTube, Instagram et TikTok. Pas besoin d’être professionnel pour commencer.',newQ:'Êtes-vous un nouvel utilisateur ?',yes:'Oui, je suis nouveau',no:'Non, continuer',search:'Rechercher',placeholder:'Rechercher un modèle ou un projet...',start2:'Nouveau départ'}
  };
  let activeLang='ar'; try { activeLang=localStorage.getItem('toryak-language')||'ar'; } catch (_) { activeLang='ar'; }
  function showScreen(n){screens.forEach((s,i)=>s?.classList.toggle('active',i===n-1)); card?.scrollTo({top:0,behavior:'smooth'});}
  function closeWelcome(){page.classList.add('closing');setTimeout(()=>{page.classList.add('hidden');page.classList.remove('closing');document.body.classList.remove('welcome-open');},520);}
  function welcomeGreeting(){
    if(!greeting)return; greeting.textContent=(langData[activeLang]||langData.ar).start2==='A fresh start'?'Welcome to TORYAK WR':'مرحبًا بك في TORYAK WR';
    greeting.classList.add('show'); setTimeout(()=>greeting.classList.remove('show'),2200);
  }
  function applyLang(code){
    activeLang=langData[code]?code:'ar'; const d=langData[activeLang];
    const rtl=activeLang==='ar'||activeLang==='ur'; page.dir=rtl?'rtl':'ltr'; document.documentElement.dir=rtl?'rtl':'ltr';
    const ids=[['welcomeBadge','badge'],['welcomeTitle','title'],['welcomeLead','lead'],['welcomeSub','sub'],['welcomeNewQuestion','newQ'],['welcomeNewYes','yes'],['welcomeNewNo','no']];
    ids.forEach(([id,k])=>{const el=document.getElementById(id);if(el)el.textContent=d[k];});
    const s=document.getElementById('welcomeSearchInput'); if(s){s.placeholder=d.placeholder;s.setAttribute('aria-label',d.placeholder)}
    const sb=document.getElementById('welcomeSearchBtn');if(sb)sb.textContent=d.search;
  }
  function saveFirstVisit(state){try{localStorage.setItem(storageKey,state)}catch(_){}
  }
  function openStudioForUpload(){
    closeWelcome();
    setTimeout(()=>{
      const btn=document.getElementById('openStudioBtn'); if(btn) btn.click();
      setTimeout(()=>document.getElementById('fileInput')?.click(),260);
    },560);
  }
  function saveContentRequest(type,url){
    let list=[];
    try { const stored=JSON.parse(localStorage.getItem(publishRequestsKey)||'[]'); if(Array.isArray(stored)) list=stored; } catch (_) { list=[]; }
    list.push({id:Date.now(),type,url,createdAt:new Date().toISOString()});
    try{localStorage.setItem(publishRequestsKey,JSON.stringify(list.slice(-100)))}catch(_){}
    try{window.projectToast?.('تم حفظ محتوى '+type)}catch(_){}
  }
  function pickSocial(type){
    const row=document.getElementById('welcomeSocialRow'); const input=document.getElementById('welcomeSocialUrl');
    if(row){row.style.display='flex';row.dataset.type=type;} if(input){input.placeholder='رابط '+type+' هنا';input.focus();}
  }

  document.getElementById('welcomeNewYes')?.addEventListener('click',()=>{
    saveFirstVisit('new'); showScreen(2); setTimeout(()=>{closeWelcome();setTimeout(()=>{welcomeGreeting();setTimeout(()=>{page.classList.remove('hidden');page.classList.remove('closing');document.body.classList.add('welcome-open');showScreen(2);},2350)},560)},120);
  });
  document.getElementById('welcomeNewNo')?.addEventListener('click',()=>{saveFirstVisit('returning');closeWelcome();});
  document.getElementById('welcomePublishYes')?.addEventListener('click',()=>showScreen(3));
  document.getElementById('welcomePublishNo')?.addEventListener('click',()=>{saveFirstVisit('new-exploring');closeWelcome();});
  document.getElementById('welcomeBackToHome')?.addEventListener('click',()=>closeWelcome());
  document.getElementById('welcomeType3D')?.addEventListener('click',openStudioForUpload);
  document.getElementById('welcomeTypePaper')?.addEventListener('click',()=>document.getElementById('welcomeImageFile')?.click());
  document.getElementById('welcomeTypeDigital')?.addEventListener('click',()=>document.getElementById('welcomeImageFile')?.click());
  document.getElementById('welcomeImageFile')?.addEventListener('change',e=>{if(e.target.files?.length){closeWelcome(); try{window.projectToast?.('تم اختيار الصورة، يمكنك متابعة نشرها من الموقع.')}catch(_){} }});
  document.getElementById('welcomeTypeYouTube')?.addEventListener('click',()=>pickSocial('YouTube'));
  document.getElementById('welcomeTypeInstagram')?.addEventListener('click',()=>pickSocial('Instagram'));
  document.getElementById('welcomeTypeTikTok')?.addEventListener('click',()=>pickSocial('TikTok'));
  document.getElementById('welcomeSocialSave')?.addEventListener('click',()=>{
    const input=document.getElementById('welcomeSocialUrl'), row=document.getElementById('welcomeSocialRow'); const url=(input?.value||'').trim(); const type=row?.dataset.type||'محتوى';
    if(!url){input?.focus();return;} saveContentRequest(type,url); if(input)input.value=''; closeWelcome();
  });
  document.getElementById('welcomeSearchBtn')?.addEventListener('click',()=>{const q=document.getElementById('welcomeSearchInput')?.value.trim()||'';closeWelcome();const main=document.getElementById('mainSearchBox');if(main){main.value=q;window.showModelsPage?.(q,true);}});
  document.getElementById('welcomeSearchInput')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();document.getElementById('welcomeSearchBtn')?.click();}});

  const initial=langData[activeLang]?activeLang:'ar'; applyLang(initial); document.body.classList.add('welcome-open');
  const original=window.setSiteLanguage;
  if(typeof original==='function'&&!window.__welcomeLanguageWrapped2){window.setSiteLanguage=function(target){original(target);applyLang(target);};window.__welcomeLanguageWrapped2=true;}
  // لا نظهر صفحة الترحيب إلا في أول زيارة أو بعد مسح تفضيلها.
  let seen=''; try{seen=localStorage.getItem(storageKey)||''}catch(_){}
  if(seen){page.classList.add('hidden');document.body.classList.remove('welcome-open');}
})();
