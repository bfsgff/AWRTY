/* TORYAK WR — unified project/model viewer
   Same visual layout as the original Explore page, used for built-in and published models. */
(function(){
  const modal = document.getElementById('exploreModal');
  const box = modal?.querySelector('.explore-box');
  const head = modal?.querySelector('.explore-head');
  const actions = modal?.querySelector('.explore-actions');
  const titleInput = document.getElementById('exploreTitle');
  const closeBtn = document.getElementById('exploreClose');
  const resetBtn = document.getElementById('exploreReset');
  const downloadBtn = document.getElementById('exploreDownload');
  const fullscreenBtn = document.getElementById('exploreFullscreen');
  const colorInput = document.getElementById('exploreColor');
  const stage = document.getElementById('exploreStage');
  const canvas = document.getElementById('exploreCanvas');
  const loading = document.getElementById('exploreLoading');
  const loadingText = document.getElementById('exploreLoadingText');
  const materialsBar = document.getElementById('exploreMaterials');
  const materialsLabel = modal?.querySelector('.explore-materials-label');
  const playBtn = document.getElementById('explorePlay');
  if(!modal || !box || !stage || !canvas || typeof THREE==='undefined' || typeof THREE.GLTFLoader==='undefined') return;

  const LANG={
    ar:{reviews:'تقييم وتعليقات',rating:'تقييم المشروع',noRating:'لا يوجد تقييم بعد',comments:'التعليقات',placeholder:'اكتب تعليقك...',post:'نشر التعليق',close:'إغلاق',fullscreen:'⛶ ملء الشاشة',exitFullscreen:'⛶ خروج من ملء الشاشة',explode:'تفكيك',assemble:'تجميع',reset:'↺ إعادة ضبط',day:'نهار',night:'ليل',light:'الإضاءة',names:'أسماء القطع',hideNames:'إخفاء أسماء القطع',none:'لا توجد تعليقات بعد',view:'عرض ثلاثي الأبعاد',loading:'جارٍ تحميل النموذج ثلاثي الأبعاد...',ready:'عرض ثلاثي الأبعاد',downloaded:'تم تحميل المجسم',error:'تعذر تحميل المجسم'},
    en:{reviews:'Reviews & comments',rating:'Project rating',noRating:'No ratings yet',comments:'Comments',placeholder:'Write your comment...',post:'Post comment',close:'Close',fullscreen:'⛶ Fullscreen',exitFullscreen:'⛶ Exit fullscreen',explode:'Explode',assemble:'Assemble',reset:'↺ Reset',day:'Day',night:'Night',light:'Lighting',names:'Part names',hideNames:'Hide part names',none:'No comments yet',view:'3D View',loading:'Loading 3D model...',ready:'3D View',downloaded:'Model downloaded',error:'Could not load model'},
    zh:{reviews:'评分与评论',rating:'项目评分',noRating:'暂无评分',comments:'评论',placeholder:'写下评论...',post:'发布评论',close:'关闭',fullscreen:'⛶ 全屏',exitFullscreen:'⛶ 退出全屏',explode:'拆解',assemble:'组装',reset:'↺ 重置',day:'白天',night:'夜间',light:'灯光',names:'部件名称',hideNames:'隐藏部件名称',none:'暂无评论',view:'3D 视图',loading:'正在加载 3D 模型...',ready:'3D 视图',downloaded:'模型已下载',error:'无法加载模型'},
    ur:{reviews:'ریٹنگ اور تبصرے',rating:'پروجیکٹ ریٹنگ',noRating:'ابھی کوئی ریٹنگ نہیں',comments:'تبصرے',placeholder:'تبصرہ لکھیں...',post:'تبصرہ شائع کریں',close:'بند کریں',fullscreen:'⛶ پوری اسکرین',exitFullscreen:'⛶ پوری اسکرین سے باہر',explode:'جدا کریں',assemble:'جوڑیں',reset:'↺ ری سیٹ',day:'دن',night:'رات',light:'روشنی',names:'حصوں کے نام',hideNames:'حصوں کے نام چھپائیں',none:'ابھی کوئی تبصرہ نہیں',view:'3D منظر',loading:'3D ماڈل لوڈ ہو رہا ہے...',ready:'3D منظر',downloaded:'ماڈل ڈاؤن لوڈ ہو گیا',error:'ماڈل لوڈ نہیں ہو سکا'},
    fr:{reviews:'Avis et commentaires',rating:'Note du projet',noRating:'Aucune note',comments:'Commentaires',placeholder:'Écrivez un commentaire...',post:'Publier',close:'Fermer',fullscreen:'⛶ Plein écran',exitFullscreen:'⛶ Quitter le plein écran',explode:'Démonter',assemble:'Assembler',reset:'↺ Réinitialiser',day:'Jour',night:'Nuit',light:'Lumière',names:'Noms des pièces',hideNames:'Masquer les noms',none:'Aucun commentaire',view:'Vue 3D',loading:'Chargement du modèle 3D...',ready:'Vue 3D',downloaded:'Modèle téléchargé',error:'Impossible de charger le modèle'}
  };
  const getLang=()=>{try{return localStorage.getItem('toryak-language')||'ar';}catch(_){return 'ar';}};
  const tt=k=>(LANG[getLang()]||LANG.ar)[k]||LANG.ar[k]||k;

  // نموذج بندقية مضاف للموقع — للعرض ثلاثي الأبعاد فقط.

  const MODEL_DATA={};

  let scene=null,camera=null,renderer=null,model=null,mixer=null,actionsList=[];
  let currentRecord=null,currentId=null,currentBuiltInKey=null;
  let originalMaterials=[],meshStates=[],retiredMeshes=[];
  let selectedMesh=null;
  let yaw=-0.58,pitch=0.07,distance=4.4,panX=0,panY=0;
  let dragging=false,rotating=false,panning=false,lastX=0,lastY=0,exploded=false;
  let pointerDownX=0,pointerDownY=0,pointerDidMove=false;
  let frameId=0,lastTime=performance.now();
  let displayPlaying=false;
  let reviewPanel=null,reviewsButton=null,lightPanel=null,lightButton=null;
  let namesButton=null,namesEnabled=false,partTooltip=null,partLabels=[];
  let viewerToolbar=null;
  function isCurrentCharacter(){
    const record=currentRecord||{};
    const text=(String(record.name||'')+' '+String(record.description||'')).toLowerCase();
    const hints=/(human|person|people|character|\bman\b|\bwoman\b|\bboy\b|\bgirl\b|avatar|mixamo|شخص|إنسان|انسان|بشري|شخصية|رجل|امرأة|امراة|ولد|بنت)/i;
    const rigged=!!(model&&model.getObjectByProperty('type','SkinnedMesh'))||!!(actionsList&&actionsList.length);
    return !!(record.isCharacter||record.hasAnimation||rigged||hints.test(text));
  }
  function updateViewerExplodeControls(){
    if(!viewerToolbar)return;
    const hide=isCurrentCharacter();
    viewerToolbar.querySelectorAll('[data-viewer-action="explode"],[data-viewer-action="assemble"]').forEach(button=>{button.style.display=hide?'none':'';});
  }
  function startViewerMotion(){
    if(!model)return;
    displayPlaying=true;
    if(mixer&&actionsList.length){
      actionsList.forEach(action=>{action.reset();action.enabled=true;action.setLoop(THREE.LoopRepeat,Infinity);action.clampWhenFinished=false;action.play();});
    }
    if(playBtn){playBtn.textContent='⏸ إيقاف';playBtn.disabled=false;playBtn.style.opacity='1';}
    render();
  }
  const partRaycaster=new THREE.Raycaster(); const partPointer=new THREE.Vector2();

  function ensureRenderer(){
    const w=Math.max(1,stage.clientWidth||760),h=Math.max(1,stage.clientHeight||500);
    if(!renderer){
      renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,preserveDrawingBuffer:false,powerPreference:'high-performance'});
      renderer.outputEncoding=THREE.sRGBEncoding;
      renderer.toneMapping=THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure=1.15;
      renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));
    }
    renderer.setSize(w,h,false);
    if(!camera) camera=new THREE.PerspectiveCamera(34,w/h,.01,120); else {camera.aspect=w/h;camera.updateProjectionMatrix();}
  }
  function makeScene(){
    ensureRenderer();
    if(scene) scene.clear();
    scene=new THREE.Scene();
    const hemi=new THREE.HemisphereLight(0xffffff,0x111722,1.15); hemi.name='hemi'; scene.add(hemi);
    const key=new THREE.DirectionalLight(0xffffff,2.2); key.position.set(4,5,6); key.name='key'; scene.add(key);
    const fill=new THREE.DirectionalLight(0x8bb8ff,.75); fill.position.set(-4,2,3); fill.name='fill'; scene.add(fill);
    const rim=new THREE.DirectionalLight(0xff71d8,1.0); rim.position.set(2,3,-4); rim.name='rim'; scene.add(rim);
    canvas.style.visibility='visible';
  }
  function lights(){return {key:scene?.getObjectByName('key'),fill:scene?.getObjectByName('fill'),rim:scene?.getObjectByName('rim'),hemi:scene?.getObjectByName('hemi')};}
  function setLoading(msg,show=true){if(!loading||!loadingText)return;loadingText.textContent=msg||'';loading.classList.toggle('hidden',!show);}
  function normalizeColors(){
    originalMaterials=[]; selectedMesh=null; if(!model)return;
    // Give each mesh its own material instances. This makes per-part colour edits
    // work even when a GLTF reuses the same material object across several meshes.
    model.traverse(o=>{
      if(!o.isMesh||!o.material)return;
      const wasArray=Array.isArray(o.material);
      const sourceMats=wasArray?o.material:[o.material];
      const ownMats=sourceMats.map(mat=>mat&&mat.clone?mat.clone():mat);
      o.material=wasArray?ownMats:ownMats[0];
      ownMats.forEach((mat,materialIndex)=>{
        if(!mat)return;
        originalMaterials.push({mesh:o,materialIndex,mat,color:mat.color?.clone?.()||null,metalness:typeof mat.metalness==='number'?mat.metalness:null,roughness:typeof mat.roughness==='number'?mat.roughness:null,opacity:typeof mat.opacity==='number'?mat.opacity:null,transparent:!!mat.transparent,map:mat.map||null,emissive:mat.emissive?.clone?.()||null});
      });
    });
    updateColorTargetLabel();
  }
  function restoreColors(){
    originalMaterials.forEach(s=>{if(!s.mat)return;if(s.color&&s.mat.color)s.mat.color.copy(s.color);if(s.emissive&&s.mat.emissive)s.mat.emissive.copy(s.emissive);if(s.metalness!==null&&'metalness'in s.mat)s.mat.metalness=s.metalness;if(s.roughness!==null&&'roughness'in s.mat)s.mat.roughness=s.roughness;if(s.opacity!==null&&'opacity'in s.mat)s.mat.opacity=s.opacity;if('transparent'in s.mat)s.mat.transparent=s.transparent;s.mat.needsUpdate=true;});
    selectedMesh=null;
    const first=originalMaterials.find(s=>s.color);if(first?.color&&colorInput)colorInput.value='#'+first.color.getHexString();
    document.querySelectorAll('.explore-color-swatch').forEach(b=>b.classList.remove('active'));
    updateColorTargetLabel();render();
  }
  function updateColorTargetLabel(){
    if(!materialsLabel)return;
    const lang=getLang();
    if(selectedMesh){
      const name=getPartName(selectedMesh,0);
      materialsLabel.textContent=lang==='en'?`Color part: ${name}`:lang==='zh'?`部件颜色：${name}`:lang==='fr'?`Couleur de pièce : ${name}`:lang==='ur'?`حصے کا رنگ: ${name}`:`لون الجزء: ${name}`;
    }else{
      materialsLabel.textContent=lang==='en'?'Colors (click a part to colour it)':lang==='zh'?'颜色（点击部件进行着色）':lang==='fr'?'Couleurs (cliquez une pièce) ':lang==='ur'?'رنگ (حصے کو منتخب کرنے کے لیے کلک کریں)':'الألوان (انقر على جزء لتلوينه)';
    }
  }
  function applyColor(hex){
    if(!model)return;
    const c=new THREE.Color(hex);
    const targets=[];
    if(selectedMesh&&model.getObjectById(selectedMesh.id)===selectedMesh)targets.push(selectedMesh);
    else model.traverse(o=>{if(o.isMesh)targets.push(o);});
    let applied=0;
    targets.forEach(mesh=>{
      if(!mesh.material)return;
      const mats=Array.isArray(mesh.material)?mesh.material:[mesh.material];
      mats.forEach(mat=>{if(mat?.color?.copy){mat.color.copy(c);mat.needsUpdate=true;applied++;}});
    });
    if(!applied && materialsLabel) materialsLabel.textContent=getLang()==='en'?'This part has no editable colour material':'هذا الجزء لا يحتوي على خامة قابلة لتغيير اللون';
    render();
  }
  function getVisibleModelBounds(object3d){
    const bounds=new THREE.Box3();let count=0;
    object3d.updateMatrixWorld(true);
    object3d.traverse(node=>{
      if(!node.isMesh||!node.geometry)return;
      let visible=true;
      for(let parent=node;parent;parent=parent.parent){if(parent.visible===false){visible=false;break;}if(parent===object3d)break;}
      if(!visible)return;
      if(!node.geometry.boundingBox)node.geometry.computeBoundingBox?.();
      const meshBounds=new THREE.Box3().setFromObject(node);
      if(![meshBounds.min.x,meshBounds.min.y,meshBounds.min.z,meshBounds.max.x,meshBounds.max.y,meshBounds.max.z].every(Number.isFinite))return;
      bounds.union(meshBounds);count++;
    });
    if(!count||bounds.isEmpty())return null;
    return bounds;
  }
  function fitModel(){
    if(!model)return false;
    const bounds=getVisibleModelBounds(model);
    if(!bounds)return false;
    const size=bounds.getSize(new THREE.Vector3());
    const center=bounds.getCenter(new THREE.Vector3());
    const max=Math.max(size.x,size.y,size.z);
    if(!Number.isFinite(max)||max<=1e-9)return false;
    const factor=2.25/max;
    // model is a wrapper around the original GLTF hierarchy. Uniformly scale its
    // existing transform and shift by the measured world center without erasing
    // transforms authored by Blender or another 3D editor.
    model.position.sub(center).multiplyScalar(factor);
    model.scale.multiplyScalar(factor);
    model.updateMatrixWorld(true);
    const fittedBounds=getVisibleModelBounds(model);
    const sphere=new THREE.Sphere();(fittedBounds||new THREE.Box3().setFromObject(model)).getBoundingSphere(sphere);
    const radius=Math.max(.01,sphere.radius);
    const verticalFov=THREE.MathUtils.degToRad(camera.fov);
    distance=Math.max(radius*2.1,radius/Math.sin(verticalFov/2)*1.12);
    yaw=-0.58;pitch=0.07;panX=0;panY=0;
    return true;
  }
  function captureMeshStates(){
    meshStates=[];if(!model)return;
    model.updateMatrixWorld(true);
    const centerBox=new THREE.Box3().setFromObject(model);
    const modelCenter=centerBox.getCenter(new THREE.Vector3());
    let i=0;
    model.traverse(o=>{
      if(!o.isMesh)return;
      const worldBox=new THREE.Box3().setFromObject(o);
      const worldCenter=worldBox.getCenter(new THREE.Vector3());
      let worldDir=worldCenter.clone().sub(modelCenter);
      if(worldDir.lengthSq()<1e-6){const a=i+1;worldDir.set(Math.sin(a*2.13),.35+Math.abs(Math.cos(a*1.37)),Math.cos(a*1.71));}
      worldDir.normalize();
      // Convert the world-space direction into this mesh parent's local space.
      let dir=worldDir.clone();
      if(o.parent){o.parent.updateMatrixWorld(true);const p0=o.parent.worldToLocal(worldCenter.clone());const p1=o.parent.worldToLocal(worldCenter.clone().add(worldDir));dir=p1.sub(p0);}
      if(dir.lengthSq()<1e-8)dir.set(1,.4,.7);
      dir.normalize();
      meshStates.push({mesh:o,pos:o.position.clone(),dir,i:i++});
    });
  }
  function getAttributeComponent(attr,index,component){
    if(component===0)return attr.getX(index);
    if(component===1)return attr.getY(index);
    if(component===2)return attr.getZ(index);
    if(component===3)return attr.getW(index);
    return attr.array[index*attr.itemSize+component];
  }
  function buildMeshFragments(sourceMesh){
    const geometry=sourceMesh?.geometry;
    const position=geometry?.getAttribute?.('position');
    if(!geometry||!position)return [];
    const index=geometry.index;
    const elementCount=index?index.count:position.count;
    const triangleCount=Math.floor(elementCount/3);
    if(triangleCount<12||triangleCount>40000)return [];
    geometry.computeBoundingBox();
    const bounds=geometry.boundingBox;
    if(!bounds)return [];
    const size=bounds.getSize(new THREE.Vector3());
    const denominator=new THREE.Vector3(Math.max(size.x,1e-7),Math.max(size.y,1e-7),Math.max(size.z,1e-7));
    const bins=new Map();
    const groups=geometry.groups||[];
    const materialForTriangle=offset=>{const g=groups.find(x=>offset>=x.start&&offset<x.start+x.count);return g?g.materialIndex:0;};
    const getVertex=(offset)=>index?index.getX(offset):offset;
    const grid=4;
    for(let tri=0;tri<triangleCount;tri++){
      const off=tri*3, ids=[getVertex(off),getVertex(off+1),getVertex(off+2)];
      const cx=(position.getX(ids[0])+position.getX(ids[1])+position.getX(ids[2]))/3;
      const cy=(position.getY(ids[0])+position.getY(ids[1])+position.getY(ids[2]))/3;
      const cz=(position.getZ(ids[0])+position.getZ(ids[1])+position.getZ(ids[2]))/3;
      const bx=Math.min(grid-1,Math.max(0,Math.floor(((cx-bounds.min.x)/denominator.x)*grid)));
      const by=Math.min(grid-1,Math.max(0,Math.floor(((cy-bounds.min.y)/denominator.y)*grid)));
      const bz=Math.min(grid-1,Math.max(0,Math.floor(((cz-bounds.min.z)/denominator.z)*grid)));
      const key=`${bx},${by},${bz}`;
      if(!bins.has(key))bins.set(key,[]);
      bins.get(key).push({ids,materialIndex:materialForTriangle(off)});
    }
    if(bins.size<2)return [];
    const attributes=Object.entries(geometry.attributes||{}).filter(([name,attr])=>attr&&attr.itemSize&&typeof attr.getX==='function'&&!/^(skinIndex|skinWeight|instanceMatrix|instanceColor)$/i.test(name));
    const pieces=[];
    for(const triangles of bins.values()){
      if(!triangles.length)continue;
      const fragGeometry=new THREE.BufferGeometry();
      for(const [name,attr] of attributes){
        const data=[];
        triangles.forEach(tri=>tri.ids.forEach(vertex=>{for(let c=0;c<attr.itemSize;c++)data.push(getAttributeComponent(attr,vertex,c));}));
        fragGeometry.setAttribute(name,new THREE.Float32BufferAttribute(data,attr.itemSize));
      }
      // Preserve material-index groups for models that use more than one material.
      if(Array.isArray(sourceMesh.material)&&sourceMesh.material.length>1){
        let start=0,last=triangles[0].materialIndex;
        for(let t=1;t<triangles.length;t++){
          if(triangles[t].materialIndex!==last){fragGeometry.addGroup(start,t*3-start,last);start=t*3;last=triangles[t].materialIndex;}
        }
        fragGeometry.addGroup(start,triangles.length*3-start,last);
      }
      if(!fragGeometry.getAttribute('normal'))fragGeometry.computeVertexNormals();
      fragGeometry.computeBoundingBox();fragGeometry.computeBoundingSphere();
      const sourceMats=Array.isArray(sourceMesh.material)?sourceMesh.material:[sourceMesh.material];
      const materials=sourceMats.map(mat=>mat&&mat.clone?mat.clone():mat);
      const piece=new THREE.Mesh(fragGeometry,Array.isArray(sourceMesh.material)?materials:materials[0]);
      piece.name=(sourceMesh.name||'Model')+'_fragment_'+pieces.length;
      piece.castShadow=sourceMesh.castShadow;piece.receiveShadow=sourceMesh.receiveShadow;piece.renderOrder=sourceMesh.renderOrder;
      piece.position.set(0,0,0);piece.rotation.set(0,0,0);piece.scale.set(1,1,1);
      pieces.push(piece);
    }
    return pieces;
  }
  function splitSingleMeshForExplode(){
    if(!model)return false;
    const meshes=[];model.traverse(o=>{if(o.isMesh)meshes.push(o);});
    if(meshes.length!==1)return meshes.length>1;
    const sourceMesh=meshes[0];
    const pieces=buildMeshFragments(sourceMesh);
    if(pieces.length<2)return false;
    const parent=sourceMesh.parent;
    if(!parent)return false;
    const index=parent.children.indexOf(sourceMesh);
    const group=new THREE.Group();group.name=(sourceMesh.name||'Model')+'_exploded_parts';
    group.position.copy(sourceMesh.position);group.quaternion.copy(sourceMesh.quaternion);group.scale.copy(sourceMesh.scale);group.visible=sourceMesh.visible;group.renderOrder=sourceMesh.renderOrder;
    // Keep any non-mesh children attached to the same transform.
    [...sourceMesh.children].forEach(child=>group.add(child));
    parent.remove(sourceMesh);parent.add(group);
    const groupIndex=parent.children.indexOf(group);parent.children.splice(groupIndex,1);parent.children.splice(Math.min(index,parent.children.length),0,group);group.parent=parent;
    pieces.forEach(piece=>group.add(piece));
    retiredMeshes.push(sourceMesh);
    model.updateMatrixWorld(true);
    normalizeColors();captureMeshStates();
    return meshStates.length>1;
  }
  let explodeAnimFrame=0;
  function setExplode(on){
    if(!model)return;
    if(on&&meshStates.length<=1&&!splitSingleMeshForExplode()){
      if(materialsLabel)materialsLabel.textContent=getLang()==='en'?'This model cannot be split into separate pieces':'تعذّر تقسيم هذا المجسم إلى أجزاء';
      return;
    }
    if(!meshStates.length)captureMeshStates();
    exploded=!!on;
    if(explodeAnimFrame)cancelAnimationFrame(explodeAnimFrame);
    const start=performance.now(),duration=760;
    const modelScale=Math.max(.001,Math.max(Math.abs(model.scale.x),Math.abs(model.scale.y),Math.abs(model.scale.z)));
    const amount=exploded?(meshStates.length>24?0.72:0.58)/modelScale:0;
    const starts=meshStates.map(s=>s.mesh.position.clone());
    if(exploded)distance=Math.max(distance,4.8);
    const ease=t=>t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;
    const step=now=>{
      const t=Math.min(1,(now-start)/duration),e=ease(t);
      meshStates.forEach((st,i)=>{const target=st.pos.clone().addScaledVector(st.dir,amount);st.mesh.position.lerpVectors(starts[i],target,e);});
      render();
      if(t<1)explodeAnimFrame=requestAnimationFrame(step);else explodeAnimFrame=0;
    };
    explodeAnimFrame=requestAnimationFrame(step);
  }
  function disposeModel(){
    if(model&&scene){scene.remove(model);model.traverse(o=>{if(o.isMesh){o.geometry?.dispose?.();const ms=Array.isArray(o.material)?o.material:[o.material];ms.forEach(m=>m?.dispose?.());}});}
    retiredMeshes.forEach(o=>{o.geometry?.dispose?.();const ms=Array.isArray(o.material)?o.material:[o.material];ms.forEach(m=>m?.dispose?.());});
    retiredMeshes=[];model=null;selectedMesh=null;originalMaterials=[];meshStates=[];mixer=null;actionsList=[];
  }
  async function sourceToBuffer(source){
    if(source?.arrayBuffer)return await source.arrayBuffer();
    if(typeof source==='string'&&source.startsWith('data:')){
      const comma=source.indexOf(',');if(comma<0)throw new Error('Invalid embedded model data');
      const binary=atob(source.slice(comma+1));const bytes=new Uint8Array(binary.length);
      for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
      return bytes.buffer;
    }
    if(typeof source==='string')return await fetch(source).then(r=>{if(!r.ok)throw new Error('Model fetch failed: '+r.status);return r.arrayBuffer();});
    throw new Error('Invalid model source');
  }
  function setAnimation(gltf){
    mixer=null;actionsList=[];
    if(gltf?.animations?.length&&model){
      mixer=new THREE.AnimationMixer(model);
      actionsList=gltf.animations.map(c=>{const a=mixer.clipAction(c);a.setLoop(THREE.LoopOnce,1);a.clampWhenFinished=true;return a;});
      mixer.addEventListener('finished',()=>{displayPlaying=false;if(playBtn)playBtn.textContent='▶ تشغيل';render();});
      // Bonnie's supplied GLB includes a rigged PoseLib clip. Sample it once and hold the pose by default.
      if(currentBuiltInKey==='bonnie' && actionsList.length){
        actionsList.forEach(a=>{a.reset();a.play();});
        mixer.update(Math.min(0.05, Math.max(0.001, (gltf.animations[0].duration||0.067)*0.75)));
        actionsList.forEach(a=>{a.paused=true;});
        displayPlaying=false;
      }
    }
    if(playBtn){playBtn.textContent='▶ تشغيل';playBtn.disabled=false;playBtn.style.opacity='1';}
  }
  function install(gltf){
    disposeModel();
    const sourceModel=gltf.scene||gltf.scenes?.[0]||gltf;
    if(!sourceModel||!sourceModel.traverse)throw new Error('ملف GLB لا يحتوي مجسماً قابلاً للعرض.');
    sourceModel.updateMatrixWorld(true);
    const sourceBounds=getVisibleModelBounds(sourceModel);
    if(!sourceBounds)throw new Error('ملف GLB لا يحتوي أجزاء ظاهرة قابلة للعرض.');
    // Keep every original node transform inside this wrapper. Resetting the source
    // scene scale/position made some Blender GLBs appear tiny or off-center.
    model=new THREE.Group();
    model.name='TORYAKViewerModelRoot';
    model.add(sourceModel);
    model.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;const mats=Array.isArray(o.material)?o.material:[o.material];mats.forEach(m=>{if(m&&'flatShading'in m){m.flatShading=false;m.needsUpdate=true;}});try{o.geometry?.computeVertexNormals?.();}catch(_){} }});
    scene.add(model);
    if(!fitModel())throw new Error('Invalid model bounds');
    captureMeshStates();normalizeColors();setAnimation(gltf);updateViewerExplodeControls();if(namesEnabled)buildPartLabels();render();setLoading('',false);
  }
  async function loadRecord(record){
    setLoading(tt('loading'),true);disposeModel();makeScene();resize();
    const loader=new THREE.GLTFLoader();
    const applySource=async source=>{
      let gltf;
      if(typeof source==='string' && /^(?:\.\/)?models\//i.test(source)){
        gltf=await new Promise((resolve,reject)=>loader.load(source,resolve,undefined,reject));
      }else{
        const buffer=await sourceToBuffer(source);
        gltf=await new Promise((resolve,reject)=>loader.parse(buffer,'',resolve,reject));
      }
      install(gltf);
    };
    try{
      const source=record?.modelBlob || record?.source;
      try{
        await applySource(source);
      }catch(primaryError){
        const fallback=currentBuiltInKey && MODEL_DATA[currentBuiltInKey]?.fallbackSource;
        if(!fallback || source===fallback) throw primaryError;
        console.warn('Embedded model load failed; retrying original GLTF files.',currentBuiltInKey,primaryError);
        disposeModel();
        await applySource(fallback);
      }
      statusText(tt('ready'));setLoading('',false);
    }catch(err){
      console.error('Unified viewer load failed',currentBuiltInKey||record?.id,err);
      const msg=(err && (err.message||err.name)) ? String(err.message||err.name) : 'Unknown loading error';
      setLoading(tt('error')+' — '+msg,true);statusText(tt('error'));
    }
  }
  function statusText(v){const s=modal.querySelector('.explore-viewer-status');if(s)s.textContent=v||'';}
  function currentName(record){const l=getLang();return l==='en'?(record.nameEn||record.name||'3D Project'):(record.name||record.nameEn||'مشروع 3D');}
  async function openViewer(input, options={}){
    currentRecord=null;currentId=null;currentBuiltInKey=null;
    if(typeof input==='string'&&MODEL_DATA[input]){currentBuiltInKey=input;const d=MODEL_DATA[input];currentRecord={id:'builtin:'+input,name:d.name,nameEn:d.nameEn,description:d.description,fileName:d.fileName,source:d.source()};}
    else if(input&&input.modelBlob){currentRecord=input;currentId=input.id;}
    else if(typeof input==='number'||(typeof input==='string'&&/^\d+$/.test(input))){const rec=await window.__toryakGetPublishedProjectRecord?.(Number(input));if(!rec||!rec.modelBlob){setLoading(tt('error'),true);return;}currentRecord=rec;currentId=rec.id;}
    else return;
    buildExtraUI();
    titleInput.value=currentName(currentRecord);
    modal.classList.add('active');modal.setAttribute('aria-hidden','false');
    resize();resetViewerState();await loadRecord(currentRecord);updateViewerExplodeControls();
    if(model){
      if(options&&options.explode&&!isCurrentCharacter())setExplode(true);
      startViewerMotion();
    }
    renderReviews();
  }
  function resetViewerState(){yaw=-.58;pitch=.07;panX=0;panY=0;exploded=false;displayPlaying=false;selectedMesh=null;updateColorTargetLabel();if(mixer)actionsList.forEach(a=>a.stop());if(playBtn){playBtn.textContent='▶ تشغيل';}setExplode(false);}
  function resize(){if(!renderer||!camera)return;ensureRenderer();render();}
  function render(){if(!renderer||!camera||!scene||!modal.classList.contains('active'))return;const cp=Math.cos(pitch),sp=Math.sin(pitch),cy=Math.cos(yaw),sy=Math.sin(yaw);const target=new THREE.Vector3(panX,panY,0);camera.position.set(target.x+distance*cp*sy,target.y+distance*sp,target.z+distance*cp*cy);camera.lookAt(target);renderer.render(scene,camera);if(namesEnabled)updatePartLabels();}
  function setDay(){const l=lights();if(!l.key)return;l.hemi.intensity=1.15;l.key.intensity=2.2;l.fill.intensity=.75;l.rim.intensity=1.0;l.key.color.set(0xffffff);l.fill.color.set(0x8bb8ff);l.rim.color.set(0xff71d8);}
  function setNight(){const l=lights();if(!l.key)return;l.hemi.intensity=.28;l.key.intensity=.55;l.fill.intensity=.22;l.rim.intensity=1.55;l.key.color.set(0x8297ff);l.fill.color.set(0x4268ff);l.rim.color.set(0xff55cc);}
  function getPartName(mesh,index){
    let n='';
    let cur=mesh;
    while(cur){ if(cur.name&&String(cur.name).trim()){n=String(cur.name).trim();break;} cur=cur.parent; }
    if(!n && mesh.material?.name) n=String(mesh.material.name).trim();
    if(!n) n=getLang()==='en'?`Part ${index+1}`:getLang()==='zh'?`部件 ${index+1}`:getLang()==='ur'?`حصہ ${index+1}`:getLang()==='fr'?`Pièce ${index+1}`:`قطعة ${index+1}`;
    return n.replace(/^(Object|Mesh|Group|Node)[_\- ]*/i,'').trim() || n;
  }
  function clearPartLabels(){partLabels.forEach(el=>el.remove());partLabels=[];}
  function buildPartLabels(){
    clearPartLabels();
    if(!namesEnabled||!model)return;
    let index=0;
    model.traverse(o=>{if(!o.isMesh)return;const label=document.createElement('div');label.className='explore-part-label';label.textContent=getPartName(o,index++);stage.appendChild(label);partLabels.push({el:label,mesh:o});});
    updatePartLabels();
  }
  function updatePartLabels(){
    if(!namesEnabled||!model)return;
    const w=stage.clientWidth||1,h=stage.clientHeight||1;const v=new THREE.Vector3();
    partLabels.forEach(item=>{const b=new THREE.Box3().setFromObject(item.mesh);b.getCenter(v);v.project(camera);const x=(v.x*.5+.5)*w,y=(-v.y*.5+.5)*h;const visible=v.z>-1&&v.z<1&&x>-20&&x<w+20&&y>-20&&y<h+20;item.el.style.display=visible?'block':'none';item.el.style.left=`${x}px`;item.el.style.top=`${y}px`;});
  }
  function setNamesEnabled(on){
    namesEnabled=!!on;stage.classList.toggle('names-enabled',namesEnabled);
    if(namesButton){namesButton.classList.toggle('names-active',namesEnabled);namesButton.textContent=namesEnabled?tt('hideNames'):tt('names');}
    if(namesEnabled)buildPartLabels();else clearPartLabels();
    if(partTooltip)partTooltip.style.display='none';
  }
  function getMeshAtEvent(e){
    if(!model||!camera)return null;
    const rect=canvas.getBoundingClientRect();if(!rect.width||!rect.height)return null;
    partPointer.x=((e.clientX-rect.left)/rect.width)*2-1;partPointer.y=-((e.clientY-rect.top)/rect.height)*2+1;
    partRaycaster.setFromCamera(partPointer,camera);
    const hit=partRaycaster.intersectObject(model,true).find(h=>h.object?.isMesh);
    return hit?.object||null;
  }
  function selectPartAt(e){
    const hit=getMeshAtEvent(e);
    selectedMesh=hit;
    updateColorTargetLabel();
    if(partTooltip&&hit){partTooltip.textContent=`✓ ${getPartName(hit,0)}`;partTooltip.style.left=`${Math.min(stage.clientWidth-12,Math.max(12,e.clientX-canvas.getBoundingClientRect().left+14))}px`;partTooltip.style.top=`${Math.min(stage.clientHeight-12,Math.max(12,e.clientY-canvas.getBoundingClientRect().top+14))}px`;partTooltip.style.display='block';}
    render();
  }
  function setupPartHover(){
    if(partTooltip)return;
    partTooltip=document.createElement('div');partTooltip.className='explore-part-tooltip';stage.appendChild(partTooltip);
    stage.addEventListener('pointermove',e=>{
      if(!model)return;
      const rect=canvas.getBoundingClientRect();
      const hit=getMeshAtEvent(e);
      if(hit){const name=getPartName(hit,0);partTooltip.textContent=(selectedMesh===hit?'✓ ':'')+name;partTooltip.style.left=`${Math.min(stage.clientWidth-12,Math.max(12,e.clientX-rect.left+14))}px`;partTooltip.style.top=`${Math.min(stage.clientHeight-12,Math.max(12,e.clientY-rect.top+14))}px`;partTooltip.style.display='block';canvas.style.cursor='pointer';}
      else{partTooltip.style.display='none';canvas.style.cursor=namesEnabled?'crosshair':'grab';}
    });
    stage.addEventListener('pointerleave',()=>{if(partTooltip)partTooltip.style.display='none';canvas.style.cursor=namesEnabled?'crosshair':'grab';});
  }
  function buildExtraUI(){
    if(!actions)return;
    if(!reviewsButton){reviewsButton=document.createElement('button');reviewsButton.type='button';reviewsButton.className='explore-close';reviewsButton.id='exploreReviewsButton';reviewsButton.textContent=tt('reviews');actions.insertBefore(reviewsButton,actions.firstChild);reviewsButton.addEventListener('click',()=>{buildReviewPanel();reviewPanel?.classList.toggle('open');});}
    else reviewsButton.textContent=tt('reviews');
    if(!lightButton){lightButton=document.createElement('button');lightButton.type='button';lightButton.className='explore-close';lightButton.id='exploreLightButton';lightButton.textContent=tt('light');actions.insertBefore(lightButton,actions.firstChild);lightButton.addEventListener('click',()=>{buildLightPanel();lightPanel?.classList.toggle('open');});}
    else lightButton.textContent=tt('light');
    if(!namesButton){namesButton=document.createElement('button');namesButton.type='button';namesButton.className='explore-close';namesButton.id='exploreNamesButton';namesButton.textContent=tt('names');actions.insertBefore(namesButton,actions.firstChild);namesButton.addEventListener('click',()=>setNamesEnabled(!namesEnabled));}
    else namesButton.textContent=namesEnabled?tt('hideNames'):tt('names');
    setupPartHover();
    if(!materialsBar)return;
    let toolbar=materialsBar.querySelector('.explore-viewer-toolbar');
    if(!toolbar){toolbar=document.createElement('div');toolbar.className='explore-viewer-toolbar';materialsBar.prepend(toolbar);[['', 'explode',()=>setExplode(true)],['','assemble',()=>setExplode(false)],['↺','reset',()=>{fitModel();setExplode(false);restoreColors();render();}],['','day',setDay],['','night',setNight]].forEach(([icon,key,fn])=>{const b=document.createElement('button');b.type='button';b.className='explore-tool-btn';b.dataset.viewerAction=key;b.textContent=`${icon} ${tt(key)}`;b.addEventListener('click',fn);toolbar.appendChild(b);});}
    viewerToolbar=toolbar;
    toolbar.querySelectorAll('.explore-tool-btn').forEach(b=>{const key=b.dataset.viewerAction;const labels={explode:'explode',assemble:'assemble',reset:'reset',day:'day',night:'night'};const icon=key==='reset'?'↺':'';b.textContent=`${icon} ${tt(labels[key]||key)}`.trim();});
    updateViewerExplodeControls();
    if(materialsLabel)materialsLabel.textContent=getLang()==='en'?'Colors':getLang()==='zh'?'颜色':getLang()==='ur'?'رنگ':getLang()==='fr'?'Couleurs':'ألوان';
  }
  function buildReviewPanel(){
    if(reviewPanel)return;
    reviewPanel=document.createElement('div');reviewPanel.id='exploreReviewPanel';reviewPanel.className='explore-review-panel';reviewPanel.innerHTML=`<div class="explore-review-title"></div><div class="explore-review-rating"></div><div class="explore-review-summary"></div><div class="explore-review-section-title"></div><textarea class="explore-review-input" maxlength="800"></textarea><button type="button" class="explore-review-post"></button><div class="explore-review-list"></div>`;box.appendChild(reviewPanel);
    reviewPanel.querySelector('.explore-review-post').addEventListener('click',postComment);renderReviews();setReviewLabels();
  }
  function buildLightPanel(){
    if(lightPanel)return;
    lightPanel=document.createElement('div');lightPanel.id='exploreLightPanel';lightPanel.className='explore-light-panel';
    const lightLang=getLang();
    const lightNames=lightLang==='en'?['Sun / Key','Fill','Rim']:lightLang==='zh'?['主光','补光','轮廓光']:lightLang==='fr'?['Soleil / principale','Remplissage','Contre-jour']:lightLang==='ur'?['سورج / مرکزی','معاون روشنی','پچھلی روشنی']:['الشمس / الإضاءة الرئيسية','الإضاءة المساندة','الإضاءة الخلفية'];
    lightPanel.innerHTML=`<div class="explore-review-title"></div><div class="light-row"><span>${lightNames[0]}</span><input class="light-color" data-light="key" type="color" value="#ffffff" aria-label="${lightNames[0]}"><input class="light-range" data-light="key" type="range" min="0" max="4" step="0.05" value="2.2" aria-label="Intensity"></div><div class="light-row"><span>${lightNames[1]}</span><input class="light-color" data-light="fill" type="color" value="#8bb8ff" aria-label="${lightNames[1]}"><input class="light-range" data-light="fill" type="range" min="0" max="3" step="0.05" value="0.75" aria-label="Intensity"></div><div class="light-row"><span>${lightNames[2]}</span><input class="light-color" data-light="rim" type="color" value="#ff71d8" aria-label="${lightNames[2]}"><input class="light-range" data-light="rim" type="range" min="0" max="3" step="0.05" value="1" aria-label="Intensity"></div>`;box.appendChild(lightPanel);
    lightPanel.querySelector('.explore-review-title').textContent=tt('light');lightPanel.addEventListener('input',e=>{const type=e.target.dataset?.light;if(!type)return;const l=lights()[type];if(!l)return;if(e.target.classList.contains('light-color'))l.color.set(e.target.value);else l.intensity=parseFloat(e.target.value)||0;render();});
  }
  function setReviewLabels(){if(!reviewPanel)return;reviewPanel.querySelector('.explore-review-title').textContent=tt('rating');reviewPanel.querySelector('.explore-review-section-title').textContent=tt('comments');const input=reviewPanel.querySelector('.explore-review-input');input.placeholder=tt('placeholder');reviewPanel.querySelector('.explore-review-post').textContent=tt('post');}
  function reviewKey(){return currentRecord?.builtIn?`builtin:${currentBuiltInKey}`:(currentId?`published:${currentId}`:(currentRecord?.id||'unknown'));}
  function getReviews(){try{return JSON.parse(localStorage.getItem('toryakReviews_'+reviewKey())||'{"ratings":[],"comments":[]}');}catch(_){return{ratings:[],comments:[]};}}
  function saveReviews(v){try{localStorage.setItem('toryakReviews_'+reviewKey(),JSON.stringify(v));}catch(_){} }
  function renderReviews(){
    if(!reviewPanel)return;setReviewLabels();const data=getReviews();const ratings=data.ratings.map(Number).filter(n=>n>=1&&n<=5);const avg=ratings.length?ratings.reduce((a,b)=>a+b,0)/ratings.length:0;const rating=reviewPanel.querySelector('.explore-review-rating');rating.innerHTML='';let last=ratings.at(-1)||0;for(let i=1;i<=5;i++){const b=document.createElement('button');b.type='button';b.className='explore-review-star'+(i<=last?' active':'');b.textContent='★';b.addEventListener('click',()=>{const x=getReviews();x.ratings.push(i);saveReviews(x);renderReviews();});rating.appendChild(b);}reviewPanel.querySelector('.explore-review-summary').textContent=ratings.length?`${avg.toFixed(1)} / 5 • ${ratings.length}`:tt('noRating');const list=reviewPanel.querySelector('.explore-review-list');list.innerHTML='';if(!data.comments.length){const n=document.createElement('div');n.className='explore-review-empty';n.textContent=tt('none');list.appendChild(n);}else{data.comments.slice().reverse().forEach(c=>{const item=document.createElement('div');item.className='explore-review-comment';item.innerHTML=`<div class="explore-review-comment-head"><span></span><span></span></div><div class="explore-review-comment-body"></div>`;item.querySelector('.explore-review-comment-head span').textContent=c.author||'Guest';item.querySelectorAll('.explore-review-comment-head span')[1].textContent=c.at?new Date(c.at).toLocaleString():'';item.querySelector('.explore-review-comment-body').textContent=c.text||'';list.appendChild(item);});}
  }
  function postComment(){if(!reviewPanel)return;const input=reviewPanel.querySelector('.explore-review-input');const text=String(input.value||'').trim();if(!text)return;const x=getReviews();let author='Guest';try{const a=window.getAuthState?.();if(a?.loggedIn)author=a.provider||'User';}catch(_){}x.comments.push({author,text,at:new Date().toISOString()});saveReviews(x);input.value='';renderReviews();}

  // Use this exact viewer for both built-in models and user-published projects.
  window.openExploreModal=openViewer;
  window.openUnifiedProjectViewer=openViewer;
  window.openPublishedProjectDetail=(id,explode)=>openViewer(Number(id),{explode:!!explode});
  window.openBuiltInProjectDetail=(key)=>openViewer(key);
  window.__toryakGetPublishedProjectRecord=window.__toryakGetPublishedProjectRecord||window.getPublishedProjectRecord;
  // Patch the published-record getter explicitly when the original is scoped.
  if(typeof window.__toryakGetPublishedProjectRecord!=='function') window.__toryakGetPublishedProjectRecord=async id=>{
    try{const db=await new Promise((resolve,reject)=>{const req=indexedDB.open('toryakProjectDB',1);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});const rec=await new Promise((resolve,reject)=>{const tx=db.transaction('projects','readonly');const req=tx.objectStore('projects').get(Number(id));req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error);});db.close();return rec;}catch(e){console.warn(e);return null;}
  };

  // Existing model cards all open the same viewer page.
  document.getElementById('modelsGrid')?.addEventListener('click',e=>{
    // Published cards own their click handlers. Skipping them here avoids double-open
    // and prevents a second non-exploded open from cancelling the explode-card action.
    if(e.target.closest?.('.published-model-card'))return;
    const card=e.target.closest?.('.pistol-card,.lighter-card,.circuit-card,.jerrycan-card,.bonnie-card,.asset-model-card'); if(card){if(e.target.closest('button'))return;let key=card.dataset.assetKey || (card.id==='lighterCard'?'lighter':card.id==='circuitCard'?'circuit':card.id==='jerrycanCard'?'jerrycan':card.id==='bonnieCard'?'bonnie':card.id==='rifleCard'?'rifle':'pistol');openViewer(key);}
  });
  document.querySelectorAll('.model-open-btn[onclick^="openExploreModal"]').forEach(btn=>{
    const m=btn.getAttribute('onclick')||'';const hit=m.match(/openExploreModal\('([^']+)'\)/);if(hit){btn.removeAttribute('onclick');btn.addEventListener('click',e=>{e.stopPropagation();openViewer(hit[1]);});}
  });
  function updateFullscreenButton(){
    if(!fullscreenBtn)return;
    const active=document.fullscreenElement===box;
    fullscreenBtn.textContent=active?tt('exitFullscreen'):tt('fullscreen');
  }
  async function toggleViewerFullscreen(){
    try{
      if(document.fullscreenElement===box){ await document.exitFullscreen(); }
      else if(box.requestFullscreen){ await box.requestFullscreen(); }
      else { box.classList.toggle('viewer-fullscreen-fallback'); }
    }catch(err){ console.warn('Fullscreen unavailable',err); }
    setTimeout(()=>{ ensureRenderer(); render(); updateFullscreenButton(); },80);
  }

  let fullscreenUiTimer=null;
  function showFullscreenViewerUI(){
    if(fullscreenUiTimer) clearTimeout(fullscreenUiTimer);
    box.classList.remove('viewer-ui-hidden');
    if(document.fullscreenElement===box){
      fullscreenUiTimer=setTimeout(()=>{
        if(document.fullscreenElement===box) box.classList.add('viewer-ui-hidden');
      },2200);
    }
  }
  function resetFullscreenViewerUI(){
    if(fullscreenUiTimer) clearTimeout(fullscreenUiTimer);
    fullscreenUiTimer=null;
    box.classList.remove('viewer-ui-hidden');
  }
  ['mousemove','pointermove','touchstart','wheel'].forEach(ev=>box.addEventListener(ev,showFullscreenViewerUI,{passive:true}));
  fullscreenBtn?.addEventListener('click',toggleViewerFullscreen);
  document.addEventListener('fullscreenchange',()=>{ if(document.fullscreenElement===box) showFullscreenViewerUI(); else resetFullscreenViewerUI(); updateFullscreenButton(); setTimeout(()=>{ensureRenderer();render();},60); });

  closeBtn?.addEventListener('click',async()=>{resetFullscreenViewerUI();if(document.fullscreenElement===box){try{await document.exitFullscreen();}catch(_){}} modal.classList.remove('active');modal.setAttribute('aria-hidden','true');dragging=rotating=panning=false;setNamesEnabled(false);disposeModel();if(reviewPanel)reviewPanel.remove(),reviewPanel=null;if(lightPanel)lightPanel.remove(),lightPanel=null;});
  resetBtn?.addEventListener('click',()=>{if(model){setExplode(false);fitModel();restoreColors();setDay();render();}});
  colorInput?.addEventListener('input',e=>applyColor(e.target.value));
  document.querySelectorAll('.explore-color-swatch[data-color]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const color=btn.getAttribute('data-color');
      if(!color)return;
      if(colorInput) colorInput.value=color;
      document.querySelectorAll('.explore-color-swatch').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      applyColor(color);
    });
  });
  playBtn?.addEventListener('click',()=>{
    if(!model)return;
    if(!displayPlaying)startViewerMotion();
    else{
      displayPlaying=false;
      if(actionsList.length&&mixer)actionsList.forEach(a=>a.stop());
      if(playBtn)playBtn.textContent='▶ تشغيل';
      render();
    }
  });
  stage.addEventListener('wheel',e=>{e.preventDefault();distance*=Math.exp(e.deltaY*.0012);distance=Math.max(1.6,Math.min(18,distance));render();},{passive:false});
  stage.addEventListener('contextmenu',e=>e.preventDefault());
  stage.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;pointerDownX=e.clientX;pointerDownY=e.clientY;pointerDidMove=false;rotating=e.button===0;panning=e.button!==0;stage.classList.add('dragging');stage.setPointerCapture?.(e.pointerId);});
  stage.addEventListener('pointermove',e=>{
    if(!dragging||!model)return;
    const dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;
    if(Math.hypot(e.clientX-pointerDownX,e.clientY-pointerDownY)>5)pointerDidMove=true;
    if(rotating){
      yaw-=dx*.008;
      pitch-=dy*.006;
      pitch=Math.max(-1.52,Math.min(1.52,pitch));
    }else{
      panX-=dx*.006;
      panY+=dy*.006;
    }
    render();
  });
  stage.addEventListener('pointerup',e=>{
    const pick=rotating&&!pointerDidMove;
    if(pick)selectPartAt(e);
    dragging=false;rotating=false;panning=false;stage.classList.remove('dragging');
  });
  stage.addEventListener('pointercancel',()=>{dragging=false;rotating=false;panning=false;stage.classList.remove('dragging');});
  window.addEventListener('resize',resize);
  window.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('active'))closeBtn?.click();});
  function tick(now){frameId=requestAnimationFrame(tick);if(!modal.classList.contains('active'))return;const dt=Math.min(.05,(now-lastTime)/1000);lastTime=now;if(mixer&&actionsList.some(a=>a.isRunning?.()))mixer.update(dt);
    if(displayPlaying && (!mixer || !actionsList.length) && model){model.rotation.y += dt*0.75;}
    render();}
  tick(performance.now());
})();
