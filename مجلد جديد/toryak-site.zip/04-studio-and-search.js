        // Model list initialized before any studio startup handlers.
        var STUDIO_MODEL_OPTIONS = [];

        // تفاعل نافذة تسجيل الدخول والترجمة
        const authModal = document.getElementById('authModal');
        const translateModal = document.getElementById('translateModal');
        document.getElementById('openAuthModalBtn').addEventListener('click', () => authModal.classList.add('active'));
        document.getElementById('closeAuthModal').addEventListener('click', () => authModal.classList.remove('active'));
        document.getElementById('openTranslateModalBtn').addEventListener('click', () => translateModal.classList.add('active'));
        document.getElementById('closeTranslateModal').addEventListener('click', () => translateModal.classList.remove('active'));

        // ================= الذكاء الاصطناعي داخل شريط البحث =================
        // شريط البحث الرئيسي: الانتقال إلى صفحة النماذج ثلاثية الأبعاد
        const modelsPage = document.getElementById('modelsPage');
        const mainSearchBox = document.getElementById('mainSearchBox');
        const modelsSearchBox = document.getElementById('modelsSearchBox');
        const modelsEmpty = document.getElementById('modelsEmpty');

        // بحث موحّد يدعم العربية والإنجليزية والأسماء البديلة بدون حساسية للمسافات أو التشكيل.
        const modelSearchAliases = {
            'روبوت': 'روبوت robot',
            'ساعة': 'ساعة watch antique camera',
            'هاتف': 'هاتف phone smartphone',
            'خوذة': 'خوذة helmet',
            'مكعب': 'مكعب cube',
            'cube': 'مكعب cube'
        };

        function normalizeSearch(value) {
            return String(value || '')
                .toLowerCase()
                .normalize('NFKC')
                .replace(/[\u064B-\u065F\u0670]/g, '')
                .replace(/ـ/g, '')
                .replace(/[أإآٱ]/g, 'ا')
                .replace(/ى/g, 'ي')
                .replace(/ؤ/g, 'و')
                .replace(/ئ/g, 'ي')
                .replace(/ة/g, 'ه')
                .replace(/[^\p{L}\p{N}]+/gu, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        }

        window.tgShowModels = (q, f) => showModelsPage(q, f);
        function showModelsPage(query, focusSearch = false) {
            try { window.tgSyncAll && window.tgSyncAll(); } catch (_) {}
            const cleanQuery = String(query || '').trim();
            modelsPage.classList.add('active');
            modelsSearchBox.value = cleanQuery;
            filterModels(cleanQuery);
            if (focusSearch) setTimeout(() => modelsSearchBox.focus(), 50);
        }

        // فهرس ثابت للبحث: لا يعتمد على النص الظاهر الذي قد يتغير عند الترجمة.
        const MODEL_SEARCH_INDEX = {
            robot: 'روبوت robot',
            watch: 'ساعة ساعه watch',
            phone: 'هاتف phone smartphone',
            helmet: 'خوذة خوذه helmet',
            cube: 'مكعب cube',
            pyramid: 'هرم pyramid مخروط cone',
            sphere: 'كرة كره sphere'
        };

        function getModelSearchBlob(card) {
            const id = card.id || '';
            // Search visible labels as well as both data attributes. Published-user cards often
            // have useful titles in .model-name even when a data-keywords attribute exists.
            const fields = [
                card.getAttribute('data-keywords') || '',
                card.getAttribute('data-model') || '',
                card.getAttribute('data-explore') || '',
                card.getAttribute('data-project-name') || '',
                card.id || '',
                card.querySelector('.model-name')?.textContent || '',
                card.querySelector('.model-desc')?.textContent || '',
                card.querySelector('.published-model-title')?.textContent || '',
                card.querySelector('h3, h4')?.textContent || ''
            ];
            const indexed = '';
            return normalizeSearch([...fields, indexed].join(' '));
        }

        const GENERIC_MODEL_SEARCHES = new Set([
            'مجسم', 'مجسمات', 'نموذج', 'نماذج', '3d', '3d model', '3d models', 'model', 'models',
            'نموذج ثلاثي الابعاد', 'نماذج ثلاثيه الابعاد', 'مجسم ثلاثي الابعاد', 'مجسمات ثلاثيه الابعاد',
            'نماذج ثلاثيه', 'مجسمات ثلاثيه'
        ].map(normalizeSearch));

        function isGenericModelSearch(normalizedQuery) {
            return GENERIC_MODEL_SEARCHES.has(normalizedQuery);
        }

        let nextModelSearchOrder = 0;
        function getSearchableModelCards() {
            const grid = document.getElementById('modelsGrid');
            if (!grid) return [];
            const cards = Array.from(grid.querySelectorAll(':scope > .model-card'));
            cards.forEach(card => {
                if (!Number.isFinite(card._toryakSearchOrder)) card._toryakSearchOrder = nextModelSearchOrder++;
            });
            return cards;
        }

        function getModelMatchScore(card, normalizedQuery) {
            if (!normalizedQuery || isGenericModelSearch(normalizedQuery)) return 10;
            const title = normalizeSearch(card.querySelector('.model-name')?.textContent || card.querySelector('h3, h4')?.textContent || '');
            const searchable = getModelSearchBlob(card);
            const tokens = normalizedQuery.split(' ').filter(Boolean);
            const words = searchable.split(' ').filter(Boolean);
            const matches = searchable.includes(normalizedQuery) || tokens.every(token =>
                words.some(word => word === token || word.startsWith(token) || word.includes(token))
            );
            if (!matches) return Infinity;
            if (title === normalizedQuery) return 0;
            if (title.startsWith(normalizedQuery)) return 1;
            if (title.includes(normalizedQuery)) return 2;
            return 3;
        }

        function filterModels(query) {
            const q = normalizeSearch(query);
            const grid = document.getElementById('modelsGrid');
            const cards = getSearchableModelCards();
            const results = cards.map(card => ({card, score:getModelMatchScore(card, q)}));
            const visibleCards = results.filter(item => Number.isFinite(item.score));
            const ordered = !q || isGenericModelSearch(q)
                ? results.sort((a,b) => a.card._toryakSearchOrder - b.card._toryakSearchOrder)
                : results.sort((a,b) => a.score - b.score || a.card._toryakSearchOrder - b.card._toryakSearchOrder);
            ordered.forEach(item => {
                item.card.classList.toggle('hidden', !Number.isFinite(item.score));
                if (grid) grid.appendChild(item.card);
            });
            const visible = visibleCards.length;
            if (modelsEmpty) {
                modelsEmpty.textContent = q && visible === 0
                    ? `غير موجود في الموقع: «${String(query || '').trim()}». جرّب اسمًا آخر أو أضف المجسم من إنشاء مشروع.`
                    : 'لم نعثر على هذا المجسم. يمكنك رفع ملف GLB أو GLTF من Blender لإضافته إلى مشروعك.';
                modelsEmpty.classList.toggle('active', visible === 0);
            }
            updateModelRequestHint(query, visible);
            return visibleCards.map(item => item.card);
        }

        function renderMainSearchSuggestions(query) {
            const panel = document.getElementById('mainSearchSuggestions');
            const input = document.getElementById('mainSearchBox');
            if (!panel || !input) return;
            const raw = String(query || '').trim();
            panel.replaceChildren();
            if (!raw) {
                panel.classList.remove('active');
                input.setAttribute('aria-expanded', 'false');
                return;
            }
            const normalized = normalizeSearch(raw);
            const allCards = getSearchableModelCards();
            const generic = isGenericModelSearch(normalized);
            const results = allCards.map(card => ({
                card,
                score: getModelMatchScore(card, normalized),
                title: card.querySelector('.model-name')?.textContent?.trim() || card.querySelector('h3, h4')?.textContent?.trim() || 'نموذج ثلاثي الأبعاد',
                description: card.querySelector('.model-desc')?.textContent?.trim() || 'نموذج ثلاثي الأبعاد موجود في الموقع'
            })).filter(item => Number.isFinite(item.score));
            results.sort((a,b) => a.score - b.score || a.card._toryakSearchOrder - b.card._toryakSearchOrder);

            function addSuggestion(title, subtitle, className='') {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = `main-search-suggestion ${className}`.trim();
                button.setAttribute('role', 'option');
                const titleNode = document.createElement('span');
                titleNode.className = 'main-search-suggestion-title';
                titleNode.textContent = title;
                button.appendChild(titleNode);
                if (subtitle) {
                    const subNode = document.createElement('span');
                    subNode.className = 'main-search-suggestion-subtitle';
                    subNode.textContent = subtitle;
                    button.appendChild(subNode);
                }
                button.addEventListener('click', () => {
                    const selected = button.classList.contains('main-search-all') ? raw : title;
                    input.value = selected;
                    panel.classList.remove('active');
                    input.setAttribute('aria-expanded', 'false');
                    showModelsPage(selected, true);
                });
                panel.appendChild(button);
            }

            if (generic) {
                addSuggestion(`عرض جميع النماذج ثلاثية الأبعاد (${allCards.length})`, 'افتح مكتبة النماذج الموجودة في الموقع', 'main-search-all');
                // For a generic query, list a few real model names as shortcuts without loading previews.
                results.slice(0, 5).forEach(item => addSuggestion(item.title, item.description));
            } else if (results.length) {
                results.slice(0, 7).forEach(item => addSuggestion(item.title, item.description));
            } else {
                const empty = document.createElement('div');
                empty.className = 'main-search-suggestion-empty';
                empty.textContent = `غير موجود في الموقع: «${raw}»`;
                panel.appendChild(empty);
            }
            panel.classList.add('active');
            input.setAttribute('aria-expanded', 'true');
        }


        // ================= طلبات النماذج غير الموجودة وإشعار الإصدار =================
        const MODEL_REQUESTS_KEY = 'toryakModelRequests';
        const RELEASE_NOTIFICATIONS_KEY = 'toryakModelReleaseNotifications';
        function getModelRequests(){
            try {
                const v = JSON.parse(localStorage.getItem(MODEL_REQUESTS_KEY) || '[]');
                return Array.isArray(v) ? v : [];
            } catch (_) { return []; }
        }
        function setModelRequests(list){
            try { localStorage.setItem(MODEL_REQUESTS_KEY, JSON.stringify(list.slice(0,100))); } catch (_) {}
        }
        function getReleaseNotifications(){
            try {
                const v = JSON.parse(localStorage.getItem(RELEASE_NOTIFICATIONS_KEY) || '[]');
                return Array.isArray(v) ? v : [];
            } catch (_) { return []; }
        }
        function setReleaseNotifications(list){
            try { localStorage.setItem(RELEASE_NOTIFICATIONS_KEY, JSON.stringify(list.slice(0,50))); } catch (_) {}
        }
        function addModelRequest(query){
            const clean = String(query || '').trim();
            const normalized = normalizeSearch(clean);
            if (normalized.length < 2) return;
            const list = getModelRequests();
            const exists = list.some(r => normalizeSearch(r.query) === normalized);
            if (!exists) {
                list.unshift({query: clean, normalized, requestedAt:new Date().toISOString()});
                setModelRequests(list);
            }
        }
        function modelMatchesRequest(projectName, request){
            const a = normalizeSearch(projectName);
            const b = normalizeSearch(request?.normalized || request?.query || '');
            if (!a || !b) return false;
            const tokens = b.split(' ').filter(Boolean);
            return a.includes(b) || tokens.every(t => a.includes(t));
        }
        function notifyModelReleased(projectName, projectId){
            const requests = getModelRequests();
            if (!requests.length) return;
            const notifications = getReleaseNotifications();
            const matched = requests.filter(r => modelMatchesRequest(projectName, r));
            if (!matched.length) return;
            matched.forEach(r => {
                const duplicate = notifications.some(n => normalizeSearch(n.query)===normalizeSearch(r.query) && Number(n.projectId)===Number(projectId));
                if (!duplicate) notifications.unshift({
                    id: Date.now() + Math.floor(Math.random()*1000),
                    query:r.query, projectId:Number(projectId), projectName:String(projectName||''),
                    createdAt:new Date().toISOString(), read:false
                });
            });
            setReleaseNotifications(notifications);
            setModelRequests(requests.filter(r => !matched.includes(r)));
        }
        function ensureReleaseNotifications(){
            try {
                const projects = JSON.parse(localStorage.getItem('toryakProjects') || '[]');
                const requests = getModelRequests();
                if (!Array.isArray(projects) || !requests.length) return;
                requests.slice().forEach(r => {
                    const p = projects.find(x => modelMatchesRequest(x?.name || '', r));
                    if (p) notifyModelReleased(p.name, p.id);
                });
            } catch (_) {}
        }
        function showReleaseNotification(notification){
            if (!notification) return;
            let panel=document.getElementById('releaseNotifyPanel');
            if(!panel){
                panel=document.createElement('div');
                panel.id='releaseNotifyPanel';
                panel.className='release-notify-panel';
                panel.innerHTML='<div class="rn-title">تم إصدار المجسم الذي تبحث عنه</div><div class="rn-text"></div><div class="rn-actions"><button type="button" class="rn-open">عرض المجسم</button><button type="button" class="rn-close">إغلاق</button></div>';
                document.body.appendChild(panel);
                panel.querySelector('.rn-close').onclick=()=>panel.classList.remove('active');
            }
            panel.querySelector('.rn-text').textContent=`تم إصدار «${notification.projectName || notification.query}» الذي كنت تبحث عنه.`;
            panel.querySelector('.rn-open').onclick=()=>{
                panel.classList.remove('active');
                if(window.openPublishedProjectDetail && notification.projectId) window.openPublishedProjectDetail(notification.projectId);
            };
            panel.classList.add('active');
            setTimeout(()=>panel.classList.remove('active'),9000);
        }
        function showPendingReleaseNotifications(){
            const list=getReleaseNotifications();
            const pending=list.find(n=>!n.read);
            if(!pending) return;
            const next=list.map(n=>n.id===pending.id?{...n,read:true}:n);
            setReleaseNotifications(next);
            setTimeout(()=>showReleaseNotification(pending),500);
        }
        function updateModelRequestHint(query, visibleCount){
            const hint=document.getElementById('modelRequestHint');
            if(!hint) return;
            const clean=String(query||'').trim();
            if(visibleCount>0 || normalizeSearch(clean).length<2){
                hint.classList.remove('active');
                hint.innerHTML='';
                return;
            }
            addModelRequest(clean);
            hint.replaceChildren();
            const messageTitle = document.createElement('b');
            messageTitle.textContent = `غير موجود في الموقع: «${clean}».`;
            const lineBreak = document.createElement('br');
            hint.append(messageTitle, lineBreak, document.createTextNode('تم تسجيل طلبك، وعند إضافة هذا المجسم سيظهر لك إشعار عند فتح الموقع.'));
            hint.classList.add('active');
        }

        // Live home suggestions: matching model names appear immediately; unknown terms are explicit.
        mainSearchBox.addEventListener('input', function() { renderMainSearchSuggestions(this.value); try { window.tgAugmentSearch && window.tgAugmentSearch(this.value, 'model'); } catch (_) {} });
        function submitMainModelSearch() {
            const query = mainSearchBox.value.trim();
            const panel = document.getElementById('mainSearchSuggestions');
            panel?.classList.remove('active');
            mainSearchBox.setAttribute('aria-expanded', 'false');
            showModelsPage(query, true);
        }
        mainSearchBox.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); submitMainModelSearch(); }
            else if (e.key === 'Escape') {
                const panel = document.getElementById('mainSearchSuggestions');
                panel?.classList.remove('active');
                this.setAttribute('aria-expanded', 'false');
            }
        });
        document.getElementById('mainSearchBtn')?.addEventListener('click', submitMainModelSearch);
        document.addEventListener('pointerdown', function(event) {
            if (event.target.closest('.main-search-wrapper')) return;
            const panel = document.getElementById('mainSearchSuggestions');
            panel?.classList.remove('active');
            mainSearchBox.setAttribute('aria-expanded', 'false');
        });

        modelsSearchBox.addEventListener('input', function() { filterModels(this.value); });
        modelsSearchBox.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') { modelsPage.classList.remove('active'); mainSearchBox.focus(); }
        });

        document.getElementById('closeModelsPage').addEventListener('click', () => {
            modelsPage.classList.remove('active');
        });

        function openModelFromPage(query) {
            modelsPage.classList.remove('active');
            document.getElementById('studioView').classList.add('active');
            loadProductModel(query);
        }





// معاينة المسدس داخل البطاقة: صورة ثابتة موثوقة لتجنب إخفاء البطاقة عند فشل WebGL.

        // تفاعل الصفحة الرئيسية (القمر والفقاعات)
        const moonWrapper = document.getElementById('moonWrapper');
        const moonBtn = document.getElementById('toggleMoonBubbles');
        const sideBubbles = document.getElementById('sideBubbles');
        
        const openStudioBtn = document.getElementById('openStudioBtn');
        const closeStudioBtn = document.getElementById('closeStudioBtn');
        const studioView = document.getElementById('studioView');

        moonBtn.addEventListener('click', () => {
            sideBubbles.classList.toggle('active');
            moonWrapper.classList.remove('animate');
            void moonWrapper.offsetWidth; 
            moonWrapper.classList.add('animate');
        });

        window.addEventListener('click', (e) => {
            if (!moonWrapper.contains(e.target) && !sideBubbles.contains(e.target)) {
                sideBubbles.classList.remove('active');
            }
        });

        openStudioBtn.addEventListener('click', () => {
            sideBubbles.classList.remove('active');
            studioView.classList.add('active');
            requestAnimationFrame(() => {
                if (typeof camera !== 'undefined' && typeof renderer !== 'undefined') {
                    ensureStudioLighting();
                    const w = Math.max(320, canvasContainer.clientWidth || window.innerWidth - 370);
                    const h = Math.max(240, canvasContainer.clientHeight || window.innerHeight - 76);
                    renderer.setSize(w, h, false);
                    camera.aspect = w / h;
                    camera.updateProjectionMatrix();
                    if (!currentModel) {
                        currentModel = makeStudioHumanFallback();
                        scene.add(currentModel);
                        finalizeModelSetup();
                        const status = document.getElementById('aiStatus');
                        if (status) status.innerText = 'الاستوديو جاهز — يظهر نموذج مؤقت. اختر مجسمًا من القائمة لتحميله.';
                        // Try the bundled model after a visible starter has already appeared.
                        const starter = STUDIO_MODEL_OPTIONS.find(item => item.key === 'lighter');
                        if (starter) loadProductModel(starter.query);
                    } else {
                        if (!currentModel.parent) scene.add(currentModel);
                        focusStudioCameraOnModel(currentModel);
                    }
                    if (typeof renderStudioFrame === 'function') renderStudioFrame();
                }
            });
        });

        closeStudioBtn.addEventListener('click', () => {
            studioView.classList.remove('active');
        });

        // ================= منصة ألعاب النوافذ الشفافة (إكس - أو، الألغاز، تفادي السيارات) =================

        // 1. لعبة إكس - أو (مع الذكاء الاصطناعي)
        const xoModalOverlay = document.getElementById('xoModalOverlay');
        const openXoModal = document.getElementById('openXoModal');
        const closeXoModal = document.getElementById('closeXoModal');
        const xoCells = document.querySelectorAll('.xo-cell');
        const xoStatus = document.getElementById('xoStatus');
        const xoRestartBtn = document.getElementById('xoRestartBtn');

        let xoBoardState = ['', '', '', '', '', '', '', '', ''];
        let isGameActive = true;
        let playerTurn = true; 

        openXoModal.addEventListener('click', () => {
            sideBubbles.classList.remove('active');
            xoModalOverlay.classList.add('active');
            resetXoGame();
        });

        closeXoModal.addEventListener('click', () => {
            xoModalOverlay.classList.remove('active');
        });

        xoCells.forEach(cell => {
            cell.addEventListener('click', () => {
                const idx = cell.getAttribute('data-index');
                if (xoBoardState[idx] === '' && isGameActive && playerTurn) {
                    xoBoardState[idx] = 'X';
                    cell.innerText = 'X';
                    cell.style.color = '#3a7bd5';
                    
                    if (checkWin('X')) {
                        xoStatus.innerText = 'فزت على الذكاء الاصطناعي! ';
                        isGameActive = false;
                        return;
                    }
                    if (xoBoardState.every(cell => cell !== '')) {
                        xoStatus.innerText = 'تعادل!';
                        isGameActive = false;
                        return;
                    }

                    playerTurn = false;
                    xoStatus.innerText = 'دور الذكاء الاصطناعي (O)...';
                    setTimeout(aiMove, 500);
                }
            });
        });

        function aiMove() {
            if (!isGameActive) return;
            let emptyCells = [];
            xoBoardState.forEach((val, idx) => { if (val === '') emptyCells.push(idx); });

            if (emptyCells.length > 0) {
                let move = getBestAiMove();
                xoBoardState[move] = 'O';
                xoCells[move].innerText = 'O';
                xoCells[move].style.color = '#ff4d4f';

                if (checkWin('O')) {
                    xoStatus.innerText = 'فاز الذكاء الاصطناعي! ';
                    isGameActive = false;
                    return;
                }
                if (xoBoardState.every(cell => cell !== '')) {
                    xoStatus.innerText = 'تعادل!';
                    isGameActive = false;
                    return;
                }
            }
            playerTurn = true;
            xoStatus.innerText = 'دورك (X) - العب الآن';
        }

        function getBestAiMove() {
            const winningCombos = [
                [0,1,2], [3,4,5], [6,7,8],
                [0,3,6], [1,4,7], [2,5,8],
                [0,4,8], [2,4,6]
            ];
            for (let combo of winningCombos) {
                let [a, b, c] = combo;
                let vals = [xoBoardState[a], xoBoardState[b], xoBoardState[c]];
                if (vals.filter(v => v === 'O').length === 2 && vals.includes('')) {
                    return combo[vals.indexOf('')];
                }
            }
            for (let combo of winningCombos) {
                let [a, b, c] = combo;
                let vals = [xoBoardState[a], xoBoardState[b], xoBoardState[c]];
                if (vals.filter(v => v === 'X').length === 2 && vals.includes('')) {
                    return combo[vals.indexOf('')];
                }
            }
            let empty = [];
            xoBoardState.forEach((v, i) => { if (v === '') empty.push(i); });
            return empty[Math.floor(Math.random() * empty.length)];
        }

        function checkWin(player) {
            const wins = [
                [0,1,2], [3,4,5], [6,7,8],
                [0,3,6], [1,4,7], [2,5,8],
                [0,4,8], [2,4,6]
            ];
            return wins.some(combo => combo.every(idx => xoBoardState[idx] === player));
        }

        function resetXoGame() {
            xoBoardState = ['', '', '', '', '', '', '', '', ''];
            isGameActive = true;
            playerTurn = true;
            xoStatus.innerText = 'دورك (X) - العب الآن';
            xoCells.forEach(c => c.innerText = '');
        }

        xoRestartBtn.addEventListener('click', resetXoGame);


        // 2. لعبة حل الألغاز السريعة
        const puzzleModalOverlay = document.getElementById('puzzleModalOverlay');
        const openPuzzleModal = document.getElementById('openPuzzleModal');
        const closePuzzleModal = document.getElementById('closePuzzleModal');
        const puzzleQuestionText = document.getElementById('puzzleQuestionText');
        const puzzleOptionsContainer = document.getElementById('puzzleOptionsContainer');
        const nextPuzzleBtn = document.getElementById('nextPuzzleBtn');

        const puzzlesDB = [
            { q: "ما هو الشيء الذي كلما أخذت منه كبر وكلما وضعت فيه صغر؟", options: ["الحفرة", "البحر", "الجبل"], correct: 0 },
            { q: "ما هو الشيء الذي يسير بلا أرجل ولا يدخل إلا بالأذنين؟", options: ["الريح", "الصوت", "الخيال"], correct: 1 },
            { q: "ما هو الشيء الذي إذا أكلته كله نفعك، وإذا أكلت نصفه قاتلك؟", options: ["السمك", "السمسم", "الخبز"], correct: 1 },
            { q: "له عيون ولا يرى، وله رأس ولا يفكر، فما هو؟", options: ["الإبرة", "القلم", "المفتاح"], correct: 0 }
        ];
        let currentPuzzleIdx = 0;

        openPuzzleModal.addEventListener('click', () => {
            sideBubbles.classList.remove('active');
            puzzleModalOverlay.classList.add('active');
            currentPuzzleIdx = Math.floor(Math.random() * puzzlesDB.length);
            loadPuzzle();
        });

        closePuzzleModal.addEventListener('click', () => {
            puzzleModalOverlay.classList.remove('active');
        });

        function loadPuzzle() {
            nextPuzzleBtn.style.display = 'none';
            let p = puzzlesDB[currentPuzzleIdx];
            puzzleQuestionText.innerText = p.q;
            puzzleOptionsContainer.innerHTML = '';
            
            p.options.forEach((opt, idx) => {
                let btn = document.createElement('button');
                btn.className = 'puzzle-option-btn';
                btn.innerText = opt;
                btn.onclick = () => checkPuzzleAnswer(idx, p.correct, btn);
                puzzleOptionsContainer.appendChild(btn);
            });
        }

        function checkPuzzleAnswer(selected, correct, btn) {
            let allBtns = puzzleOptionsContainer.querySelectorAll('button');
            allBtns.forEach(b => b.disabled = true);
            if (selected === correct) {
                btn.style.background = 'rgba(82, 196, 26, 0.4)';
                btn.style.borderColor = '#52c41a';
                puzzleQuestionText.innerText = 'إجابة صحيحة! أحسنت ';
            } else {
                btn.style.background = 'rgba(255, 77, 79, 0.4)';
                btn.style.borderColor = '#ff4d4f';
                puzzleQuestionText.innerText = 'إجابة خاطئة، حاول في السؤال القادم!';
            }
            nextPuzzleBtn.style.display = 'block';
        }

        nextPuzzleBtn.addEventListener('click', () => {
            currentPuzzleIdx = (currentPuzzleIdx + 1) % puzzlesDB.length;
            loadPuzzle();
        });


        // 3. لعبة تفادي السيارات المصغرة — حركة مستمرة، سيارات متعددة، تصادم وإعادة تشغيل
        const carModalOverlay = document.getElementById('carModalOverlay');
        const openCarModal = document.getElementById('openCarModal');
        const closeCarModal = document.getElementById('closeCarModal');
        const carGameCanvas = document.getElementById('carGameCanvas');
        const carCtx = carGameCanvas.getContext('2d');
        const carScoreText = document.getElementById('carScoreText');
        const carLeftBtn = document.getElementById('carLeftBtn');
        const carRightBtn = document.getElementById('carRightBtn');
        const carRestartBtn = document.getElementById('carRestartBtn');

        let carGameInterval = null;
        let playerCar = { x: 105, y: 205, width: 30, height: 45, speed: 30 };
        let obstacles = [];
        let carScore = 0;
        let isCarPlaying = false;
        let carSpawnTimer = 0;
        let roadOffset = 0;

        openCarModal.addEventListener('click', () => {
            sideBubbles.classList.remove('active');
            carModalOverlay.classList.add('active');
            startCarGame();
        });

        closeCarModal.addEventListener('click', () => {
            carModalOverlay.classList.remove('active');
            stopCarGame();
        });

        carRestartBtn.addEventListener('click', startCarGame);

        function startCarGame() {
            playerCar.x = 105;
            obstacles = [];
            carScore = 0;
            carSpawnTimer = 12;
            roadOffset = 0;
            isCarPlaying = true;
            carScoreText.innerText = 'النقاط: 0 • تفادى السيارات';
            drawCarGame();
            if (carGameInterval) clearInterval(carGameInterval);
            carGameInterval = setInterval(updateCarGame, 30);
        }

        function stopCarGame() {
            isCarPlaying = false;
            if (carGameInterval) {
                clearInterval(carGameInterval);
                carGameInterval = null;
            }
        }

        function movePlayer(direction) {
            if (!isCarPlaying) return;
            playerCar.x += direction * playerCar.speed;
            playerCar.x = Math.max(10, Math.min(carGameCanvas.width - playerCar.width - 10, playerCar.x));
        }

        carLeftBtn.addEventListener('click', () => movePlayer(-1));
        carRightBtn.addEventListener('click', () => movePlayer(1));

        window.addEventListener('keydown', (e) => {
            if (!carModalOverlay.classList.contains('active')) return;
            if (e.key === 'ArrowLeft' || e.key.toLowerCase() === 'a') { e.preventDefault(); movePlayer(-1); }
            if (e.key === 'ArrowRight' || e.key.toLowerCase() === 'd') { e.preventDefault(); movePlayer(1); }
            if (e.key === 'Enter' && !isCarPlaying) startCarGame();
        });

        function spawnObstacle() {
            const laneCenters = [35, 95, 155, 205];
            const lane = laneCenters[Math.floor(Math.random() * laneCenters.length)];
            const width = 30, height = 45;
            const speed = 3.6 + Math.min(4.0, carScore / 300) + Math.random() * 1.8;
            obstacles.push({ x: lane - width / 2, y: -height - 5, width, height, speed, passed:false });
        }

        function updateCarGame() {
            if (!isCarPlaying) return;

            roadOffset = (roadOffset + 6) % 30;
            carSpawnTimer -= 1;
            if (carSpawnTimer <= 0) {
                spawnObstacle();
                const minFrames = Math.max(26, 54 - Math.floor(carScore / 30));
                carSpawnTimer = minFrames + Math.floor(Math.random() * 22);
            }

            for (let i = obstacles.length - 1; i >= 0; i--) {
                const obs = obstacles[i];
                obs.y += obs.speed;

                if (
                    playerCar.x + 3 < obs.x + obs.width &&
                    playerCar.x + playerCar.width - 3 > obs.x &&
                    playerCar.y + 4 < obs.y + obs.height &&
                    playerCar.y + playerCar.height - 4 > obs.y
                ) {
                    isCarPlaying = false;
                    carScoreText.innerText = 'اصطدام! النقاط النهائية: ' + carScore + ' — اضغط إعادة اللعبة';
                    if (carGameInterval) { clearInterval(carGameInterval); carGameInterval = null; }
                    drawCarGame();
                    return;
                }

                if (!obs.passed && obs.y > carGameCanvas.height) {
                    obs.passed = true;
                    carScore += 10;
                    carScoreText.innerText = 'النقاط: ' + carScore + ' • سرعة المرور: ' + obs.speed.toFixed(1);
                    obstacles.splice(i, 1);
                } else if (obs.y > carGameCanvas.height + 60) {
                    obstacles.splice(i, 1);
                }
            }

            drawCarGame();
        }

        function drawCarShape(ctx, x, y, w, h, body) {
            ctx.save();
            ctx.fillStyle = body;
            ctx.roundRect ? ctx.roundRect(x, y, w, h, 7) : ctx.fillRect(x, y, w, h);
            ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,.78)';
            ctx.fillRect(x + 6, y + 7, w - 12, 9);
            ctx.fillStyle = 'rgba(5,10,18,.85)';
            ctx.fillRect(x + 6, y + 18, w - 12, 10);
            ctx.fillStyle = 'rgba(255,255,255,.9)';
            ctx.fillRect(x - 3, y + 7, 4, 9);
            ctx.fillRect(x + w - 1, y + 7, 4, 9);
            ctx.fillRect(x - 3, y + h - 16, 4, 9);
            ctx.fillRect(x + w - 1, y + h - 16, 4, 9);
            ctx.restore();
        }

        function drawCarGame() {
            carCtx.clearRect(0, 0, carGameCanvas.width, carGameCanvas.height);
            carCtx.fillStyle = '#111520';
            carCtx.fillRect(0, 0, carGameCanvas.width, carGameCanvas.height);

            // حواف الطريق
            carCtx.fillStyle = 'rgba(255,255,255,.07)';
            carCtx.fillRect(4, 0, 4, carGameCanvas.height);
            carCtx.fillRect(carGameCanvas.width - 8, 0, 4, carGameCanvas.height);

            // خطوط الطريق المتحركة
            carCtx.strokeStyle = 'rgba(255,255,255,0.28)';
            carCtx.lineWidth = 2;
            carCtx.setLineDash([16, 14]);
            carCtx.lineDashOffset = roadOffset;
            carCtx.beginPath();
            carCtx.moveTo(80, 0); carCtx.lineTo(80, carGameCanvas.height);
            carCtx.moveTo(160, 0); carCtx.lineTo(160, carGameCanvas.height);
            carCtx.stroke();
            carCtx.setLineDash([]);
            carCtx.lineDashOffset = 0;

            drawCarShape(carCtx, playerCar.x, playerCar.y, playerCar.width, playerCar.height, '#3a7bd5');
            obstacles.forEach(obs => drawCarShape(carCtx, obs.x, obs.y, obs.width, obs.height, '#ff4d4f'));
        }

        // ================= كود الاستوديو الثلاثي الأبعاد (بدون الكاميرا) =================
        const canvasContainer = document.getElementById('canvas-container');
        const scene = new THREE.Scene();

        const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.05, 1000);
        camera.position.set(0, 0.2, 3.0);

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setClearColor(0x000000, 1);
        renderer.outputEncoding = THREE.sRGBEncoding;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.12;
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        canvasContainer.appendChild(renderer.domElement);

        const ambientLight = new THREE.AmbientLight(0xffffff, 0.48);
        scene.add(ambientLight);

        const sunLight = new THREE.DirectionalLight(0xfff1cf, 2.8);
        sunLight.position.set(4, 8, 4);
        sunLight.shadow.mapSize.set(2048, 2048);
        sunLight.shadow.camera.near = 0.5; sunLight.shadow.camera.far = 40;
        sunLight.shadow.camera.left = -8; sunLight.shadow.camera.right = 8;
        sunLight.shadow.camera.top = 8; sunLight.shadow.camera.bottom = -8;
        sunLight.shadow.bias = -0.00025;
        sunLight.castShadow = true;
        scene.add(sunLight);

        const fillStudioLight = new THREE.DirectionalLight(0xffffff, 0.55);
        fillStudioLight.position.set(-5, 3, 2);
        scene.add(fillStudioLight);

        const rimStudioLight = new THREE.PointLight(0xffe6a1, 0.45, 20);
        rimStudioLight.position.set(0, 5, -5);
        scene.add(rimStudioLight);

        // Animated ocean floor: dark background stays black, while the lower stage
        // is a reflective blue sea with gentle moving waves.
        const oceanGeometry = new THREE.PlaneGeometry(80, 80, 100, 100);
        const oceanPositions = oceanGeometry.attributes.position;
        const oceanBaseHeights = new Float32Array(oceanPositions.count);
        for (let i = 0; i < oceanPositions.count; i++) oceanBaseHeights[i] = oceanPositions.getZ(i);
        const oceanMaterial = new THREE.MeshPhongMaterial({
            color: 0x101316, specular: 0xb9b6a8, shininess: 75,
            transparent: false, side: THREE.DoubleSide
        });
        const oceanFloor = new THREE.Mesh(oceanGeometry, oceanMaterial);
        oceanFloor.name = 'TORYAK_Animated_Ocean_Floor';
        oceanFloor.rotation.x = -Math.PI / 2;
        oceanFloor.position.y = -1.8;
        oceanFloor.receiveShadow = true;
        scene.add(oceanFloor);
        let oceanClock = 0;
        function updateToryakOcean(delta = 0.016) {
            oceanClock += Math.min(0.05, Math.max(0, delta));
            const pos = oceanGeometry.attributes.position;
            for (let i = 0; i < pos.count; i++) {
                const x = pos.getX(i), y = pos.getY(i);
                pos.setZ(i, oceanBaseHeights[i] + Math.sin(x * 0.42 + oceanClock * 0.42) * 0.045 + Math.cos(y * 0.31 - oceanClock * 0.31) * 0.035 + Math.sin((x+y) * 0.17 + oceanClock * 0.22) * 0.022);
            }
            pos.needsUpdate = true;
            oceanGeometry.computeVertexNormals();
            if (!window.__toryakFloorColor) oceanMaterial.color.setRGB(0.035 + Math.sin(oceanClock * 0.7) * 0.006, 0.040 + Math.sin(oceanClock * 0.7) * 0.006, 0.045 + Math.sin(oceanClock * 0.7) * 0.006);
            oceanMaterial.specular.setRGB(0.42, 0.39, 0.30);
        }

        // Visible fallback person, used only if an embedded model fails to load.
        function makeStudioHumanFallback() {
            const g = new THREE.Group(); g.name = 'TORYAK_Human_Fallback';
            const mat = (color, roughness=0.72, metalness=0.02) => new THREE.MeshStandardMaterial({color, roughness, metalness});
            const skin = mat(0xc58d68), shirt = mat(0x2876bd), pants = mat(0x202a3b), shoes = mat(0x101318), hair = mat(0x30231d);
            function part(geo, material, x,y,z, sx=1,sy=1,sz=1){ const m=new THREE.Mesh(geo,material);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=true;m.receiveShadow=true;g.add(m);return m; }
            part(new THREE.SphereGeometry(0.22,24,18), skin, 0,1.42,0,0.82,1,0.85);
            part(new THREE.SphereGeometry(0.225,24,16), hair, 0,1.53,-0.035,0.84,0.5,0.86);
            part(new THREE.CylinderGeometry(0.075,0.09,0.2,16), skin, 0,1.17,0);
            part(new THREE.CylinderGeometry(0.25,0.29,0.58,16), shirt, 0,0.78,0,1,1,0.7);
            part(new THREE.CylinderGeometry(0.075,0.095,0.42,12), shirt, -0.34,0.82,0,0.9,1,0.9).rotation.z=0.22;
            part(new THREE.CylinderGeometry(0.075,0.095,0.42,12), shirt, 0.34,0.82,0,0.9,1,0.9).rotation.z=-0.22;
            part(new THREE.SphereGeometry(0.105,16,12), skin, -0.4,0.52,0); part(new THREE.SphereGeometry(0.105,16,12), skin, 0.4,0.52,0);
            part(new THREE.CylinderGeometry(0.105,0.12,0.42,12), pants, -0.14,0.25,0,1,1,0.95);
            part(new THREE.CylinderGeometry(0.105,0.12,0.42,12), pants, 0.14,0.25,0,1,1,0.95);
            part(new THREE.BoxGeometry(0.2,0.09,0.34), shoes, -0.14,-0.05,0.07); part(new THREE.BoxGeometry(0.2,0.09,0.34), shoes, 0.14,-0.05,0.07);
            g.position.set(0,0,0); return g;
        }

        // Safe studio lighting: subtle ambient fill plus a soft key light.
        function ensureStudioLighting() {
            if (typeof scene === 'undefined' || !scene || typeof THREE === 'undefined') return;
            if (!scene.getObjectByName('toryak-soft-ambient')) {
                const ambient = new THREE.HemisphereLight(0x9bb7d8, 0x111318, 1.15);
                ambient.name = 'toryak-soft-ambient'; scene.add(ambient);
            }
            if (!scene.getObjectByName('toryak-soft-key')) {
                const key = new THREE.DirectionalLight(0xd9e8ff, 1.35);
                key.name = 'toryak-soft-key'; key.position.set(4, 7, 5); scene.add(key);
            }
        }

        const loader = new THREE.GLTFLoader();
        let currentModel = null;
        let currentModelFile = null;
        let currentModelFileName = '';
        let currentModelDownloadUrl = '';
        let studioModelLoadRequestId = 0;
        let isAutoRotating = true;
        let currentScaleValue = 1;
        let projectAnimationPlaying = false;
        let projectAnimationMode = 'rotate';
        let projectAnimationSpeed = 1;
        let projectAnimationTime = 0;
        let projectAnimationBaseY = -0.5;
        let projectPathFrames = [];
        let projectPathPlaying = false;
        let projectPathElapsed = 0;
        let projectEmbeddedMixer = null;
        let projectEmbeddedActions = [];
        let studioCameraTarget = new THREE.Vector3(0, 0, 0);
        let studioZoomDistance = 3.5;
        
        let isExploded = false;
        let originalPositions = [];
        let explodeDirections = [];
        let animationProgress = 0;

        // نموذج الولاعة مضمّن داخل الصفحة بالكامل، ولا يحتاج ملفات خارجية.


        // مكتبة نماذج الاستوديو: هذه هي النماذج الموجودة في الموقع فقط.
        

        function studioModelKeyForCard(card) {
            if (!card) return '';
            if (card.dataset.assetKey) return card.dataset.assetKey;
            if (card.dataset.explore) return card.dataset.explore;
            return '';
        }
        function makeSiteModelCardsDraggable() {
            document.querySelectorAll('#modelsGrid .model-card').forEach(card => {
                if (card.dataset.toryakDragReady === '1') return;
                card.dataset.toryakDragReady = '1';
                card.draggable = true;
                card.addEventListener('dragstart', event => {
                    const key = studioModelKeyForCard(card);
                    if (!key) return;
                    event.dataTransfer?.setData('application/x-toryak-model-key', key);
                    event.dataTransfer?.setData('text/plain', `toryak-model:${key}`);
                    if (event.dataTransfer) event.dataTransfer.effectAllowed = 'copy';
                });
            });
        }
        makeSiteModelCardsDraggable();

        function studioQueryNorm(value){
            return normalizeSearch(String(value || '').toLowerCase());
        }

        function findStudioModels(query){
            const q = studioQueryNorm(query);
            if (!q) return STUDIO_MODEL_OPTIONS.slice();
            return STUDIO_MODEL_OPTIONS.filter(model => {
                const hay = studioQueryNorm([model.label, model.query, ...model.aliases].join(' '));
                return hay.includes(q) || q.split(' ').filter(Boolean).every(token => hay.includes(token));
            });
        }

        function renderStudioSearchResults(query){
            const box = document.getElementById('studioSearchResults');
            if (!box) return [];
            const q = String(query || '').trim();
            if (!q) { box.innerHTML = ''; box.classList.remove('active'); return STUDIO_MODEL_OPTIONS.slice(); }
            const matches = findStudioModels(q);
            if (!matches.length) {
                box.innerHTML = '<div class="studio-search-empty">لا يوجد نموذج مطابق للبحث.</div>';
                box.classList.add('active');
                return matches;
            }
            box.innerHTML = matches.map(model =>
                `<button type="button" class="studio-search-result toryak-preview-reveal" data-model-key="${model.key}">${model.label}</button>`
            ).join('');
            box.classList.add('active');
            box.querySelectorAll('.studio-search-result').forEach(btn => {
                btn.addEventListener('click', () => {
                    const item = STUDIO_MODEL_OPTIONS.find(m => m.key === btn.dataset.modelKey);
                    if (!item) return;
                    document.getElementById('searchInput').value = item.label;
                    box.classList.remove('active');
                    box.innerHTML = '';
                    loadProductModel(item.query);
                });
            });
            return matches;
        }

        function hideStudioSearchResults(){
            const box = document.getElementById('studioSearchResults');
            if (box) box.classList.remove('active');
        }

        // Folder import is useful for GLTF projects whose textures live beside the .gltf file.
        (function wireStudioFolderPicker(){
            const choose = document.getElementById('chooseModelFolderBtn');
            const folder = document.getElementById('modelFolderInput');
            if (choose && folder) choose.addEventListener('click', () => folder.click());
        })();

        // When search has no match, explain how to bring the requested model into the site.
        (function wireMissingModelNotice(){
            const input = document.getElementById('searchInput');
            const box = document.getElementById('studioSearchResults');
            if (!input || !box) return;
            input.addEventListener('input', () => {
                const q = input.value.trim();
                if (q && !findStudioModels(q).length) {
                    box.innerHTML = '<div class="studio-search-empty">ما لقينا هذا المجسم. يمكنك رفع ملف GLB/GLTF أو مجلد المشروع من لوحة إنشاء 3D، ثم نشره ليظهر ضمن مشاريع هذا المتصفح.</div>';
                    box.classList.add('active');
                }
            });
        })();

        // A restrained slow response on click, without delaying the actual action.
        (function addSoftClickMotion(){
            if (document.getElementById('toryak-soft-click-motion')) return;
            const style = document.createElement('style');
            style.id = 'toryak-soft-click-motion';
            style.textContent = '.studio-view button,.studio-view .color-dot,.studio-view input[type=color]{transition:transform .28s ease,filter .28s ease,background-color .28s ease,box-shadow .28s ease}.studio-view button:active{transform:scale(.975);filter:brightness(1.12)}.studio-view .action-btn:focus-visible,.studio-view .top-btn:focus-visible{outline:2px solid #8ccaff;outline-offset:2px}';
            document.head.appendChild(style);
        })();

        function findExactStudioModel(query){
            const q = studioQueryNorm(query);
            if (!q) return null;
            return STUDIO_MODEL_OPTIONS.find(model => model.aliases.some(alias => studioQueryNorm(alias) === q)) || null;
        }

        function loadEmbeddedModelSource(source, onLoaded, onError) {
            const url = String(source || '');
            const match = url.match(/^data:[^,]*;base64,([\s\S]+)$/i);
            if (!match) {
                loader.load(url, onLoaded, undefined, onError);
                return;
            }
            let retriedWithLoader = false;
            let settled = false;
            const safeLoaded = (result) => {
                if (settled) return;
                settled = true;
                onLoaded(result);
            };
            const safeError = (error) => {
                if (settled) return;
                settled = true;
                onError(error);
            };
            const retryThroughLoader = (error) => {
                if (retriedWithLoader) { safeError(error); return; }
                retriedWithLoader = true;
                try { loader.load(url, safeLoaded, undefined, safeError); }
                catch (secondError) { safeError(secondError || error); }
            };
            try {
                const raw = atob(match[1].replace(/\s/g, ''));
                const bytes = new Uint8Array(raw.length);
                for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
                loader.parse(bytes.buffer, '', safeLoaded, retryThroughLoader);
            } catch (error) {
                retryThroughLoader(error);
            }
        }

        function loadProductModel(query) {
            const exact = findExactStudioModel(query) || findStudioModels(query)[0];
            if (!exact) {
                document.getElementById('aiStatus').innerText = 'لا يوجد نموذج مطابق للبحث.';
                renderStudioSearchResults(query);
                return;
            }
            const requestId = ++studioModelLoadRequestId;
            // Keep the currently visible model while the replacement loads, so a bad URL never leaves a black viewport.
            currentModelFile = null;
            currentModelFileName = '';
            currentModelDownloadUrl = '';
            if (window.__toryakActiveObjectUrls?.length) {
                window.__toryakActiveObjectUrls.forEach(u => { try { URL.revokeObjectURL(u); } catch (_) {} });
                window.__toryakActiveObjectUrls = [];
            }
            projectAnimationPlaying = false;
            projectAnimationTime = 0;
            projectPathPlaying = false;
            projectPathFrames = [];
            updateProjectPathCount();
            isExploded = false;
            animationProgress = 0;

            const modelSources = {};
            const modelSource = modelSources[exact.key];
            const modelUrl = typeof modelSource === 'function' ? modelSource() : modelSource;
            currentModelDownloadUrl = modelUrl;
            const loadingStatus = document.getElementById('aiStatus');
            if (loadingStatus) loadingStatus.innerText = `جاري تحميل ${exact.label}...`;
            // Do not leave an empty black viewport while the model parser runs.
            if (!currentModel) {
                ensureStudioLighting();
                currentModel = makeStudioHumanFallback();
                scene.add(currentModel);
                finalizeModelSetup();
            }

            const onLoaded = function(gltf) {
                if (requestId !== studioModelLoadRequestId) return;
                const previousModel = currentModel;
                let loadedModel = gltf && (gltf.scene || gltf.scenes?.[0] || gltf);
                if (!loadedModel || !loadedModel.isObject3D) {
                    onError(new Error('ملف النموذج لم يحتوِ على كائن ثلاثي الأبعاد صالح.'));
                    return;
                }
                try {
                    currentModel = loadedModel;
                    setupProjectEmbeddedAnimations(currentModel, Array.isArray(gltf.animations) ? gltf.animations : []);
                    if (Array.isArray(gltf.animations) && gltf.animations.length) {
                        const animStatus = document.getElementById('aiStatus');
                        if (animStatus) animStatus.innerText = `تم تحميل المجسم ومعه ${gltf.animations.length} حركة مضمّنة من Blender.`;
                    }
                    projectPathFrames = [];
                    updateProjectPathCount();
                    projectPathPlaying = false;
                    projectAnimationPlaying = false;
                    isAutoRotating = true;
                    isExploded = false;
                    animationProgress = 0;
                    finalizeModelSetup();
                    if (previousModel && previousModel !== currentModel) scene.remove(previousModel);
                    focusStudioCameraOnModel(currentModel);
                    renderStudioFrame();
                    const status = document.getElementById('aiStatus');
                    if (status) status.innerText = `تم عرض ${exact.label} بنجاح!`;
                } catch (error) {
                    console.error('TORYAK studio model setup failed:', exact.label, error);
                    if (currentModel && currentModel !== previousModel) scene.remove(currentModel);
                    currentModel = previousModel || null;
                    if (currentModel && !currentModel.parent) scene.add(currentModel);
                    if (currentModel) { focusStudioCameraOnModel(currentModel); renderStudioFrame(); }
                    onError(error);
                }
            };
            const onError = function(err) {
                if (requestId !== studioModelLoadRequestId) return;
                console.error('TORYAK studio model load failed:', exact.label, err);
                const status = document.getElementById('aiStatus');
                const detail = String(err && (err.message || err) || 'خطأ غير معروف').replace(/\s+/g, ' ').slice(0, 150);
                if (status) status.innerText = `تعذر تحميل ${exact.label}: ${detail}. عرضنا نموذجًا بشريًا مؤقتًا بدل الشاشة السوداء؛ جرّب نموذجًا آخر أو ارفع ملف GLB.`;
                if (!currentModel) {
                    currentModel = makeStudioHumanFallback();
                    scene.add(currentModel);
                    finalizeModelSetup();
                }
            };

            loadEmbeddedModelSource(modelUrl, onLoaded, onError);
        }

        function createGeometricShape(geometry) {
            const material = new THREE.MeshStandardMaterial({ color: 0x1890ff, roughness: 0.3, metalness: 0.4 });
            currentModel = new THREE.Mesh(geometry, material);
            currentModel.castShadow = true;
            finalizeModelSetup();
            document.getElementById('aiStatus').innerText = `تم إنشاؤه وعرضه بنجاح!`;
        }

        function fitModelToMediumStudio(object3d, targetSize = 2.2) {
            if (!object3d) return 1;
            object3d.scale.set(1, 1, 1);
            object3d.position.set(0, 0, 0);

            const box = new THREE.Box3().setFromObject(object3d);
            const size = box.getSize(new THREE.Vector3());
            const center = box.getCenter(new THREE.Vector3());
            const maxSize = Math.max(size.x || 0, size.y || 0, size.z || 0);
            if (!isFinite(maxSize) || maxSize <= 0) {
                object3d.position.set(0, -0.5, 0);
                return 1;
            }

            const scale = THREE.MathUtils.clamp(targetSize / maxSize, 0.02, 8);
            object3d.scale.setScalar(scale);
            // Center the model and keep it at a comfortable, medium viewing size.
            object3d.position.set(-center.x * scale, -0.45 - center.y * scale, -center.z * scale);
            object3d.traverse(child => {
                if (child.isMesh) {
                    child.castShadow = true;
                    child.receiveShadow = true;
                }
            });
            return scale;
        }

        function finalizeModelSetup() {
            currentScaleValue = fitModelToMediumStudio(currentModel, 2.55);
            projectAnimationBaseY = currentModel ? currentModel.position.y : -0.45;
            projectAnimationTime = 0;
            if (currentModel && !currentModel.parent) scene.add(currentModel);
            setupExplodeData();
            focusStudioCameraOnModel(currentModel);
            renderStudioFrame();
        }

        function setupExplodeData() {
            originalPositions = [];
            explodeDirections = [];
            if (!currentModel) return;

            currentModel.traverse((child) => {
                if (child.isMesh) {
                    originalPositions.push(child.position.clone());
                    const dir = new THREE.Vector3(
                        (Math.random() - 0.5) * 2,
                        Math.random() * 1.5 + 0.2,
                        (Math.random() - 0.5) * 2
                    ).normalize();
                    explodeDirections.push(dir);
                }
            });
        }

        function fitUploadedModelToStudio(object3d) {
            if (!object3d) return 1;
            object3d.scale.set(1, 1, 1);
            object3d.position.set(0, 0, 0);
            object3d.updateMatrixWorld(true);
            const box = new THREE.Box3().setFromObject(object3d);
            const size = box.getSize(new THREE.Vector3());
            const center = box.getCenter(new THREE.Vector3());
            const maxSize = Math.max(size.x || 0, size.y || 0, size.z || 0);
            if (!isFinite(maxSize) || maxSize <= 0 || box.isEmpty()) {
                object3d.position.set(0, -0.5, 0);
                return 1;
            }
            const scale = THREE.MathUtils.clamp(2.55 / maxSize, 0.0001, 1000);
            object3d.scale.setScalar(scale);
            object3d.position.set(-center.x * scale, -0.45 - center.y * scale, -center.z * scale);
            object3d.traverse(child => { if (child.isMesh) { child.castShadow = true; child.receiveShadow = true; child.visible = true; } });
            object3d.updateMatrixWorld(true);
            return scale;
        }

        function focusStudioCameraOnModel(object3d) {
            if (!object3d || !camera || !renderer) return;
            try {
                object3d.updateMatrixWorld(true);
                const box = new THREE.Box3().setFromObject(object3d);
                if (box.isEmpty()) return;
                const sphere = box.getBoundingSphere(new THREE.Sphere());
                const center = sphere.center;
                studioCameraTarget.copy(center);
                const radius = Math.max(0.08, sphere.radius || 0.08);
                const width = Math.max(1, renderer.domElement.clientWidth || window.innerWidth);
                const height = Math.max(1, renderer.domElement.clientHeight || window.innerHeight);
                const aspect = width / height;
                const verticalFov = THREE.MathUtils.degToRad(camera.fov || 62);
                const horizontalFov = 2 * Math.atan(Math.tan(verticalFov / 2) * aspect);
                const limitingFov = Math.max(0.12, Math.min(verticalFov, horizontalFov));
                const distance = Math.max(2.0, (radius / Math.sin(limitingFov / 2)) * 1.18);
                studioZoomDistance = distance;
                camera.aspect = aspect;
                camera.near = Math.max(0.01, distance / 1000);
                camera.far = Math.max(100, distance * 100);
                camera.position.set(center.x, center.y + radius * 0.08, center.z + distance);
                camera.lookAt(center);
                camera.updateProjectionMatrix();
                camera.updateMatrixWorld(true);
            } catch (err) {
                console.warn('Could not auto-frame the project model', err);
                camera.position.set(0, 0.2, 4.5);
                camera.lookAt(0, 0, 0);
                camera.updateProjectionMatrix();
            }
        }

        function showStudioFallbackModel() {
            // Never create the old placeholder made from geometric shapes. Use a real model
            // already included in the site as the new-project starter instead.
            if (currentModel) {
                if (!currentModel.parent) scene.add(currentModel);
                focusStudioCameraOnModel(currentModel);
                renderStudioFrame();
                return;
            }
            const starter = STUDIO_MODEL_OPTIONS.find(item => item.key === 'lighter')
                || STUDIO_MODEL_OPTIONS.find(item => item.key === 'pistol')
                || STUDIO_MODEL_OPTIONS[0];
            if (starter) {
                const status = document.getElementById('aiStatus');
                if (status) status.innerText = `جاري تحميل مجسم ${starter.label} من مكتبة الموقع...`;
                loadProductModel(starter.query);
            } else {
                const status = document.getElementById('aiStatus');
                if (status) status.innerText = 'لم يتم العثور على مجسمات في مكتبة الموقع.';
            }
        }

        function renderStudioFrame() {
            if (renderer && camera) {
                const width = Math.max(1, canvasContainer.clientWidth || window.innerWidth || renderer.domElement.clientWidth || 760);
                const height = Math.max(1, canvasContainer.clientHeight || window.innerHeight || renderer.domElement.clientHeight || 500);
                if (renderer.domElement.width !== Math.round(width * renderer.getPixelRatio()) || renderer.domElement.height !== Math.round(height * renderer.getPixelRatio())) renderer.setSize(width, height, false);
                camera.aspect = width / height;
                camera.updateProjectionMatrix();
                renderer.render(scene, camera);
            }
        }

        function loadCustomFile(event) {
            const files = Array.from(event?.target?.files || []);
            if (files.length) handleCustomModelFiles(files);
        }

        function loadCustomFiles(event) { loadCustomFile(event); }

        async function handleCustomModelFiles(files) {
            let valid = Array.from(files || []).filter(Boolean);
            if (!valid.length) return;
            const requestId = ++studioModelLoadRequestId;

            const status = document.getElementById('aiStatus');
            const setStatus = (text) => { if (status) status.innerText = text; };
            const modelExtensions = new Set(['glb','gltf','obj','stl','fbx','ply','dae','3ds','3mf','amf','wrl','vrml']);
            const extOf = (file) => String(file?.name || '').split('.').pop().toLowerCase();

            // ZIPs are common for game assets and usually carry textures/material files too.
            const archives = valid.filter(file => extOf(file) === 'zip');
            if (archives.length) {
                if (typeof JSZip === 'undefined') {
                    setStatus('مكتبة فك ZIP لم تُحمّل. جرّب رفع ملف المجسم مباشرة أو أعد الاتصال بالإنترنت.');
                    return;
                }
                try {
                    setStatus('جاري فك ضغط ملفات المجسم والخامات...');
                    const unpacked = [];
                    for (const archive of archives) {
                        const zip = await JSZip.loadAsync(archive);
                        const entries = Object.values(zip.files).filter(entry => !entry.dir && extOf({name:entry.name}) !== 'zip');
                        for (const entry of entries) {
                            const blob = await entry.async('blob');
                            const basename = entry.name.split('/').pop() || 'asset';
                            const file = new File([blob], basename, {type: blob.type || ''});
                            try { Object.defineProperty(file, '__toryakRelativePath', {value: entry.name, configurable: true}); } catch (_) { file.__toryakRelativePath = entry.name; }
                            unpacked.push(file);
                        }
                    }
                    valid = valid.filter(file => extOf(file) !== 'zip').concat(unpacked);
                    if (!valid.some(file => modelExtensions.has(extOf(file)))) {
                        setStatus('لم أجد مجسمًا داخل ملف ZIP. تأكد أنه يحتوي على ملف GLB أو GLTF أو OBJ أو FBX أو STL أو صيغة مدعومة أخرى.');
                        return;
                    }
                } catch (archiveError) {
                    console.error('ZIP extraction failed', archiveError);
                    setStatus('تعذر فك ملف ZIP. جرّب فك الضغط على جهازك ثم اسحب ملف المجسم وملفات الخامات معًا.');
                    return;
                }
            }

            const primary = valid.find(file => modelExtensions.has(extOf(file)));
            if (!primary) {
                const blocked = valid[0];
                const ext = extOf(blocked);
                if (['blend','max','ma','mb','usd','usdz','unitypackage','c4d','maxtree'].includes(ext)) {
                    setStatus(`صيغة .${ext} لا تُعرض مباشرة في هذا العارض. صدّر المجسم من برنامجه إلى GLB أو GLTF أو FBX أو OBJ ثم ارفعه هنا.`);
                } else {
                    setStatus('لم أجد ملف مجسم مدعومًا. جرّب GLB أو GLTF أو OBJ أو FBX أو STL أو PLY أو DAE أو 3DS أو ZIP.');
                }
                return;
            }

            const ext = extOf(primary);
            const companions = valid.filter(file => file !== primary);
            currentModelFile = primary;
            currentModelFileName = primary.name;
            currentModelDownloadUrl = '';
            projectAnimationPlaying = false;
            projectAnimationTime = 0;
            isExploded = false;
            animationProgress = 0;
            const fileNameEl = document.getElementById('projectFileName');
            if (fileNameEl) {
                fileNameEl.innerText = companions.length
                    ? `${primary.name} + ${companions.length} ملف مساعد`
                    : `الملف: ${primary.name}`;
            }
            setStatus(`جاري قراءة ${primary.name}...`);

            const fileMap = Object.create(null);
            const objectUrls = [];
            const normalizePath = (value) => {
                let s = String(value || '').replace(/\\/g,'/');
                try { s = decodeURIComponent(s); } catch (_) {}
                return s.replace(/^[.][/]+/, '').replace(/^[/]+/, '').split('?')[0].split('#')[0];
            };
            valid.forEach(file => {
                const url = URL.createObjectURL(file);
                objectUrls.push(url);
                const rel = file.__toryakRelativePath || file.webkitRelativePath || file.name;
                const keys = [file.name, rel, normalizePath(rel), String(rel).split('/').pop()];
                keys.forEach(key => {
                    const clean = normalizePath(key);
                    if (!clean) return;
                    fileMap[clean] = url;
                    fileMap[clean.toLowerCase()] = url;
                });
            });

            // Keep object URLs alive as long as the loaded model may need its textures.
            window.__toryakActiveObjectUrls = window.__toryakActiveObjectUrls || [];
            window.__toryakActiveObjectUrls.forEach(url => { try { URL.revokeObjectURL(url); } catch (_) {} });
            window.__toryakActiveObjectUrls = objectUrls.slice();

            const manager = new THREE.LoadingManager();
            manager.setURLModifier((url) => {
                const clean = normalizePath(url);
                const base = clean.split('/').pop();
                return fileMap[clean] || fileMap[clean.toLowerCase()] || fileMap[base] || fileMap[base.toLowerCase()] || url;
            });

            const readText = (file) => new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(String(reader.result || ''));
                reader.onerror = () => reject(reader.error || new Error('تعذرت قراءة الملف النصي'));
                reader.readAsText(file);
            });
            const readBuffer = (file) => new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.onerror = () => reject(reader.error || new Error('تعذرت قراءة ملف المجسم'));
                reader.readAsArrayBuffer(file);
            });

            const finish = (object3d, animations = []) => {
                if (requestId !== studioModelLoadRequestId) return;
                if (!object3d || !object3d.isObject3D) throw new Error('لم تُرجع أداة التحميل مجسمًا صالحًا');
                let meshCount = 0;
                object3d.visible = true;
                object3d.traverse(child => {
                    child.visible = true;
                    if (!child.isMesh) return;
                    meshCount++;
                    if (child.geometry && !child.geometry.attributes.normal && child.geometry.computeVertexNormals) {
                        try { child.geometry.computeVertexNormals(); } catch (_) {}
                    }
                    if (!child.material) {
                        child.material = new THREE.MeshStandardMaterial({color:0x9aabbc, roughness:0.62, metalness:0.12, side:THREE.DoubleSide});
                    } else {
                        const materials = Array.isArray(child.material) ? child.material : [child.material];
                        materials.forEach(material => {
                            if (!material) return;
                            if ('side' in material) material.side = THREE.DoubleSide;
                            if (material.visible === false) material.visible = true;
                            // Keep valid texture materials; repair only fully invisible materials.
                            if (material.transparent && Number(material.opacity) === 0) {
                                material.opacity = 1;
                                material.transparent = false;
                            }
                            material.needsUpdate = true;
                        });
                    }
                    child.castShadow = true;
                    child.receiveShadow = true;
                });
                if (!meshCount) throw new Error('الملف لا يحتوي على شبكة هندسية Mesh قابلة للعرض');

                const previousModel = currentModel;
                currentModel = object3d;
                setupProjectEmbeddedAnimations(currentModel, Array.isArray(animations) ? animations : (Array.isArray(object3d.animations) ? object3d.animations : []));
                projectPathFrames = [];
                projectPathPlaying = false;
                updateProjectPathCount();
                currentScaleValue = fitUploadedModelToStudio(currentModel);
                if (previousModel && previousModel !== currentModel) scene.remove(previousModel);
                scene.add(currentModel);
                projectAnimationBaseY = currentModel.position.y;
                setupExplodeData();
                isAutoRotating = true;
                projectAnimationPlaying = false;
                focusStudioCameraOnModel(currentModel);
                renderStudioFrame();
                setStatus(`تم تحميل وعرض ${primary.name} بنجاح (${meshCount} جزء).`);
            };

            const fail = (error) => {
                if (requestId !== studioModelLoadRequestId) return;
                console.error(`Could not load 3D model: ${primary.name}`, error);
                let detail = '';
                if (ext === 'gltf' && companions.length === 0) detail = ' ملف GLTF قد يحتاج ملفات BIN والصور والخامات المرافقة؛ اخترها معه أو ارفع مجلد ZIP.';
                else if (ext === 'obj' && !companions.some(file => extOf(file) === 'mtl')) detail = ' إذا كان للملف خامة، اختر ملف MTL والصور معه أيضًا.';
                setStatus(`تعذر عرض ${primary.name}. تأكد من سلامة الملف وأنه ليس بصيغة غير مدعومة.${detail}`);
            };

            try {
                if (ext === 'gltf' || ext === 'glb') {
                    const gltfLoader = new THREE.GLTFLoader(manager);
                    if (THREE.DRACOLoader) {
                        const dracoLoader = new THREE.DRACOLoader();
                        dracoLoader.setDecoderPath('https://www.gstatic.com/draco/v1/decoders/');
                        gltfLoader.setDRACOLoader(dracoLoader);
                    }
                    const data = ext === 'gltf' ? await readText(primary) : await readBuffer(primary);
                    gltfLoader.parse(data, '', gltf => {
                        try { finish(gltf.scene || gltf.scenes?.[0] || gltf, gltf.animations || []); } catch (error) { fail(error); }
                    }, fail);
                    return;
                }

                if (ext === 'obj') {
                    const objText = await readText(primary);
                    const objLoader = new THREE.OBJLoader(manager);
                    const declaredMtl = (objText.match(/^\s*mtllib\s+(.+)$/mi) || [])[1]?.trim().split(/[\\/]/).pop();
                    const mtlFiles = companions.filter(file => extOf(file) === 'mtl');
                    const mtl = mtlFiles.find(file => file.name.toLowerCase() === String(declaredMtl || '').toLowerCase()) || mtlFiles[0];
                    if (mtl && THREE.MTLLoader) {
                        const mtlLoader = new THREE.MTLLoader(manager);
                        const creator = mtlLoader.parse(await readText(mtl), '');
                        creator.preload();
                        objLoader.setMaterials(creator);
                    }
                    finish(objLoader.parse(objText));
                    return;
                }

                if (ext === 'fbx') {
                    if (!THREE.FBXLoader) throw new Error('FBXLoader غير متوفر');
                    const fbx = new THREE.FBXLoader(manager).parse(await readBuffer(primary), '');
                    finish(fbx, fbx.animations || []);
                    return;
                }
                if (ext === 'stl') {
                    if (!THREE.STLLoader) throw new Error('STLLoader غير متوفر');
                    const geometry = new THREE.STLLoader(manager).parse(await readBuffer(primary));
                    const hasColors = !!geometry.hasColors || !!geometry.attributes?.color;
                    const material = new THREE.MeshStandardMaterial({
                        color: hasColors ? 0xffffff : 0x9aabbc,
                        vertexColors: hasColors,
                        opacity: typeof geometry.alpha === 'number' ? geometry.alpha : 1,
                        transparent: typeof geometry.alpha === 'number' && geometry.alpha < 1,
                        roughness: 0.58, metalness: 0.12, side: THREE.DoubleSide
                    });
                    const mesh = new THREE.Mesh(geometry, material);
                    mesh.name = primary.name;
                    finish(mesh);
                    return;
                }
                if (ext === 'ply') {
                    if (!THREE.PLYLoader) throw new Error('PLYLoader غير متوفر');
                    const geometry = new THREE.PLYLoader(manager).parse(await readBuffer(primary));
                    if (!geometry.attributes.normal) geometry.computeVertexNormals();
                    const hasColors = !!geometry.attributes.color;
                    finish(new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({color:0xffffff, vertexColors:hasColors, roughness:0.65, metalness:0.08, side:THREE.DoubleSide})));
                    return;
                }
                if (ext === 'dae') {
                    if (!THREE.ColladaLoader) throw new Error('ColladaLoader غير متوفر');
                    const result = new THREE.ColladaLoader(manager).parse(await readText(primary), '');
                    finish(result.scene || result);
                    return;
                }
                if (ext === '3ds') {
                    if (!THREE.TDSLoader) throw new Error('TDSLoader غير متوفر');
                    finish(new THREE.TDSLoader(manager).parse(await readBuffer(primary), ''));
                    return;
                }
                if (ext === '3mf') {
                    if (!THREE.ThreeMFLoader) throw new Error('ThreeMFLoader غير متوفر');
                    finish(new THREE.ThreeMFLoader(manager).parse(await readBuffer(primary)));
                    return;
                }
                if (ext === 'amf') {
                    if (!THREE.AMFLoader) throw new Error('AMFLoader غير متوفر');
                    finish(new THREE.AMFLoader(manager).parse(await readBuffer(primary)));
                    return;
                }
                if (ext === 'wrl' || ext === 'vrml') {
                    if (!THREE.VRMLLoader) throw new Error('VRMLLoader غير متوفر');
                    finish(new THREE.VRMLLoader(manager).parse(await readText(primary)));
                    return;
                }
                fail(new Error('امتداد غير مدعوم'));
            } catch (error) {
                fail(error);
            }
        }

        function handleCustomModelFile(file) { handleCustomModelFiles(file ? [file] : []); }

        function setupProjectEmbeddedAnimations(root, animations) {
            try {
                if (projectEmbeddedMixer) projectEmbeddedMixer.stopAllAction();
            } catch (_) {}
            projectEmbeddedMixer = null;
            projectEmbeddedActions = [];
            const clips = Array.isArray(animations) ? animations : [];
            if (root && clips.length && typeof THREE.AnimationMixer === 'function') {
                projectEmbeddedMixer = new THREE.AnimationMixer(root);
                projectEmbeddedActions = clips.map(clip => {
                    const action = projectEmbeddedMixer.clipAction(clip);
                    action.setLoop(THREE.LoopRepeat, Infinity);
                    return action;
                });
            }
            const btn = document.getElementById('projectAnimationBtn');
            if (btn) {
                btn.innerText = clips.length ? `▶ تشغيل الحركة (${clips.length})` : '▶ تشغيل';
                btn.title = clips.length ? 'تشغيل أو إيقاف الحركة المضمّنة في ملف النموذج' : 'تشغيل دوران/طفو أو مسار الحركة المحفوظ';
            }
        }

        async function loadRemoteModelUrl(rawUrl) {
            let url;
            try { url = new URL(String(rawUrl || '').trim()); }
            catch (_) { projectToast('اكتب رابط ملف 3D صحيحاً يبدأ بـ http أو https.'); return; }
            if (!['http:','https:'].includes(url.protocol)) { projectToast('الرابط يجب أن يبدأ بـ http أو https.'); return; }
            const ext = url.pathname.split('.').pop().toLowerCase();
            const allowed = new Set(['glb','gltf','obj','fbx','stl','ply','dae','3ds','wrl','vrml']);
            if (!allowed.has(ext)) { projectToast('الرابط يجب أن يشير مباشرة إلى ملف GLB أو GLTF أو OBJ أو FBX أو STL أو PLY أو DAE أو 3DS.'); return; }
            const requestId = ++studioModelLoadRequestId;
            const status = document.getElementById('aiStatus');
            if (status) status.innerText = `جاري تحميل الملف من الرابط: ${url.pathname.split('/').pop()}...`;
            projectAnimationPlaying = false;
            projectPathPlaying = false;
            const fail = (err) => {
                if (requestId !== studioModelLoadRequestId) return;
                console.error('Remote 3D model failed:', err);
                if (status) status.innerText = 'تعذّر تحميل الرابط. تأكد أنه رابط مباشر لملف مجسم وأن الاستضافة تسمح بالتحميل من مواقع أخرى (CORS). جرّب تنزيل الملف ثم رفعه من جهازك.';
            };
            const finish = (object3d, animations=[]) => {
                if (requestId !== studioModelLoadRequestId) return;
                if (!object3d || !object3d.isObject3D) { fail(new Error('No 3D Object3D')); return; }
                let meshes = 0;
                object3d.visible = true;
                object3d.traverse(child => {
                    child.visible = true;
                    if (!child.isMesh) return;
                    meshes++;
                    if (!child.material) child.material = new THREE.MeshStandardMaterial({color:0x9aabbc,roughness:.62,metalness:.1,side:THREE.DoubleSide});
                    const mats = Array.isArray(child.material) ? child.material : [child.material];
                    mats.forEach(mat => { if (mat) { if ('side' in mat) mat.side = THREE.DoubleSide; if (mat.transparent && mat.opacity === 0) {mat.transparent=false;mat.opacity=1;} mat.needsUpdate=true; } });
                    child.castShadow = true; child.receiveShadow = true;
                });
                if (!meshes) { fail(new Error('No mesh found')); return; }
                const previous = currentModel;
                currentModel = object3d;
                currentModelFile = null;
                currentModelFileName = url.pathname.split('/').pop() || 'remote-model.'+ext;
                currentModelDownloadUrl = url.href;
                setupProjectEmbeddedAnimations(currentModel, animations || object3d.animations || []);
                projectPathFrames = []; projectPathPlaying = false; updateProjectPathCount();
                currentScaleValue = fitUploadedModelToStudio(currentModel);
                if (previous && previous !== currentModel) scene.remove(previous);
                scene.add(currentModel);
                setupExplodeData();
                isAutoRotating = true;
                projectAnimationPlaying = false;
                focusStudioCameraOnModel(currentModel);
                renderStudioFrame();
                const fileNameEl = document.getElementById('projectFileName');
                if (fileNameEl) fileNameEl.innerText = `رابط: ${currentModelFileName}`;
                if (status) status.innerText = `تم تحميل وعرض ${currentModelFileName} (${meshes} جزء).`;
            };
            try {
                const manager = new THREE.LoadingManager();
                if (ext === 'glb' || ext === 'gltf') new THREE.GLTFLoader(manager).load(url.href, gltf => finish(gltf.scene || gltf.scenes?.[0] || gltf, gltf.animations || []), undefined, fail);
                else if (ext === 'obj') new THREE.OBJLoader(manager).load(url.href, object => finish(object, object.animations || []), undefined, fail);
                else if (ext === 'fbx') new THREE.FBXLoader(manager).load(url.href, object => finish(object, object.animations || []), undefined, fail);
                else if (ext === 'stl') new THREE.STLLoader(manager).load(url.href, geometry => finish(new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({color:0x9aabbc,roughness:.62,metalness:.1,side:THREE.DoubleSide}))), undefined, fail);
                else if (ext === 'ply') new THREE.PLYLoader(manager).load(url.href, geometry => { if (!geometry.attributes.normal) geometry.computeVertexNormals(); finish(new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({color:0x9aabbc,vertexColors:!!geometry.attributes.color,roughness:.62,side:THREE.DoubleSide}))); }, undefined, fail);
                else if (ext === 'dae') new THREE.ColladaLoader(manager).load(url.href, result => finish(result.scene || result, result.animations || []), undefined, fail);
                else if (ext === '3ds') new THREE.TDSLoader(manager).load(url.href, object => finish(object, object.animations || []), undefined, fail);
                else if (ext === 'wrl' || ext === 'vrml') new THREE.VRMLLoader(manager).load(url.href, object => finish(object, object.animations || []), undefined, fail);
            } catch (err) { fail(err); }
        }

        document.getElementById('loadRemoteModelBtn')?.addEventListener('click', () => {
            const field = document.getElementById('remoteModelUrl');
            if (field?.value.trim()) loadRemoteModelUrl(field.value.trim());
            else { field?.focus(); projectToast('ألصق رابط الملف المباشر أولاً.'); }
        });
        document.getElementById('remoteModelUrl')?.addEventListener('keydown', e => {
            if (e.key === 'Enter') { e.preventDefault(); document.getElementById('loadRemoteModelBtn')?.click(); }
        });

        const dropZone = document.getElementById('dropZone');
        if (dropZone) {
            ['dragenter','dragover'].forEach(type => dropZone.addEventListener(type, (e) => {
                e.preventDefault(); e.stopPropagation(); dropZone.classList.add('drag-over');
            }));
            ['dragleave','drop'].forEach(type => dropZone.addEventListener(type, (e) => {
                e.preventDefault(); e.stopPropagation(); dropZone.classList.remove('drag-over');
            }));
            dropZone.addEventListener('drop', (e) => {
                const transfer = e.dataTransfer;
                const plainText = transfer?.getData('text/plain') || '';
                const publishedId = transfer?.getData('application/x-toryak-published-id') || (plainText.startsWith('toryak-project:') ? plainText.slice(15) : '');
                if (publishedId) { loadPublishedProjectById(publishedId); return; }
                const modelKey = transfer?.getData('application/x-toryak-model-key') || (plainText.startsWith('toryak-model:') ? plainText.slice(13) : '');
                if (modelKey && STUDIO_MODEL_OPTIONS.some(m => m.key === modelKey)) {
                    const item = STUDIO_MODEL_OPTIONS.find(m => m.key === modelKey);
                    loadProductModel(item.query);
                    return;
                }
                const files = Array.from(transfer?.files || []);
                if (files.length) { handleCustomModelFiles(files); return; }
                const uri = (transfer?.getData('text/uri-list') || transfer?.getData('text/plain') || '').split(/\r?\n/).find(line => line && !line.startsWith('#')) || '';
                if (/^https?:\/\//i.test(uri)) loadRemoteModelUrl(uri);
                else if (uri) projectToast('اسحب ملف المجسم أو الصق رابط الملف المباشر في خانة الرابط.');
            });
        }


        // ================= إنشاء المشروع وحفظه محلياً =================
        const projectNameInput = document.getElementById('projectName');
        const projectHeaderTitle = document.getElementById('projectHeaderTitle');
        const projectDescriptionInput = document.getElementById('projectDescription');
        const publishProjectBtn = document.getElementById('publishProjectBtn');
        const publishProjectTopBtn = document.getElementById('publishProjectTopBtn');
        const newProjectBtn = document.getElementById('newProjectBtn');
        const deleteProjectBtn = document.getElementById('deleteProjectBtn');
        let currentStudioProjectId = null;
        const publishedProjectsCount = document.getElementById('publishedProjectsCount');

        function getPublishedProjects() {
            try { return JSON.parse(localStorage.getItem('toryakProjects') || '[]'); }
            catch (_) { return []; }
        }

        function openProjectDB() {
            return new Promise((resolve, reject) => {
                if (!('indexedDB' in window)) return reject(new Error('IndexedDB غير متوفر'));
                const req = indexedDB.open('toryakProjectDB', 1);
                req.onupgradeneeded = () => {
                    if (!req.result.objectStoreNames.contains('projects')) req.result.createObjectStore('projects', {keyPath:'id'});
                };
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error || new Error('DB error'));
            });
        }

        async function saveProjectRecord(record) {
            try {
                const db = await openProjectDB();
                await new Promise((resolve, reject) => {
                    const tx = db.transaction('projects','readwrite');
                    tx.objectStore('projects').put(record);
                    tx.oncomplete = resolve;
                    tx.onerror = () => reject(tx.error);
                });
                db.close();
                return true;
            } catch (err) {
                console.warn('Project DB unavailable, keeping metadata only', err);
                return false;
            }
        }

        async function getPublishedProjectRecord(id) {
            try {
                const db = await openProjectDB();
                const record = await new Promise((resolve, reject) => {
                    const tx = db.transaction('projects','readonly');
                    const req = tx.objectStore('projects').get(Number(id));
                    req.onsuccess = () => resolve(req.result || null);
                    req.onerror = () => reject(req.error);
                });
                db.close();
                return record;
            } catch (err) {
                console.warn('Could not read published project', err);
                return null;
            }
        }

        async function loadPublishedProjectById(id) {
            currentStudioProjectId = Number(id);
            const record = await getPublishedProjectRecord(id);
            if (!record || !record.modelBlob) {
                projectToast('لا يمكن فتح هذا المجسم في هذه الجلسة.');
                return;
            }
            const blob = record.modelBlob;
            const url = URL.createObjectURL(blob);
            currentModelFile = blob;
            currentModelFileName = record.fileName || `${record.name || 'published-model'}.glb`;
            currentModelDownloadUrl = url;
            projectAnimationPlaying = false;
            try {
                if (currentModel) scene.remove(currentModel);
                loader.load(url, gltf => {
                    URL.revokeObjectURL(url);
                    currentModel = gltf.scene || gltf;
                    setupProjectEmbeddedAnimations(currentModel, gltf.animations || []);
                    projectPathFrames = Array.isArray(record.animationFrames) ? record.animationFrames : [];
                    projectPathPlaying = false;
                    updateProjectPathCount();
                    finalizeModelSetup();
                    if (projectNameInput) projectNameInput.value = record.name || '';
                    if (projectHeaderTitle) projectHeaderTitle.value = record.name || '';
                    if (projectDescriptionInput) projectDescriptionInput.value = record.description || '';
                    document.getElementById('aiStatus').innerText = `تم فتح المشروع المنشور: ${record.name || 'نموذج'}`;
                }, undefined, err => {
                    URL.revokeObjectURL(url);
                    console.error(err);
                    projectToast('تعذر فتح المجسم المنشور.');
                });
            } catch (err) {
                URL.revokeObjectURL(url);
                console.error(err);
                projectToast('تعذر فتح المجسم المنشور.');
            }
        }

        function renderPublishedProjects() {
            const grid = document.getElementById('modelsGrid');
            if (!grid) return;
            grid.querySelectorAll('.published-model-card').forEach(el => { removePublishedThumbnail(el); el.remove(); });
            const projects = getPublishedProjects();
            projects.forEach(project => {
                const card = document.createElement('div');
                card.className = 'model-card published-model-card asset-model-card';
                card.dataset.model = `${project.name || ''} ${project.description || ''} published project`;
                card.dataset.keywords = `${project.name || ''} ${project.description || ''} ${project.fileName || ''}`;
                card.dataset.publishedId = String(project.id);
                const projectIsCharacter = !!project.isCharacter || /(human|person|people|character|\bman\b|\bwoman\b|\bboy\b|\bgirl\b|avatar|mixamo|شخص|إنسان|انسان|بشري|شخصية|رجل|امرأة|امراة|ولد|بنت)/i.test(`${project.name || ''} ${project.description || ''}`);
                card.innerHTML = `
                    <div class="asset-model-preview published-model-preview"><canvas></canvas></div>
                    <div class="model-name"></div>
                    <div class="model-desc"></div>
                    <button class="model-open-btn" type="button">استكشاف</button>`;
                card.querySelector('.model-name').textContent = project.name || 'مشروع 3D';
                card.querySelector('.model-desc').textContent = project.description || 'نموذج ثلاثي الأبعاد منشور';
                card.draggable = true;
                card.addEventListener('dragstart', event => {
                    event.dataTransfer?.setData('application/x-toryak-published-id', String(project.id));
                    event.dataTransfer?.setData('text/plain', `toryak-project:${project.id}`);
                    if (event.dataTransfer) event.dataTransfer.effectAllowed = 'copy';
                });
                const openPublishedViewer = (explode=false) => {
                    if (typeof window.openPublishedProjectDetail === 'function') {
                        window.openPublishedProjectDetail(project.id, explode);
                    } else {
                        projectToast('عارض المجسم لم يجهز بعد. حدّث الصفحة ثم حاول مرة أخرى.');
                    }
                };
                card.querySelector('.model-open-btn').addEventListener('click', (event) => {
                    event.preventDefault();event.stopPropagation();openPublishedViewer(false);
                });
                const explodeButton = card.querySelector('.published-explode-btn');
                if (explodeButton) explodeButton.addEventListener('click', (event) => {
                    event.preventDefault();event.stopPropagation();openPublishedViewer(true);
                });
                card.addEventListener('click', (event) => {
                    if (!event.target.closest('button')) openPublishedViewer(false);
                });
                grid.appendChild(card);
                hydratePublishedThumbnail(card, project.id);
            });
            makeSiteModelCardsDraggable();
            if (typeof filterModels === 'function' && document.getElementById('modelsSearchBox')) filterModels(document.getElementById('modelsSearchBox').value);
            updatePublishedProjectsCount();
        }

        // Published project cards share a single WebGL context. Each card canvas is 2D,
        // which prevents one WebGL context per uploaded model and keeps previews responsive.
        const toryakPublishedPreviewState = {
            renderer: null, scratch: null, renderWidth: 0, renderHeight: 0,
            records: new Map(), frameId: 0, lastFrame: 0, observer: null
        };

        function toryakEnsurePublishedPreviewRenderer() {
            const state = toryakPublishedPreviewState;
            if (state.renderer) {
                try { if (!state.renderer.getContext().isContextLost()) return true; } catch (_) {}
                try { state.renderer.dispose(); } catch (_) {}
                state.renderer = null;
                state.scratch = null;
                state.renderWidth = state.renderHeight = 0;
            }
            try {
                state.scratch = document.createElement('canvas');
                state.renderer = new THREE.WebGLRenderer({
                    canvas: state.scratch, alpha: true, antialias: false,
                    powerPreference: 'low-power', preserveDrawingBuffer: true
                });
                state.renderer.setPixelRatio(1);
                state.renderer.setClearColor(0x000000, 0);
                state.renderer.outputEncoding = THREE.sRGBEncoding;
                state.renderer.toneMapping = THREE.ACESFilmicToneMapping;
                state.renderer.toneMappingExposure = 1.08;
                return true;
            } catch (err) {
                console.warn('Could not initialize shared published-model preview renderer', err);
                state.renderer = null;
                state.scratch = null;
                return false;
            }
        }

        function toryakFitPublishedPreview(record) {
            const state = toryakPublishedPreviewState;
            if (!record || !state.renderer || !record.canvas.isConnected) return;
            const host = record.host;
            const rawW = Math.max(180, Math.round(host.clientWidth || 340));
            const rawH = Math.max(180, Math.round(host.clientHeight || 270));
            // Use the preview's real aspect ratio and a model-derived camera distance.
            // This keeps tall, wide, and small uploaded models centered and fully visible.
            const scale = Math.min(1, 520 / rawW, 360 / rawH);
            const width = Math.max(160, Math.round(rawW * scale));
            const height = Math.max(160, Math.round(rawH * scale));
            if (record.canvas.width !== width || record.canvas.height !== height) {
                record.canvas.width = width;
                record.canvas.height = height;
            }
            if (state.renderWidth !== width || state.renderHeight !== height) {
                state.renderer.setSize(width, height, false);
                state.renderWidth = width;
                state.renderHeight = height;
            }
            record.camera.aspect = width / height;
            const verticalFov = THREE.MathUtils.degToRad(record.camera.fov);
            const horizontalFov = 2 * Math.atan(Math.tan(verticalFov / 2) * record.camera.aspect);
            const limitingHalfFov = Math.max(0.08, Math.min(verticalFov, horizontalFov) / 2);
            const radius = Math.max(0.05, record.fitRadius || 1.15);
            const distance = radius / Math.sin(limitingHalfFov) * 1.18;
            record.camera.position.set(0, radius * 0.035, distance);
            record.camera.lookAt(0, 0, 0);
            record.camera.near = Math.max(0.001, distance - radius * 2.2);
            record.camera.far = distance + radius * 4;
            record.camera.updateProjectionMatrix();
        }

        function toryakDrawPublishedPreview(record) {
            const state = toryakPublishedPreviewState;
            if (!record || !state.renderer || !record.ctx || !record.canvas.isConnected) return;
            try {
                toryakFitPublishedPreview(record);
                state.renderer.setClearColor(0x000000, 0);
                state.renderer.render(record.scene, record.camera);
                record.ctx.clearRect(0, 0, record.canvas.width, record.canvas.height);
                record.ctx.drawImage(state.scratch, 0, 0, record.canvas.width, record.canvas.height);
            } catch (err) {
                console.warn('Could not draw published model preview', record.id, err);
            }
        }

        function toryakDisposePublishedPreviewRecord(record) {
            if (!record) return;
            if (record.objectUrl) { try { URL.revokeObjectURL(record.objectUrl); } catch (_) {} }
            record.scene?.traverse?.(node => {
                if (!node.isMesh) return;
                node.geometry?.dispose?.();
                const materials = Array.isArray(node.material) ? node.material : [node.material];
                materials.forEach(material => {
                    if (!material) return;
                    Object.values(material).forEach(value => { if (value && value.isTexture) value.dispose(); });
                    material.dispose?.();
                });
            });
        }

        function toryakStopPublishedPreviewLoopIfIdle() {
            const state = toryakPublishedPreviewState;
            const hasVisible = Array.from(state.records.values()).some(r => r.visible && r.canvas.isConnected);
            if (!hasVisible && state.frameId) {
                cancelAnimationFrame(state.frameId);
                state.frameId = 0;
                state.lastFrame = 0;
            }
        }

        function toryakRunPublishedPreviewFrame(now) {
            const state = toryakPublishedPreviewState;
            state.frameId = 0;
            if (document.hidden) return;
            // Cap card animation at ~24 FPS. Rotation remains quick without maxing out the GPU.
            if (state.lastFrame && now - state.lastFrame < 41) {
                state.frameId = requestAnimationFrame(toryakRunPublishedPreviewFrame);
                return;
            }
            const dt = state.lastFrame ? Math.min(0.08, (now - state.lastFrame) / 1000) : 0.041;
            state.lastFrame = now;
            let anyVisible = false;
            for (const [id, record] of state.records) {
                if (!record.canvas.isConnected) {
                    toryakDisposePublishedPreviewRecord(record);
                    state.records.delete(id);
                    continue;
                }
                if (!record.visible) continue;
                anyVisible = true;
                // 1.65 rad/s gives a noticeably faster full turn (~3.8 seconds).
                record.root.rotation.y += 0.4 * dt;
                toryakDrawPublishedPreview(record);
            }
            if (anyVisible && !document.hidden) state.frameId = requestAnimationFrame(toryakRunPublishedPreviewFrame);
            else state.lastFrame = 0;
        }

        function toryakStartPublishedPreviewLoop() {
            const state = toryakPublishedPreviewState;
            if (!state.frameId && !document.hidden && Array.from(state.records.values()).some(r => r.visible && r.canvas.isConnected)) {
                state.lastFrame = 0;
                state.frameId = requestAnimationFrame(toryakRunPublishedPreviewFrame);
            }
        }

        window.__toryakRefreshPublishedPreviews = function(){
            const state=toryakPublishedPreviewState;
            for(const record of state.records.values()){
                const rect=record.host.getBoundingClientRect();
                record.visible=!!(rect.width>0&&rect.height>0&&rect.bottom>0&&rect.top<window.innerHeight&&rect.right>0&&rect.left<window.innerWidth);
                if(record.visible)toryakDrawPublishedPreview(record);
            }
            toryakStartPublishedPreviewLoop();
        };

        function toryakEnsurePublishedPreviewObserver() {
            const state = toryakPublishedPreviewState;
            if (state.observer || !('IntersectionObserver' in window)) return;
            state.observer = new IntersectionObserver(entries => {
                for (const entry of entries) {
                    const record = state.records.get(String(entry.target.dataset.publishedId || ''));
                    if (!record) continue;
                    record.visible = !!entry.isIntersecting;
                    if (record.visible) toryakDrawPublishedPreview(record);
                }
                toryakStartPublishedPreviewLoop();
                toryakStopPublishedPreviewLoopIfIdle();
            }, { root: null, rootMargin: '80px 0px' });
        }

        function removePublishedThumbnail(card) {
            if (!card) return;
            const state = toryakPublishedPreviewState;
            const id = String(card.dataset.publishedId || '');
            const record = state.records.get(id);
            if (record) {
                state.observer?.unobserve?.(record.host);
                state.records.delete(id);
                toryakDisposePublishedPreviewRecord(record);
            }
            toryakStopPublishedPreviewLoopIfIdle();
        }

        async function hydratePublishedThumbnail(card, id) {
            const canvas = card?.querySelector('canvas');
            const host = card?.querySelector('.published-model-preview');
            if (!canvas || !host || typeof THREE === 'undefined' || !THREE.GLTFLoader) return;
            const idKey = String(id);
            card.dataset.publishedId = idKey;
            host.dataset.publishedId = idKey;
            if (card.dataset.previewLoading === '1' || card.dataset.previewReady === '1') return;
            card.dataset.previewLoading = '1';
            const ctx = canvas.getContext('2d', { alpha: true });
            if (!ctx) { delete card.dataset.previewLoading; return; }
            let recordData=null;
            try{recordData=await getPublishedProjectRecord(id);}catch(dbErr){console.warn('Could not read published model for its card preview',id,dbErr);}
            if (!card.isConnected) { delete card.dataset.previewLoading; return; }
            if (!recordData?.modelBlob) {
                delete card.dataset.previewLoading;
                const c=canvas.getContext('2d');if(c){c.clearRect(0,0,canvas.width,canvas.height);c.fillStyle='rgba(255,255,255,.58)';c.font='13px Segoe UI,Arial';c.textAlign='center';c.fillText('ملف المعاينة غير متاح',canvas.width/2,canvas.height/2);}
                return;
            }
            if (!toryakEnsurePublishedPreviewRenderer()) {
                delete card.dataset.previewLoading;
                const c=canvas.getContext('2d');if(c){c.clearRect(0,0,canvas.width,canvas.height);c.fillStyle='rgba(255,255,255,.58)';c.font='13px Segoe UI,Arial';c.textAlign='center';c.fillText('المعاينة غير متاحة على هذا الجهاز',canvas.width/2,canvas.height/2);}
                return;
            }

            const scene = new THREE.Scene();
            scene.add(new THREE.HemisphereLight(0xffffff, 0x171c26, 1.55));
            const keyLight = new THREE.DirectionalLight(0xffffff, 2.15);
            keyLight.position.set(3, 4, 5);
            scene.add(keyLight);
            const fillLight = new THREE.DirectionalLight(0x7fb4ff, 0.72);
            fillLight.position.set(-3, 1, 2);
            scene.add(fillLight);
            const camera = new THREE.PerspectiveCamera(34, 1.3, 0.01, 2000);
            camera.position.set(0, 0.06, 4.35);
            camera.lookAt(0, 0, 0);
            const objectUrl = URL.createObjectURL(recordData.modelBlob);

            const failPreview = (err) => {
                try { URL.revokeObjectURL(objectUrl); } catch (_) {}
                delete card.dataset.previewLoading;
                delete card.dataset.previewReady;
                console.warn('Published thumbnail failed', err);
                const existing = canvas.getContext('2d');
                if (existing) {
                    existing.clearRect(0, 0, canvas.width, canvas.height);
                    existing.save();existing.fillStyle='rgba(255,255,255,.55)';existing.font='13px Segoe UI,Arial';existing.textAlign='center';
                    existing.fillText('تعذر عرض المعاينة — اضغط استكشاف',canvas.width/2,canvas.height/2);existing.font='10px Segoe UI,Arial';existing.fillText(/not valid JSON|JSON/i.test(String((err&&err.message)||err||''))?'ملف قديم تالف — أعد نشر المجسم':String((err&&err.message)||err||'').slice(0,60),canvas.width/2,canvas.height/2+18);existing.restore();
                }
            };
            try {
                const onGltf = gltf => {
                    try{URL.revokeObjectURL(objectUrl);}catch(_){}
                    let wrapper=null;
                    try {
                        if (!card.isConnected) {
                            const orphan = { scene, canvas, ctx, objectUrl: null, root: gltf.scene || gltf };
                            toryakDisposePublishedPreviewRecord(orphan);
                            delete card.dataset.previewLoading;
                            return;
                        }
                        const model = gltf.scene || gltf.scenes?.[0] || gltf;
                        if (!model || !model.traverse) throw new Error('ملف المجسم لا يحتوي مشهداً قابلاً للعرض.');
                        model.updateMatrixWorld(true);
                        wrapper = new THREE.Group();
                        wrapper.add(model);
                        wrapper.updateMatrixWorld(true);
                        // Ignore hidden helper meshes/objects so they cannot shrink the real model
                        // to a tiny dot or pull it away from the center of its gallery card.
                        const box = new THREE.Box3();
                        let visibleMeshCount = 0;
                        model.traverse(node => {
                            if (!node.isMesh || !node.geometry) return;
                            let visible = true;
                            for (let parent = node; parent && parent !== wrapper; parent = parent.parent) {
                                if (parent.visible === false) { visible = false; break; }
                            }
                            if (!visible) return;
                            if (!node.geometry.boundingBox) node.geometry.computeBoundingBox?.();
                            const meshBox = new THREE.Box3().setFromObject(node);
                            if (![meshBox.min.x,meshBox.min.y,meshBox.min.z,meshBox.max.x,meshBox.max.y,meshBox.max.z].every(Number.isFinite)) return;
                            box.union(meshBox);
                            visibleMeshCount++;
                        });
                        if (!visibleMeshCount || box.isEmpty()) throw new Error('لا توجد أجزاء ظاهرة قابلة للمعاينة في ملف GLB.');
                        const sphere = box.getBoundingSphere(new THREE.Sphere());
                        const center = sphere.center.clone();
                        const radius = Math.max(0.001, sphere.radius);
                        if (!Number.isFinite(radius) || radius <= 0) throw new Error('المجسم لا يحتوي أبعاداً صالحة للمعاينة.');
                        const root = new THREE.Group();
                        root.add(wrapper);
                        const fitRadius = 1.12;
                        root.scale.setScalar(fitRadius / radius);
                        root.position.copy(center).multiplyScalar(-root.scale.x);
                        root.rotation.y = -0.28;
                        scene.add(root);
                        wrapper.traverse(node => { if (node.isMesh) { node.castShadow = false; node.receiveShadow = false; } });
                        const record = {
                            id: idKey, card, host, canvas, ctx, scene, camera, root, fitRadius,
                            visible: !('IntersectionObserver' in window) && host.getBoundingClientRect().width > 0,
                            objectUrl: null
                        };
                        const old = toryakPublishedPreviewState.records.get(idKey);
                        if (old) toryakDisposePublishedPreviewRecord(old);
                        toryakPublishedPreviewState.records.set(idKey, record);
                        card.dataset.previewReady = '1';
                        delete card.dataset.previewLoading;
                        toryakEnsurePublishedPreviewObserver();
                        if (toryakPublishedPreviewState.observer) toryakPublishedPreviewState.observer.observe(host);
                        toryakDrawPublishedPreview(record);
                        toryakStartPublishedPreviewLoop();
                    } catch (callbackError) {
                        if (wrapper) toryakDisposePublishedPreviewRecord({scene,root:wrapper,canvas,ctx});
                        failPreview(callbackError);
                    }
                };
                const retryParse = err => {
                    if (card.dataset.parseRetry === '1') { failPreview(err); return; }
                    card.dataset.parseRetry = '1';
                    recordData.modelBlob.arrayBuffer().then(buf => loader.parse(buf, '', onGltf, failPreview)).catch(failPreview);
                };
                loader.load(objectUrl, onGltf, undefined, retryParse);
            } catch (loadError) { failPreview(loadError); }
        }

        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                if (toryakPublishedPreviewState.frameId) cancelAnimationFrame(toryakPublishedPreviewState.frameId);
                toryakPublishedPreviewState.frameId = 0;
                toryakPublishedPreviewState.lastFrame = 0;
            } else {
                toryakStartPublishedPreviewLoop();
            }
        });

        function updatePublishedProjectsCount() {
            if (publishedProjectsCount) publishedProjectsCount.innerText = getPublishedProjects().length;
        }

        function restoreProjectDraft() {
            try {
                const draftName = localStorage.getItem('toryakDraftName') || '';
                const draftDescription = localStorage.getItem('toryakDraftDescription') || '';
                if (projectNameInput && !projectNameInput.value) projectNameInput.value = draftName;
                if (projectHeaderTitle && !projectHeaderTitle.value) projectHeaderTitle.value = draftName;
                if (projectDescriptionInput && !projectDescriptionInput.value) projectDescriptionInput.value = draftDescription;
            } catch (_) {}
        }

        function projectToast(message) {
            let toast = document.getElementById('projectToast');
            if (!toast) {
                toast = document.createElement('div');
                toast.id = 'projectToast';
                toast.className = 'project-toast';
                document.body.appendChild(toast);
            }
            toast.innerText = message;
            toast.classList.add('active');
            clearTimeout(window.__toryakToastTimer);
            window.__toryakToastTimer = setTimeout(() => toast.classList.remove('active'), 2600);
        }

        // ================= صلاحيات النشر =================
        // في النسخة الثابتة من الموقع لا توجد خوادم مصادقة حقيقية؛ لذلك نستخدم جلسة محلية
        // للتجربة. المستخدم العادي يحتاج لتسجيل الدخول، وصاحب الموقع يستطيع الدخول بوضع المالك.
        const OWNER_ACCESS_CODE = 'TORYAK-OWNER-2026';

        function getAuthState() {
            try {
                const state = JSON.parse(localStorage.getItem('toryakAuth') || 'null');
                return state && typeof state === 'object' ? state : { loggedIn:false, role:'guest' };
            } catch (_) {
                return { loggedIn:false, role:'guest' };
            }
        }

        function setAuthState(role, provider='local') {
            const state = { loggedIn:true, role:role === 'owner' ? 'owner' : 'user', provider, at:new Date().toISOString() };
            try { localStorage.setItem('toryakAuth', JSON.stringify(state)); } catch (_) {}
            return state;
        }

        function isAllowedToPublish() {
            const state = getAuthState();
            return state.role === 'owner' || state.loggedIn === true;
        }

        function showAuthForPublish() {
            const modal = document.getElementById('authModal');
            if (modal) modal.classList.add('active');
            projectToast('سجّل الدخول عبر Google أو Microsoft للنشر.');
        }

        window.demoLogin = function(provider) {
            setAuthState('user', provider);
            document.getElementById('authModal')?.classList.remove('active');
            updatePublishAccessUI?.();
            projectToast(`تم تسجيل الدخول عبر ${provider}`);
        };

        window.ownerLogin = function() {
            const code = window.prompt('أدخل رمز صاحب الموقع:');
            if (code === null) return;
            if (code !== OWNER_ACCESS_CODE) {
                projectToast('رمز صاحب الموقع غير صحيح.');
                return;
            }
            setAuthState('owner', 'owner');
            document.getElementById('authModal')?.classList.remove('active');
            updatePublishAccessUI?.();
            projectToast('تم تفعيل صلاحية صاحب الموقع. يمكنك النشر بدون تسجيل دخول.');
        };

        document.getElementById('googleLoginBtn')?.addEventListener('click', () => demoLogin('Google'));
        document.getElementById('microsoftLoginBtn')?.addEventListener('click', () => demoLogin('Microsoft'));

        function updatePublishAccessUI() {
            const state = getAuthState();
            const buttons = [publishProjectBtn, publishProjectTopBtn].filter(Boolean);
            buttons.forEach(btn => {
                btn.dataset.authRequired = state.role === 'owner' || state.loggedIn ? '0' : '1';
                btn.title = state.role === 'owner' ? 'صاحب الموقع: النشر متاح' : (state.loggedIn ? 'النشر متاح بعد تسجيل الدخول' : 'تسجيل الدخول مطلوب للنشر');
            });
        }
        updatePublishAccessUI();
        window.tgRenderModels = function () {
            try { renderPublishedProjects(); updatePublishedProjectsCount(); } catch (_) {}
            try { const mb = document.getElementById('modelsSearchBox'); if (typeof filterModels === 'function' && mb) filterModels(mb.value); } catch (_) {}
            try { const mm = document.getElementById('mainSearchBox'), pn = document.getElementById('mainSearchSuggestions'); if (mm && mm.value.trim() && pn && pn.classList.contains('active') && typeof renderMainSearchSuggestions === 'function') renderMainSearchSuggestions(mm.value); } catch (_) {}
        };
        async function publishProject() {
            if (!isAllowedToPublish()) {
                showAuthForPublish();
                return;
            }
            const name = (projectNameInput?.value || '').trim();
            const description = (projectDescriptionInput?.value || '').trim();
            if (!name) {
                projectNameInput?.focus();
                projectToast('اكتب اسم المشروع أولاً');
                return;
            }
            if (!currentModel) {
                projectToast('ارفع أو اختر نموذجاً ثلاثي الأبعاد أولاً');
                return;
            }

            if (window.tgNameTaken && await window.tgNameTaken(name, null)) { projectNameInput?.focus(); projectToast('⚠ هذا الاسم مطابق لاسم لعبة أو مجسم موجود. اختر اسمًا آخر.'); return; }
            const id = Date.now();
            currentStudioProjectId = id;
            let modelBlob = null;
            let modelExt = 'glb';
            try {
                modelBlob = await exportCurrentModelGLBBlob(currentModel);
            } catch (exportErr) {
                console.warn('GLB publish export failed', exportErr);
                const ext = String(currentModelFileName || '').split('.').pop().toLowerCase();
                if (currentModelFile && ext === 'glb') {
                    modelBlob = currentModelFile;
                    modelExt = 'glb';
                } else {
                    projectToast('لم أستطع تحويل هذا المجسم إلى GLB للنشر. جرّب تحميله كـ GLB أو أعد رفعه ثم النشر.');
                    return;
                }
            }
            if (!modelBlob) {
                projectToast('لا يوجد ملف مجسم صالح للنشر.');
                return;
            }

            const record = {
                id, name, description,
                fileName: `${name.replace(/[\\/:*?"<>|]+/g,'_') || 'toryak-project'}.glb`,
                modelExt,
                modelBlob,
                animationFrames: projectPathFrames.map(frame => ({position:[...frame.position],rotation:[...frame.rotation],scale:[...frame.scale],at:frame.at})),
                createdAt: new Date().toISOString()
            };

            const __me = (window.__me && window.__me()) || {};
            record.owner = __me.id || ''; record.ownerName = __me.name || ''; record.ownerPhoto = __me.photo || '';
            const savedFullProject = await saveProjectRecord(record);
            const projects = getPublishedProjects();
            projects.unshift({id,name,description,fileName:record.fileName,createdAt:record.createdAt,hasModel:savedFullProject,animationFrames:record.animationFrames,owner:record.owner,ownerName:record.ownerName,ownerPhoto:record.ownerPhoto});
            try { localStorage.setItem('toryakProjects', JSON.stringify(projects.slice(0, 50))); }
            catch (storageError) { console.warn('Could not update project search index', storageError); projectToast('حُفظ المجسم في قاعدة البيانات المحلية، لكن تعذّر تحديث فهرس البحث بسبب مساحة التخزين.'); }
            if (window.tgCloud && savedFullProject) {
                try {
                    if (await window.tgCloud.ok()) {
                        projectToast('جارٍ نشر المجسم للجميع...');
                        await window.tgCloud.putModel(record);
                        const ps = getPublishedProjects(); const pi = ps.find(p => Number(p.id) === Number(id));
                        if (pi) { pi.cloudSynced = true; try { localStorage.setItem('toryakProjects', JSON.stringify(ps)); } catch (_) {} }
                    }
                } catch (ce) { console.warn('cloud publish', ce); projectToast(ce && ce.message === 'name-taken' ? '⚠ هذا الاسم مطابق لاسم موجود.' : 'حُفظ المجسم على جهازك فقط، تعذر النشر للجميع ['+((ce&&(ce.code||ce.message))||'')+']'); }
            }
            notifyModelReleased(name, id);
            renderPublishedProjects();
            updatePublishedProjectsCount();
            if (typeof filterModels === 'function' && document.getElementById('modelsSearchBox')) filterModels(document.getElementById('modelsSearchBox').value);
            projectToast(savedFullProject ? `تم حفظ مشروع «${name}» محلياً، وأضيف إلى بحث النماذج في هذا المتصفح.` : `حُفظ اسم مشروع «${name}» محلياً، لكن ملف المجسم لم يُحفظ بالكامل.`);
            document.getElementById('aiStatus').innerText = savedFullProject ? `المشروع «${name}» محفوظ ويمكن تحميله` : `المشروع «${name}» منشور محلياً`;
        }


        function setProjectAnimationMode(mode) {
            projectAnimationMode = mode || 'rotate';
            projectAnimationTime = 0;
            projectAnimationBaseY = currentModel ? currentModel.position.y : -0.5;
            const labels = { rotate:'↻ دوران', float:'↕ طفو', inspect:'◌ عرض' };
            document.getElementById('aiStatus').innerText = `وضع الأنيميشن: ${labels[projectAnimationMode] || mode}`;
        }

        function updateProjectPathCount() {
            const el = document.getElementById('projectPathCount');
            if (el) el.textContent = `الوضعيات المحفوظة: ${projectPathFrames.length}`;
            const playBtn = document.getElementById('playProjectPathBtn');
            if (playBtn && !projectPathPlaying) playBtn.textContent = 'تشغيل المسار';
        }
        function captureProjectPose() {
            if (!currentModel) { projectToast('اختر أو ارفع مجسماً أولاً.'); return; }
            projectAnimationPlaying = false;
            projectPathPlaying = false;
            projectPathFrames.push({
                position: [currentModel.position.x,currentModel.position.y,currentModel.position.z],
                rotation: [currentModel.rotation.x,currentModel.rotation.y,currentModel.rotation.z],
                scale: [currentModel.scale.x,currentModel.scale.y,currentModel.scale.z],
                at: Date.now()
            });
            updateProjectPathCount();
            try { localStorage.setItem('toryakDraftAnimationFrames', JSON.stringify(projectPathFrames)); } catch (_) {}
            projectToast(`تم حفظ الوضعية ${projectPathFrames.length}. حرّك المجسم لحفظ الوضعية التالية.`);
        }
        function clearProjectPath() {
            projectPathFrames = [];
            projectPathPlaying = false;
            projectPathElapsed = 0;
            updateProjectPathCount();
            try { localStorage.removeItem('toryakDraftAnimationFrames'); } catch (_) {}
            projectToast('تم مسح وضعيات الحركة.');
        }
        function toggleProjectPathPlayback() {
            if (projectPathFrames.length < 2) {
                projectToast('احفظ وضعيتين على الأقل: احفظ الأولى، حرّك المجسم، ثم احفظ الثانية.');
                return;
            }
            projectAnimationPlaying = false;
            isAutoRotating = false;
            projectPathElapsed = 0;
            projectPathPlaying = !projectPathPlaying;
            const btn = document.getElementById('playProjectPathBtn');
            if (btn) btn.textContent = projectPathPlaying ? 'إيقاف المسار' : 'تشغيل المسار';
            if (projectPathPlaying) {
                const first = projectPathFrames[0];
                currentModel.position.fromArray(first.position);
                currentModel.rotation.set(...first.rotation);
                currentModel.scale.fromArray(first.scale);
            }
        }
        function updateProjectPathAnimation(dtMs) {
            if (!projectPathPlaying || !currentModel || projectPathFrames.length < 2) return;
            const segmentDuration = 1300;
            const totalDuration = segmentDuration * (projectPathFrames.length - 1);
            projectPathElapsed += Math.max(1, dtMs) * projectAnimationSpeed;
            if (projectPathElapsed >= totalDuration) {
                const last = projectPathFrames[projectPathFrames.length - 1];
                currentModel.position.fromArray(last.position);
                currentModel.rotation.set(...last.rotation);
                currentModel.scale.fromArray(last.scale);
                projectPathPlaying = false;
                const btn = document.getElementById('playProjectPathBtn');
                if (btn) btn.textContent = 'تشغيل المسار';
                return;
            }
            const segment = Math.min(projectPathFrames.length - 2, Math.floor(projectPathElapsed / segmentDuration));
            const t = (projectPathElapsed - segment * segmentDuration) / segmentDuration;
            const a = projectPathFrames[segment], b = projectPathFrames[segment + 1];
            for (let i=0;i<3;i++) {
                currentModel.position.setComponent(i, a.position[i] + (b.position[i]-a.position[i])*t);
                currentModel.scale.setComponent(i, a.scale[i] + (b.scale[i]-a.scale[i])*t);
            }
            currentModel.rotation.set(
                a.rotation[0] + (b.rotation[0]-a.rotation[0])*t,
                a.rotation[1] + (b.rotation[1]-a.rotation[1])*t,
                a.rotation[2] + (b.rotation[2]-a.rotation[2])*t
            );
        }
        document.getElementById('captureProjectPoseBtn')?.addEventListener('click', captureProjectPose);
        document.getElementById('playProjectPathBtn')?.addEventListener('click', toggleProjectPathPlayback);
        document.getElementById('clearProjectPathBtn')?.addEventListener('click', clearProjectPath);

        function toggleProjectAnimation() {
            if (!currentModel) { projectToast('ارفع أو اختر نموذجاً ثلاثي الأبعاد أولاً'); return; }
            isAutoRotating = false;
            projectPathPlaying = false;
            if (projectEmbeddedActions.length && projectEmbeddedMixer) {
                const running = projectEmbeddedActions.some(action => action.isRunning());
                if (running) projectEmbeddedActions.forEach(action => action.stop());
                else projectEmbeddedActions.forEach(action => { action.reset(); action.play(); });
                const btn = document.getElementById('projectAnimationBtn');
                if (btn) btn.innerText = running ? '▶ تشغيل' : '⏸ إيقاف';
                if (typeof window.projectToast === 'function') projectToast(running ? 'تم إيقاف حركة المجسم المضمّنة.' : 'تم تشغيل الحركة المضمّنة في المجسم.');
                return;
            }
            projectAnimationPlaying = !projectAnimationPlaying;
            const btn = document.getElementById('projectAnimationBtn');
            if (btn) btn.innerText = projectAnimationPlaying ? '⏸ إيقاف' : '▶ تشغيل';
        }

        function downloadBlob(blob, filename) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = filename || 'toryak-project';
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1500);
        }

        function exportCurrentModelGLBBlob(root) {
            return new Promise((resolve, reject) => {
                if (!root) return reject(new Error('لا يوجد مجسم للتصدير'));
                if (typeof THREE.GLTFExporter === 'undefined') return reject(new Error('GLTFExporter غير متوفر'));
                const exporter = new THREE.GLTFExporter();
                exporter.parse(root, result => {
                    if (result instanceof ArrayBuffer) resolve(new Blob([result], {type:'model/gltf-binary'}));
                    else resolve(new Blob([JSON.stringify(result)], {type:'model/gltf+json'}));
                }, err => reject(err || new Error('تعذر تصدير المجسم')), {binary:true, embedImages:true, trs:false, onlyVisible:false});
            });
        }

        function exportCurrentModelGLB(root, filename) {
            return new Promise((resolve, reject) => {
                if (!root) return reject(new Error('لا يوجد مجسم للتصدير'));
                if (typeof THREE.GLTFExporter === 'undefined') return reject(new Error('GLTFExporter غير متوفر'));
                const exporter = new THREE.GLTFExporter();
                exporter.parse(root, result => {
                    const blob = result instanceof ArrayBuffer
                        ? new Blob([result], {type:'model/gltf-binary'})
                        : new Blob([JSON.stringify(result)], {type:'model/gltf+json'});
                    downloadBlob(blob, filename);
                    resolve();
                }, err => reject(err || new Error('تعذر تصدير المجسم')), {
                    binary: true,
                    embedImages: true,
                    trs: false,
                    onlyVisible: false
                });
            });
        }

        async function downloadCurrentProject() {
            const rawName = (projectNameInput?.value || '').trim();
            const name = rawName.replace(/[\\/:*?"<>|]+/g,'_') || 'toryak-project';
            try {
                if (currentModel) {
                    await exportCurrentModelGLB(currentModel, `${name}.glb`);
                    projectToast('تم تحميل المجسم باللون والتعديلات الحالية');
                    return;
                }
                if (currentModelFile) {
                    const ext = currentModelFileName.split('.').pop() || 'glb';
                    downloadBlob(currentModelFile, `${name}.${ext}`);
                    projectToast('بدأ تحميل ملف المشروع');
                    return;
                }
                if (currentModelDownloadUrl && !currentModelDownloadUrl.includes('service_pistol_4k')) {
                    const res = await fetch(currentModelDownloadUrl);
                    if (!res.ok) throw new Error('download failed');
                    const blob = await res.blob();
                    const clean = currentModelDownloadUrl.split('?')[0].split('/').pop() || 'model.glb';
                    const ext = clean.split('.').pop() || 'glb';
                    downloadBlob(blob, `${name}.${ext}`);
                    projectToast('بدأ تحميل المجسم');
                    return;
                }
                throw new Error('no downloadable model');
            } catch (err) {
                console.error(err);
                projectToast('تعذر تصدير المجسم. جرّب تحميله بعد ظهوره في الاستوديو.');
            }
        }

        projectNameInput?.addEventListener('input', () => {
            if (projectHeaderTitle && projectHeaderTitle.value !== projectNameInput.value) projectHeaderTitle.value = projectNameInput.value;
            try { localStorage.setItem('toryakDraftName', projectNameInput.value); } catch (_) {}
        });
        projectHeaderTitle?.addEventListener('input', () => {
            if (projectNameInput && projectNameInput.value !== projectHeaderTitle.value) projectNameInput.value = projectHeaderTitle.value;
            try { localStorage.setItem('toryakDraftName', projectHeaderTitle.value); } catch (_) {}
        });
        projectDescriptionInput?.addEventListener('input', () => {
            try { localStorage.setItem('toryakDraftDescription', projectDescriptionInput.value); } catch (_) {}
        });
        restoreProjectDraft();

        document.getElementById('projectAnimationBtn')?.addEventListener('click', toggleProjectAnimation);
        document.getElementById('projectAnimationSpeed')?.addEventListener('input', e => {
            projectAnimationSpeed = parseFloat(e.target.value) || 1;
        });
        document.getElementById('downloadProjectBtn')?.addEventListener('click', downloadCurrentProject);

        function resetProjectForm() {
            studioModelLoadRequestId++;
            if (projectNameInput) projectNameInput.value = '';
            if (projectHeaderTitle) projectHeaderTitle.value = '';
            if (projectDescriptionInput) projectDescriptionInput.value = '';
            try { localStorage.removeItem('toryakDraftName'); localStorage.removeItem('toryakDraftDescription'); } catch (_) {}
            const fileInput = document.getElementById('fileInput');
            if (fileInput) fileInput.value = '';
            currentModelFile = null;
            currentModelFileName = '';
            currentModelDownloadUrl = '';
            projectAnimationPlaying = false;
            projectAnimationTime = 0;
            projectPathPlaying = false;
            projectPathFrames = [];
            projectPathElapsed = 0;
            updateProjectPathCount();
            const animationBtn = document.getElementById('projectAnimationBtn');
            if (animationBtn) animationBtn.innerText = '▶ تشغيل';
            const fileNameEl = document.getElementById('projectFileName');
            if (fileNameEl) fileNameEl.innerText = 'لم يتم اختيار ملف بعد';
            if (currentModel) { scene.remove(currentModel); currentModel = null; }
            currentStudioProjectId = null;
            originalPositions = [];
            explodeDirections = [];
            isExploded = false;
            animationProgress = 0;
            showStudioFallbackModel();
            document.getElementById('aiStatus').innerText = 'مشروع جديد جاهز — يتم تحميل مجسم حقيقي من مكتبة الموقع، ويمكنك استبداله بملفك.';
        }

        async function deleteCurrentProject() {
            if (!currentStudioProjectId) {
                projectToast('افتح مشروعاً منشوراً أولاً أو انشر المشروع ثم احذفه.');
                return;
            }
            const projects = getPublishedProjects();
            const project = projects.find(p => Number(p.id) === Number(currentStudioProjectId));
            if (!project) {
                projectToast('لم يتم العثور على المشروع.');
                return;
            }
            if (!(await window.__askConfirm(`هل تريد حذف المشروع «${project.name || 'بدون اسم'}» نهائياً من هذا المتصفح؟`))) return;
            try {
                const db = await openProjectDB();
                await new Promise((resolve, reject) => {
                    const tx = db.transaction('projects', 'readwrite');
                    tx.objectStore('projects').delete(Number(currentStudioProjectId));
                    tx.oncomplete = resolve;
                    tx.onerror = () => reject(tx.error || new Error('delete failed'));
                    tx.onabort = () => reject(tx.error || new Error('delete aborted'));
                });
                db.close();
            } catch (err) {
                console.warn('Could not delete project blob from IndexedDB', err);
            }
            const remaining = projects.filter(p => Number(p.id) !== Number(currentStudioProjectId));
            localStorage.setItem('toryakProjects', JSON.stringify(remaining));
            try { window.tgCloudDeleteModel && window.tgCloudDeleteModel(currentStudioProjectId); } catch (_) {}
            try { localStorage.removeItem('toryakReviews_published:' + currentStudioProjectId); } catch (_) {}
            const deletedId = currentStudioProjectId;
            currentStudioProjectId = null;
            resetProjectForm();
            renderPublishedProjects();
            updatePublishedProjectsCount();
            projectToast(`تم حذف المشروع «${project.name || 'المشروع'}»`);
            document.getElementById('aiStatus').innerText = 'تم حذف المشروع';
            // If the project detail viewer happens to be open, close it too.
            try {
                const overlay = document.getElementById('projectDetailOverlay');
                if (overlay?.classList.contains('active')) overlay.classList.remove('active');
            } catch (_) {}
        }

        publishProjectBtn?.addEventListener('click', publishProject);
        publishProjectTopBtn?.addEventListener('click', publishProject);
        newProjectBtn?.addEventListener('click', resetProjectForm);
        deleteProjectBtn?.addEventListener('click', deleteCurrentProject);
        updatePublishedProjectsCount();
        renderPublishedProjects();

        // Start with a real model from the site's own library (not a cube/sphere placeholder).
        showStudioFallbackModel();

        function toggleExplodeModel() {
            if (!currentModel) { projectToast('حمّل مجسماً أولاً ثم جرّب التفكيك.'); return; }
            if (!originalPositions.length) setupExplodeData();
            isExploded = !isExploded;
            let index = 0;
            currentModel.traverse((child) => {
                if (!child.isMesh) return;
                const base = originalPositions[index];
                const dir = explodeDirections[index];
                if (base && dir) {
                    if (isExploded) child.position.copy(base).addScaledVector(dir, 0.55 + (index % 4) * 0.12);
                    else child.position.copy(base);
                }
                index++;
            });
            currentModel.updateMatrixWorld(true);
            const status = document.getElementById('aiStatus');
            if (status) status.innerText = isExploded ? 'تم تفكيك أجزاء المجسم — اضغط مجددًا لإعادة تجميعه.' : 'تمت إعادة تجميع المجسم.';
            if (typeof renderStudioFrame === 'function') renderStudioFrame();
        }

        let selectedStudioMesh = null;

        function paintStudioMesh(child, color) {
            if (!child || !child.isMesh || !child.material) return;
            if (!child.userData.__toryakColorEditable) {
                child.material = Array.isArray(child.material)
                    ? child.material.map(mat => mat && mat.clone ? mat.clone() : mat)
                    : (child.material.clone ? child.material.clone() : child.material);
                child.userData.__toryakColorEditable = true;
            }
            const mats = Array.isArray(child.material) ? child.material : [child.material];
            mats.forEach(mat => { if (mat && mat.color && mat.color.copy) { mat.color.copy(color); mat.needsUpdate = true; } });
        }

        function changeStudioFloorColor(hexColor) {
            if (typeof oceanMaterial === 'undefined' || !oceanMaterial) return;
            oceanMaterial.color.set(hexColor);
            oceanMaterial.specular.set(hexColor);
            oceanMaterial.needsUpdate = true;
            window.__toryakFloorColor = hexColor;
            if (typeof renderStudioFrame === 'function') renderStudioFrame();
        }

        function changeModelColor(hexColor) {
            if (!currentModel) return;
            const color = new THREE.Color(hexColor);
            if (selectedStudioMesh && currentModel.getObjectById(selectedStudioMesh.id) === selectedStudioMesh) {
                paintStudioMesh(selectedStudioMesh, color);
                projectToast('تم تلوين الجزء المحدد. اضغط على مساحة فارغة لإلغاء تحديده.');
            } else currentModel.traverse((child) => {
                if (!child.isMesh || !child.material) return;
                paintStudioMesh(child, color);
            });
            if (typeof renderStudioFrame === 'function') renderStudioFrame();
        }

        function moveCurrentModel(axis, amount) {
            if (!currentModel) { projectToast('اختر أو ارفع مجسماً أولاً.'); return; }
            projectPathPlaying = false;
            projectAnimationPlaying = false;
            if (axis === 'x') currentModel.position.x += Number(amount) || 0;
            else if (axis === 'y') currentModel.position.y += Number(amount) || 0;
            else if (axis === 'z') currentModel.position.z += Number(amount) || 0;
            projectAnimationBaseY = currentModel.position.y;
            renderStudioFrame();
        }
        function centerStudioModel() {
            if (!currentModel) return;
            focusStudioCameraOnModel(currentModel);
            renderStudioFrame();
        }
        document.getElementById('centerStudioModelBtn')?.addEventListener('click', centerStudioModel);

        function scaleModel(factor) {
            if (currentModel) {
                currentScaleValue *= factor;
                currentScaleValue = Math.max(0.1, Math.min(currentScaleValue, 15.0));
                currentModel.scale.set(currentScaleValue, currentScaleValue, currentScaleValue);
            }
        }

        function updateSunIntensity(val) { sunLight.intensity = parseFloat(val); if (renderer) renderStudioFrame(); }
        function updateStudioLight(kind, val) {
            const value = parseFloat(val);
            if (kind === 'key') sunLight.intensity = value;
            else if (kind === 'fill') fillStudioLight.intensity = value;
            else if (kind === 'rim') rimStudioLight.intensity = value;
            if (renderer) renderStudioFrame();
        }
        function updateStudioLightColor(kind, value) {
            const color = new THREE.Color(value);
            if (kind === 'key') sunLight.color.copy(color);
            else if (kind === 'fill') fillStudioLight.color.copy(color);
            else if (kind === 'rim') rimStudioLight.color.copy(color);
            else if (kind === 'ambient') ambientLight.color.copy(color);
            if (renderer) renderStudioFrame();
        }
        function toggleAutoRotate() { isAutoRotating = !isAutoRotating; }

        const studioSearchInput = document.getElementById('searchInput');
        const studioSearchResults = document.getElementById('studioSearchResults');

        studioSearchInput.addEventListener('input', function() {
            const query = this.value.trim();
            const matches = renderStudioSearchResults(query);
            // إذا كتب المستخدم الاسم الكامل/الاختصار المعروف، يُعرض المجسم مباشرة.
            if (findExactStudioModel(query)) {
                hideStudioSearchResults();
                loadProductModel(query);
            }
        });

        studioSearchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const matches = findStudioModels(this.value);
                if (matches.length) {
                    hideStudioSearchResults();
                    loadProductModel(matches[0].query);
                }
            } else if (e.key === 'Escape') {
                hideStudioSearchResults();
            }
        });

        document.querySelectorAll('.studio-model-quick-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const item = STUDIO_MODEL_OPTIONS.find(model => model.key === btn.dataset.modelKey)
                    || findExactStudioModel(btn.dataset.modelQuery || '')
                    || findStudioModels(btn.dataset.modelQuery || '')[0];
                if (!item) {
                    const status = document.getElementById('aiStatus');
                    if (status) status.innerText = 'تعذر تحديد المجسم من مكتبة الموقع.';
                    return;
                }
                studioSearchInput.value = item.label;
                hideStudioSearchResults();
                loadProductModel(item.query);
            });
        });

        document.addEventListener('mousedown', function(e) {
            if (!e.target.closest('.studio-search-wrap')) hideStudioSearchResults();
        });

        let isDragging = false;
        let studioPointerMode = 'rotate';
        let dragStudioTarget = null;
        let prevMousePos = { x: 0, y: 0 };
        const studioRaycaster = new THREE.Raycaster();
        const studioPointerNdc = new THREE.Vector2();
        function pickStudioMesh(e) {
            if (!currentModel) return null;
            const rect = studioCanvas.getBoundingClientRect();
            studioPointerNdc.x = ((e.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1;
            studioPointerNdc.y = -((e.clientY - rect.top) / Math.max(1, rect.height)) * 2 + 1;
            studioRaycaster.setFromCamera(studioPointerNdc, camera);
            const hits = studioRaycaster.intersectObject(currentModel, true);
            return hits.find(hit => hit.object && hit.object.isMesh)?.object || null;
        }
        const studioCanvas = renderer.domElement;
        studioCanvas.style.touchAction = 'none';
        studioCanvas.addEventListener('contextmenu', e => { if (studioView.classList.contains('active')) e.preventDefault(); });
        studioCanvas.addEventListener('pointerdown', (e) => {
            if (!studioView.classList.contains('active') || !currentModel) return;
            if (![0,1,2].includes(e.button)) return;
            const hitMesh = pickStudioMesh(e);
            if (hitMesh) {
                selectedStudioMesh = hitMesh;
                const status = document.getElementById('aiStatus');
                if (status) status.innerText = `تم تحديد الجزء: ${hitMesh.name || 'جزء من المجسم'} — اختر لونًا لتلوينه، أو استخدم Alt + السحب لتحريكه.`;
            } else if (!e.shiftKey && !e.altKey && e.button === 0) {
                selectedStudioMesh = null;
                const status = document.getElementById('aiStatus');
                if (status) status.innerText = 'أُلغي تحديد الجزء؛ أدوات اللون تعمل على المجسم كاملًا.';
            }
            isDragging = true;
            studioPointerMode = e.altKey && selectedStudioMesh ? 'move-part' : ((e.button === 1 || e.button === 2 || e.shiftKey) ? 'move' : 'rotate');
            dragStudioTarget = studioPointerMode === 'move-part' ? selectedStudioMesh : currentModel;
            prevMousePos = { x: e.clientX, y: e.clientY };
            // Manual mouse control takes over from the animation while dragging.
            isAutoRotating = false;
            projectAnimationPlaying = false;
            projectPathPlaying = false;
            projectEmbeddedActions.forEach(action => { try { action.stop(); } catch (_) {} });
            try { studioCanvas.setPointerCapture(e.pointerId); } catch (_) {}
            studioCanvas.style.cursor = 'grabbing';
            e.preventDefault();
        });
        window.addEventListener('pointermove', (e) => {
            if (!isDragging || !currentModel) return;
            const dx = e.clientX - prevMousePos.x;
            const dy = e.clientY - prevMousePos.y;
            if (studioPointerMode === 'rotate') {
                currentModel.rotation.y += dx * 0.008;
                currentModel.rotation.x += dy * 0.008;
                currentModel.rotation.x = Math.max(-Math.PI, Math.min(Math.PI, currentModel.rotation.x));
            } else {
                const unitsPerPixel = Math.max(0.001, camera.position.distanceTo(studioCameraTarget) * 0.0018);
                const target = dragStudioTarget || currentModel;
                target.position.x += dx * unitsPerPixel;
                target.position.y -= dy * unitsPerPixel;
                if (target === currentModel) projectAnimationBaseY = currentModel.position.y;
            }
            prevMousePos = { x: e.clientX, y: e.clientY };
            renderStudioFrame();
        });
        const endStudioDrag = (e) => {
            isDragging = false;
            dragStudioTarget = null;
            studioCanvas.style.cursor = 'grab';
            try { if (e?.pointerId !== undefined && studioCanvas.hasPointerCapture(e.pointerId)) studioCanvas.releasePointerCapture(e.pointerId); } catch (_) {}
        };
        window.addEventListener('pointerup', endStudioDrag);
        window.addEventListener('pointercancel', endStudioDrag);
        studioCanvas.addEventListener('wheel', (e) => {
            if (!studioView.classList.contains('active')) return;
            e.preventDefault();
            const offset = camera.position.clone().sub(studioCameraTarget);
            const length = THREE.MathUtils.clamp(offset.length() * Math.exp(e.deltaY * 0.001), 0.35, 60);
            offset.normalize().multiplyScalar(length);
            camera.position.copy(studioCameraTarget).add(offset);
            camera.lookAt(studioCameraTarget);
            studioZoomDistance = length;
            camera.updateProjectionMatrix();
        }, { passive: false });
        canvasContainer.addEventListener('dragover', e => { e.preventDefault(); if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy'; });
        canvasContainer.addEventListener('drop', e => {
            e.preventDefault();
            const transfer = e.dataTransfer;
            const files = Array.from(transfer?.files || []);
            if (files.length) { handleCustomModelFiles(files); return; }
            const plain = transfer?.getData('text/plain') || '';
            const key = transfer?.getData('application/x-toryak-model-key') || (plain.startsWith('toryak-model:') ? plain.slice(13) : '');
            if (key && STUDIO_MODEL_OPTIONS.some(item => item.key === key)) { loadProductModel(STUDIO_MODEL_OPTIONS.find(item => item.key === key).query); return; }
            const url = (transfer?.getData('text/uri-list') || plain).split(/\r?\n/).find(line => line && !line.startsWith('#')) || '';
            if (/^https?:\/\//i.test(url)) loadRemoteModelUrl(url);
        });

        function animate() {
            requestAnimationFrame(animate);
            // Scientist 3D Studio replaces this legacy editor. Do not keep its hidden
            // renderer or animation loop competing with the visible editor and viewer.
            if (window.__TORYAK_USE_SCIENTIST_STUDIO__) return;
            updateToryakOcean(0.016);

            if (projectPathPlaying) {
                updateProjectPathAnimation(16);
            } else if (currentModel) {
                if (projectAnimationPlaying) {
                    projectAnimationTime += 16 * projectAnimationSpeed;
                    const t = projectAnimationTime;
                    if (projectAnimationMode === 'rotate') {
                        currentModel.rotation.y += 0.0035 * projectAnimationSpeed;
                    } else if (projectAnimationMode === 'float') {
                        currentModel.position.y = projectAnimationBaseY + Math.sin(t * 0.0018) * 0.10;
                    } else {
                        currentModel.rotation.y += 0.0022 * projectAnimationSpeed;
                        currentModel.rotation.x = Math.sin(t * 0.0012) * 0.08;
                    }
                } else if (isAutoRotating) {
                    currentModel.rotation.y += 0.003;
                }
                if (projectEmbeddedMixer && projectEmbeddedActions.some(action => action.isRunning())) {
                    projectEmbeddedMixer.update(Math.min(0.05, 0.016 * projectAnimationSpeed));
                }
            }

            if (currentModel && originalPositions.length > 0) {
                const targetProgress = isExploded ? 1 : 0;
                animationProgress += (targetProgress - animationProgress) * 0.08;

                let meshIndex = 0;
                currentModel.traverse((child) => {
                    if (child.isMesh && originalPositions[meshIndex]) {
                        const origPos = originalPositions[meshIndex];
                        const dir = explodeDirections[meshIndex];
                        const explodeDistance = 1.2;

                        child.position.x = origPos.x + dir.x * explodeDistance * animationProgress;
                        child.position.y = origPos.y + dir.y * explodeDistance * animationProgress;
                        child.position.z = origPos.z + dir.z * explodeDistance * animationProgress;
                        meshIndex++;
                    }
                });
            }

            renderer.render(scene, camera);
        }
        animate();

        window.addEventListener('resize', () => {
            const width = Math.max(1, canvasContainer.clientWidth || window.innerWidth);
            const height = Math.max(1, canvasContainer.clientHeight || window.innerHeight);
            camera.aspect = width / height;
            camera.updateProjectionMatrix();
            renderer.setSize(width, height);
            renderStudioFrame();
        });
    
