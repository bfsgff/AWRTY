(function(){
  // Canonical keys are the original Arabic strings. The translator never scans script/style text,
  // so the large embedded GLB base64 strings are not touched and language switching stays fast.
  const A = {
    'الصفحة الرئيسية':'Home',
    'تسجيل الدخول':'Sign in',
    'الترجمة':'Language',
    'إنشاء مشروع (3D)':'Create 3D Project',
    'لعبة إكس - أو':'Tic-Tac-Toe',
    'تفادي السيارات':'Car Dodge',
    'الألغاز السريعة':'Quick Puzzles',
    'اكتب اسم النموذج واضغط Enter للانتقال إلى صفحة النماذج ثلاثية الأبعاد':'Type a model name and press Enter to open the 3D models page',
    'ابحث عن نموذج ثلاثي الأبعاد...':'Search for a 3D model...',
    'نماذج ثلاثية الأبعاد':'3D Models',
    'رجوع':'Back',
    'مسدس خدمة':'Service Pistol',
    'نموذج ثلاثي الأبعاد مرفق بالموقع':'3D model included with the site',
    'استكشاف':'Explore',
    'روبوت':'Robot', 'ساعة':'Watch', 'هاتف':'Phone', 'خوذة':'Helmet', 'مكعب':'Cube',
    'نموذج ثلاثي الأبعاد':'3D Model',
    'شكل هندسي ثلاثي الأبعاد':'3D geometric shape',
    'عرض النموذج 3D':'View 3D Model',
    'لا يوجد نموذج مطابق للبحث.':'No matching model found.',
    'تسجيل الدخول عبر Google':'Sign in with Google',
    'سجّل الدخول عبر Google أو Microsoft للنشر.':'Sign in with Google or Microsoft to publish.',
    'رمز صاحب الموقع غير صحيح.':'Invalid site owner code.',
    'تسجيل الدخول عبر Microsoft':'Sign in with Microsoft',
    'إضاءة الاستوديو:':'Studio Lights:',
    'الرئيسية':'Key',
    'الجانبية':'Fill',
    'الخلفية':'Rim',
    'فتح في الاستوديو':'Open in Studio',
    'نموذج ثلاثي الأبعاد منشور':'Published 3D model',
    'مشروع 3D':'3D Project',
    'PUBLISHED 3D MODEL':'PUBLISHED 3D MODEL',
    'تغيير لغة الموقع':'Change site language',
    'ولاعة كلاسيكية':'Vintage Lighter',
    'نموذج ثلاثي الأبعاد جديد':'New 3D model',
    'ولاعة':'Lighter',
    'لوحة دوائر إلكترونية':'Electronic Circuit Board',
    'جالون معدني':'Metal Jerrycan',
    'جالون':'Jerrycan',
    'عبوة معدنية':'Metal Canister',
    'جالون جالون معدني عبوة معدنية metal jerrycan jerrycan canister container':'Metal Jerrycan canister',
    'لوحة دوائر':'Circuit Board',
    'دائرة إلكترونية':'Electronic Circuit Board',
    'العربية (Arabic)':'Arabic',
    'الإنجليزية (English)':'English',
    'لعبة إكس - أو ( ضد الذكاء الاصطناعي )':'Tic-Tac-Toe (vs AI)',
    'دورك (X) - العب الآن':'Your turn (X) — play now',
    'إعادة اللعب':'Play again',
    'جاري تحميل اللغز...':'Loading puzzle...',
    'السؤال التالي':'Next question',
    'لعبة تفادي السيارات':'Car Dodge Game',
    'إعادة اللعبة':'Restart game',
    'النقاط: 0 • تحكم بالأسهم أو الزرين':'Score: 0 • Use arrow keys or the buttons',
    'إعادة ضبط':'Reset',
    'تحميل المجسم':'Download Model',
    'إغلاق':'Close',
    'جارٍ تجهيز المجسم...':'Preparing the model...',
    'اسحب بالماوس يمين/يسار وفوق/تحت لتدوير المجسم • عجلة الماوس للتكبير والتصغير':'Drag with the mouse to rotate • Use the wheel to zoom',
    'الخامة الأصلية':'Original Material',
    'المعدن والخشونة':'Metal & Roughness',
    'ألوان':'Colors',
    '▶ تشغيل':'▶ Play',
    '⏸ إيقاف':'⏸ Pause',
    'لون المجسم':'Model Color',
    'استوديو التحكم بالمجسمات':'3D Model Studio',
    'تحميل المشروع':'Download Project',
    'إغلاق الاستوديو':'Close Studio',
    'نماذج سريعة للبحث:':'Quick model search:',
    'أجهزة:':'Devices:',
    'ساعة، هاتف، سماعة':'Watch, phone, headset',
    'أخرى:':'Other:',
    'روبوت، خوذة':'Robot, helmet',
    'أشكال هندسية:':'Geometric shapes:',
    'مكعب، هرم، كرة':'Cube, pyramid, sphere',
    'إنشاء مشروع 3D':'Create 3D Project',
    'اسحب ملف 3D هنا أو اضغط للاختيار':'Drag a 3D file here or click to choose',
    'المدعوم: GLB / GLTF / OBJ':'Supported: GLB / GLTF / OBJ',
    'لم يتم اختيار ملف بعد':'No file selected yet',
    'مشروع جديد':'New Project',
    'نشر المشروع ':'Publish Project ',
    'أنيميشن وتحريك المجسم':'Model Animation',
    '↻ دوران':'↻ Rotate',
    '↕ طفو':'↕ Float',
    '◌ عرض':'◌ Inspect',
    'المشاريع المنشورة محلياً: 0':'Locally published projects: 0',
    'المشاريع المنشورة محلياً:':'Locally published projects:',
    'خاصية التفكيك (Explode):':'Explode:',
    'تفكيك / تجميع المجسم':'Explode / Assemble Model',
    'تلوين المجسم:':'Color Model:',
    'الحجم:':'Size:',
    'تكبير (+)':'Zoom In (+)',
    'تصغير (-)':'Zoom Out (-)',
    'شدة إضاءة الاستوديو:':'Studio Lighting:',
    'الحركة:':'Motion:',
    'تشغيل / إيقاف الدوران':'Toggle Rotation',
    'الاستوديو جاهز':'Studio ready',
    'عنوان المشروع...':'Project title...',
    'اكتب عنوان المشروع بحرية':'Enter project title',
    'وصف المشروع (اختياري)':'Project description (optional)',
    'مسدس pistol مسدس خدمة':'Service Pistol pistol',
    'بحث عن نموذج ثلاثي الأبعاد...':'Search for a 3D model...',
    'حدث خطأ أثناء تجهيز النموذج.':'An error occurred while preparing the model.',
    'تعذر قراءة ملف المجسم. جرّب إغلاق النافذة وفتحها من جديد.':'Could not read the model file. Close and reopen the window.',
    'تعذر تحميل المجسم':'Could not download the model',
    'بدأ تحميل المجسم':'Model download started',
    'حدث خطأ أثناء تجهيز النموذج.':'An error occurred while preparing the model.'
  };

  const X = {};
  const Z = {};
  const U = {};
  const F = {};

  // Chinese
  const zh = {
    'الصفحة الرئيسية':'首页','تسجيل الدخول':'登录','الترجمة':'语言','إنشاء مشروع (3D)':'创建 3D 项目',
    'لعبة إكس - أو':'井字棋','تفادي السيارات':'躲避汽车','الألغاز السريعة':'快速谜题',
    'اكتب اسم النموذج واضغط Enter للانتقال إلى صفحة النماذج ثلاثية الأبعاد':'输入模型名称并按 Enter 打开 3D 模型页面',
    'ابحث عن نموذج ثلاثي الأبعاد...':'搜索 3D 模型...','نماذج ثلاثية الأبعاد':'3D 模型','رجوع':'返回',
    'مسدس خدمة':'服务手枪','نموذج ثلاثي الأبعاد مرفق بالموقع':'网站内置 3D 模型','استكشاف':'探索',
    'روبوت':'机器人','ساعة':'手表','هاتف':'手机','خوذة':'头盔','مكعب':'立方体','نموذج ثلاثي الأبعاد':'3D 模型',
    'شكل هندسي ثلاثي الأبعاد':'3D 几何图形','عرض النموذج 3D':'查看 3D 模型','لا يوجد نموذج مطابق للبحث.':'没有找到匹配的模型。',
    'تسجيل الدخول عبر Google':'使用 Google 登录','دخول صاحب الموقع':'网站管理员登录','سجّل الدخول أولاً للنشر، أو ادخل بوضع صاحب الموقع。':'登录后才能发布，或进入网站管理员模式。','رمز صاحب الموقع غير صحيح.':'网站管理员代码无效。','تم تفعيل صلاحية صاحب الموقع. يمكنك النشر بدون تسجيل دخول.':'网站管理员模式已启用。无需登录即可发布。','تسجيل الدخول عبر Microsoft':'使用 Microsoft 登录','تغيير لغة الموقع':'更改网站语言',
    'ولاعة كلاسيكية':'复古打火机','نموذج ثلاثي الأبعاد جديد':'新的 3D 模型','ولاعة':'打火机','لوحة دوائر إلكترونية':'电子电路板',
    'جالون معدني':'金属油桶','جالون':'油桶','عبوة معدنية':'金属容器','لوحة دوائر':'电路板','دائرة إلكترونية':'电子电路',
    'لعبة إكس - أو ( ضد الذكاء الاصطناعي )':'井字棋（对战 AI）','دورك (X) - العب الآن':'轮到你（X）— 开始游戏','إعادة اللعب':'再玩一次',
    'جاري تحميل اللغز...':'正在加载谜题...','السؤال التالي':'下一题','لعبة تفادي السيارات':'躲避汽车游戏','إعادة اللعبة':'重新开始',
    'النقاط: 0 • تحكم بالأسهم أو الزرين':'得分：0 • 使用方向键或按钮','إعادة ضبط':'重置','تحميل المجسم':'下载模型','إغلاق':'关闭',
    'جارٍ تجهيز المجسم...':'正在准备模型...','اسحب بالماوس يمين/يسار وفوق/تحت لتدوير المجسم • عجلة الماوس للتكبير والتصغير':'拖动鼠标旋转模型 • 使用滚轮缩放',
    'الخامة الأصلية':'原始材质','المعدن والخشونة':'金属与粗糙度','ألوان':'颜色','▶ تشغيل':'▶ 播放','⏸ إيقاف':'⏸ 暂停','لون المجسم':'模型颜色',
    'استوديو التحكم بالمجسمات':'3D 模型工作室','تحميل المشروع':'下载项目','إغلاق الاستوديو':'关闭工作室','نماذج سريعة للبحث:':'快速模型搜索：',
    'أجهزة:':'设备：','ساعة، هاتف، سماعة':'手表、手机、耳机','أخرى:':'其他：','روبوت، خوذة':'机器人、头盔','أشكال هندسية:':'几何图形：',
    'مكعب، هرم، كرة':'立方体、棱锥、球体','إنشاء مشروع 3D':'创建 3D 项目','اسحب ملف 3D هنا أو اضغط للاختيار':'将 3D 文件拖到这里或点击选择',
    'المدعوم: GLB / GLTF / OBJ':'支持：GLB / GLTF / OBJ','لم يتم اختيار ملف بعد':'尚未选择文件','مشروع جديد':'新项目','نشر المشروع ':'发布项目 ',
    'أنيميشن وتحريك المجسم':'模型动画','↻ دوران':'↻ 旋转','↕ طفو':'↕ 浮动','◌ عرض':'◌ 查看','المشاريع المنشورة محلياً: 0':'本地发布项目：0',
    'المشاريع المنشورة محلياً:':'本地发布项目：','خاصية التفكيك (Explode):':'爆炸分解：','تفكيك / تجميع المجسم':'分解 / 组合模型',
    'تلوين المجسم:':'模型颜色：','الحجم:':'大小：','تكبير (+)':'放大 (+)','تصغير (-)':'缩小 (-)','شدة إضاءة الاستوديو:':'工作室灯光强度：',
    'الحركة:':'动作：','تشغيل / إيقاف الدوران':'切换旋转','الاستوديو جاهز':'工作室已准备好','عنوان المشروع...':'项目标题...','اكتب عنوان المشروع بحرية':'输入项目标题',
    'وصف المشروع (اختياري)':'项目描述（可选）','حدث خطأ أثناء تجهيز النموذج.':'准备模型时发生错误。','تعذر قراءة ملف المجسم. جرّب إغلاق النافذة وفتحها من جديد.':'无法读取模型文件。请关闭并重新打开窗口。',
    'تعذر تحميل المجسم':'无法下载模型','بدأ تحميل المجسم':'已开始下载模型','حدث خطأ أثناء تجهيز النموذج.':'准备模型时发生错误。'
  }
  ;

  // Urdu (Pakistan)
  const ur = {
    'الصفحة الرئيسية':'ہوم','تسجيل الدخول':'سائن اِن','الترجمة':'زبان','إنشاء مشروع (3D)':'3D پروجیکٹ بنائیں','لعبة إكس - أو':'ٹک ٹیک ٹو',
    'تفادي السيارات':'گاڑیوں سے بچیں','الألغاز السريعة':'فوری پہیلیاں','اكتب اسم النموذج واضغط Enter للانتقال إلى صفحة النماذج ثلاثية الأبعاد':'ماڈل کا نام لکھیں اور 3D ماڈلز کا صفحہ کھولنے کے لیے Enter دبائیں',
    'ابحث عن نموذج ثلاثي الأبعاد...':'3D ماڈل تلاش کریں...','نماذج ثلاثية الأبعاد':'3D ماڈلز','رجوع':'واپس','مسدس خدمة':'سروس پستول','نموذج ثلاثي الأبعاد مرفق بالموقع':'ویب سائٹ میں شامل 3D ماڈل','استكشاف':'دریافت',
    'روبوت':'روبوٹ','ساعة':'گھڑی','هاتف':'فون','خوذة':'ہیلمٹ','مكعب':'مکعب','نموذج ثلاثي الأبعاد':'3D ماڈل','شكل هندسي ثلاثي الأبعاد':'3D ہندسی شکل','عرض النموذج 3D':'3D ماڈل دیکھیں',
    'لا يوجد نموذج مطابق للبحث.':'کوئی مماثل ماڈل نہیں ملا۔','لا يوجد نموذج مطابق للبحث.':'کوئی مماثل ماڈل نہیں ملا۔','تسجيل الدخول عبر Google':'Google کے ذریعے سائن اِن','تسجيل الدخول عبر Microsoft':'Microsoft کے ذریعے سائن اِن','تغيير لغة الموقع':'ویب سائٹ کی زبان تبدیل کریں',
    'ولاعة كلاسيكية':'قدیم طرز کا لائٹر','نموذج ثلاثي الأبعاد جديد':'نیا 3D ماڈل','ولاعة':'لائٹر','لوحة دوائر إلكترونية':'الیکٹرانک سرکٹ بورڈ','جالون معدني':'دھاتی جیری کین','جالون':'جیری کین','عبوة معدنية':'دھاتی کنٹینر','لوحة دوائر':'سرکٹ بورڈ','دائرة إلكترونية':'الیکٹرانک سرکٹ',
    'لعبة إكس - أو ( ضد الذكاء الاصطناعي )':'ٹک ٹیک ٹو (AI کے خلاف)','دورك (X) - العب الآن':'آپ کی باری (X) — ابھی کھیلیں','إعادة اللعب':'دوبارہ کھیلیں','جاري تحميل اللغز...':'پہیلی لوڈ ہو رہی ہے...','السؤال التالي':'اگلا سوال','لعبة تفادي السيارات':'گاڑیوں سے بچنے کی گیم','إعادة اللعبة':'گیم دوبارہ شروع کریں',
    'النقاط: 0 • تحكم بالأسهم أو الزرين':'اسکور: 0 • تیر والے بٹن یا دونوں بٹن استعمال کریں','إعادة ضبط':'ری سیٹ','تحميل المجسم':'ماڈل ڈاؤن لوڈ کریں','إغلاق':'بند کریں','جارٍ تجهيز المجسم...':'ماڈل تیار کیا جا رہا ہے...','اسحب بالماوس يمين/يسار وفوق/تحت لتدوير المجسم • عجلة الماوس للتكبير والتصغير':'ماڈل گھمانے کے لیے ماؤس سے دائیں/بائیں اور اوپر/نیچے گھسیٹیں • زوم کے لیے وہیل استعمال کریں',
    'الخامة الأصلية':'اصل میٹیریل','المعدن والخشونة':'دھات اور کھردرا پن','ألوان':'رنگ','▶ تشغيل':'▶ چلائیں','⏸ إيقاف':'⏸ روکیں','لون المجسم':'ماڈل کا رنگ','استوديو التحكم بالمجسمات':'3D ماڈل اسٹوڈیو','تحميل المشروع':'پروجیکٹ ڈاؤن لوڈ کریں','إغلاق الاستوديو':'اسٹوڈیو بند کریں',
    'نماذج سريعة للبحث:':'فوری ماڈل تلاش:','أجهزة:':'آلات:','ساعة، هاتف، سماعة':'گھڑی، فون، ہیڈسیٹ','أخرى:':'دیگر:','روبوت، خوذة':'روبوٹ، ہیلمٹ','أشكال هندسية:':'ہندسی اشکال:','مكعب، هرم، كرة':'مکعب، اہرام، کرہ',
    'إنشاء مشروع 3D':'3D پروجیکٹ بنائیں','اسحب ملف 3D هنا أو اضغط للاختيار':'3D فائل یہاں گھسیٹیں یا منتخب کرنے کے لیے کلک کریں','المدعوم: GLB / GLTF / OBJ':'سپورٹ: GLB / GLTF / OBJ','لم يتم اختيار ملف بعد':'ابھی کوئی فائل منتخب نہیں ہوئی','مشروع جديد':'نیا پروجیکٹ','نشر المشروع ':'پروجیکٹ شائع کریں ','أنيميشن وتحريك المجسم':'ماڈل اینیمیشن','↻ دوران':'↻ گھمائیں','↻ دوران':'↻ گھمائیں','↕ طفو':'↕ تیرنا','◌ عرض':'◌ معائنہ','المشاريع المنشورة محلياً: 0':'مقامی طور پر شائع شدہ پروجیکٹس: 0','المشاريع المنشورة محلياً:':'مقامی طور پر شائع شدہ پروجیکٹس:','خاصية التفكيك (Explode):':'ماڈل الگ کرنا:','تفكيك / تجميع المجسم':'ماڈل الگ / جوڑیں',
    'تلوين المجسم:':'ماڈل کا رنگ:','الحجم:':'سائز:','تكبير (+)':'بڑا کریں (+)','تصغير (-)':'چھوٹا کریں (-)','شدة إضاءة الاستوديو:':'اسٹوڈیو لائٹنگ:','الحركة:':'حرکت:','تشغيل / إيقاف الدوران':'گردش آن / آف','الاستوديو جاهز':'اسٹوڈیو تیار ہے','عنوان المشروع...':'پروجیکٹ کا عنوان...','اكتب عنوان المشروع بحرية':'پروجیکٹ کا عنوان لکھیں','وصف المشروع (اختياري)':'پروجیکٹ کی تفصیل (اختیاری)',
    'حدث خطأ أثناء تجهيز النموذج.':'ماڈل تیار کرتے وقت خرابی ہوئی۔','تعذر قراءة ملف المجسم. جرّب إغلاق النافذة وفتحها من جديد.':'ماڈل فائل نہیں پڑھی جا سکی۔ ونڈو بند کرکے دوبارہ کھولیں۔','تعذر تحميل المجسم':'ماڈل ڈاؤن لوڈ نہیں ہو سکا','بدأ تحميل المجسم':'ماڈل ڈاؤن لوڈ شروع ہوگیا','حدث خطأ أثناء تجهيز النموذج.':'ماڈل تیار کرتے وقت خرابی ہوئی۔'
  };

  // French
  const fr = {
    'الصفحة الرئيسية':'Accueil','تسجيل الدخول':'Se connecter','الترجمة':'Langue','إنشاء مشروع (3D)':'Créer un projet 3D','لعبة إكس - أو':'Morpion','تفادي السيارات':'Éviter les voitures','الألغاز السريعة':'Énigmes rapides',
    'اكتب اسم النموذج واضغط Enter للانتقال إلى صفحة النماذج ثلاثية الأبعاد':'Saisissez un nom de modèle puis appuyez sur Entrée pour ouvrir les modèles 3D','ابحث عن نموذج ثلاثي الأبعاد...':'Rechercher un modèle 3D...','نماذج ثلاثية الأبعاد':'Modèles 3D','رجوع':'Retour',
    'مسدس خدمة':'Pistolet de service','نموذج ثلاثي الأبعاد مرفق بالموقع':'Modèle 3D inclus dans le site','استكشاف':'Explorer','روبوت':'Robot','ساعة':'Montre','هاتف':'Téléphone','خوذة':'Casque','مكعب':'Cube','نموذج ثلاثي الأبعاد':'Modèle 3D','شكل هندسي ثلاثي الأبعاد':'Forme géométrique 3D','عرض النموذج 3D':'Voir le modèle 3D','لا يوجد نموذج مطابق للبحث.':'Aucun modèle correspondant.',
    'تسجيل الدخول عبر Google':'Se connecter avec Google','دخول صاحب الموقع':'Connexion propriétaire du site','سجّل الدخول أولاً للنشر، أو ادخل بوضع صاحب الموقع.':'Connectez-vous pour publier, ou passez en mode propriétaire.','رمز صاحب الموقع غير صحيح.':'Code propriétaire incorrect.','تم تفعيل صلاحية صاحب الموقع. يمكنك النشر بدون تسجيل دخول.':'Mode propriétaire activé. Vous pouvez publier sans vous connecter.','تسجيل الدخول عبر Microsoft':'Se connecter avec Microsoft','تغيير لغة الموقع':'Changer la langue du site','ولاعة كلاسيكية':'Briquet vintage','نموذج ثلاثي الأبعاد جديد':'Nouveau modèle 3D','ولاعة':'Briquet','لوحة دوائر إلكترونية':'Carte électronique','جالون معدني':'Bidon métallique','جالون':'Bidon','عبوة معدنية':'Conteneur métallique','لوحة دوائر':'Circuit imprimé','دائرة إلكترونية':'Circuit électronique',
    'لعبة إكس - أو ( ضد الذكاء الاصطناعي )':'Morpion (contre l’IA)','دورك (X) - العب الآن':'À vous (X) — jouez maintenant','إعادة اللعب':'Rejouer','جاري تحميل اللغز...':'Chargement de l’énigme...','السؤال التالي':'Question suivante','لعبة تفادي السيارات':'Jeu d’évitement de voitures','إعادة اللعبة':'Redémarrer le jeu','النقاط: 0 • تحكم بالأسهم أو الزرين':'Score : 0 • Utilisez les flèches ou les deux boutons','إعادة ضبط':'Réinitialiser',
    'تحميل المجسم':'Télécharger le modèle','إغلاق':'Fermer','جارٍ تجهيز المجسم...':'Préparation du modèle...','اسحب بالماوس يمين/يسار وفوق/تحت لتدوير المجسم • عجلة الماوس للتكبير والتصغير':'Faites glisser la souris pour faire pivoter • Utilisez la molette pour zoomer','الخامة الأصلية':'Matériau d’origine','المعدن والخشونة':'Métal et rugosité','ألوان':'Couleurs','▶ تشغيل':'▶ Lire','⏸ إيقاف':'⏸ Pause','لون المجسم':'Couleur du modèle',
    'استوديو التحكم بالمجسمات':'Studio de modèles 3D','تحميل المشروع':'Télécharger le projet','إغلاق الاستوديو':'Fermer le studio','نماذج سريعة للبحث:':'Recherche rapide de modèles :','أجهزة:':'Appareils :','ساعة، هاتف، سماعة':'Montre, téléphone, casque audio','أخرى:':'Autres :','روبوت، خوذة':'Robot, casque','أشكال هندسية:':'Formes géométriques :','مكعب، هرم، كرة':'Cube, pyramide, sphère',
    'إنشاء مشروع 3D':'Créer un projet 3D','اسحب ملف 3D هنا أو اضغط للاختيار':'Faites glisser un fichier 3D ici ou cliquez pour choisir','المدعوم: GLB / GLTF / OBJ':'Pris en charge : GLB / GLTF / OBJ','لم يتم اختيار ملف بعد':'Aucun fichier sélectionné','مشروع جديد':'Nouveau projet','نشر المشروع ':'Publier le projet ','أنيميشن وتحريك المجسم':'Animation du modèle','↻ دوران':'↻ Rotation','↕ طفو':'↕ Flottement','◌ عرض':'◌ Inspection','المشاريع المنشورة محلياً: 0':'Projets publiés localement : 0','المشاريع المنشورة محلياً:':'Projets publiés localement :','خاصية التفكيك (Explode):':'Explosion :','تفكيك / تجميع المجسم':'Dissocier / assembler le modèle',
    'تلوين المجسم:':'Couleur du modèle :','الحجم:':'Taille :','تكبير (+)':'Agrandir (+)','تصغير (-)':'Réduire (-)','شدة إضاءة الاستوديو:':'Intensité lumineuse du studio :','الحركة:':'Mouvement :','تشغيل / إيقاف الدوران':'Activer / désactiver la rotation','الاستوديو جاهز':'Studio prêt','عنوان المشروع...':'Titre du projet...','اكتب عنوان المشروع بحرية':'Saisissez librement le titre du projet','وصف المشروع (اختياري)':'Description du projet (facultatif)',
    'حدث خطأ أثناء تجهيز النموذج.':'Une erreur s’est produite pendant la préparation du modèle.','تعذر قراءة ملف المجسم. جرّب إغلاق النافذة وفتحها من جديد.':'Impossible de lire le fichier du modèle. Fermez puis rouvrez la fenêtre.','تعذر تحميل المجسم':'Impossible de télécharger le modèle','بدأ تحميل المجسم':'Téléchargement du modèle démarré','حدث خطأ أثناء تجهيز النموذج.':'Une erreur s’est produite pendant la préparation du modèle.'
  };

  Object.assign(A,{"استوديو جيم":"Game Studio","بحث":"Search","الألعاب":"Games","اللعبة":"Game","نشر اللعبة":"Publish game","تنزيل اللعبة":"Download game","تشغيل اللعبة":"Play game","تطوير اللعبة":"Develop game","مواصفات اللعبة":"Game specs","التعليقات":"Comments","نشر التعليق":"Post comment","اكتب تعليقك...":"Write your comment...","اسمك (اختياري)":"Your name (optional)","اسم اللعبة":"Game name","اكتب اسم اللعبة":"Type the game name","قيّم اللعبة":"Rate the game","خيارات الألعاب":"Game options","نتائج البحث":"Search results","تحميل":"Download","تنزيل ملف اللعبة":"Download game file","فتح اللعبة في نافذة جديدة":"Open game in a new window","الانتقال إلى الموقع":"Go to site","حذف المشروع":"Delete project","نشر المشروع":"Publish project","عنوان المشروع":"Project title","تقييم المشروع":"Project rating","مشروع":"Project","إزالة":"Remove","أضف فيديو":"Add video","فيديو":"Video","تغيير الصورة":"Change image","معاينة البطاقة":"Card preview","سيظهر وصف اللعبة هنا.":"The game description will appear here.","جاري تحميل المعاينة…":"Loading preview…","جاري تجهيز المعاينة...":"Preparing preview...","لا يوجد تقييم بعد":"No ratings yet","اضغط لعرض كل التعليقات":"Click to view all comments","📷 إرفاق صورة للعبة":"📷 Attach a game image","لم نعثر على لعبة بهذا الاسم. يمكنك نشر لعبة جديدة من استوديو جيم.":"No game found with this name. You can publish a new game from Game Studio.","ملف اللعبة أو التطبيق":"Game or app file","رابط اللعبة (اختياري)":"Game link (optional)","صورة اللعبة (غلاف)":"Game image (cover)","أضف صورة للعبة":"Add a game image","ابحث عن أي نموذج أو مشروع...":"Search any model or project...","ابحث عن نموذج ثلاثي الأبعاد":"Search for a 3D model","البحث في الموقع":"Search the site","مرحبًا بك!":"Welcome!","هل أنت مستخدم جديد؟":"Are you a new user?","نعم، أنا جديد":"Yes, I'm new","لا، أريد المتابعة":"No, I want to continue","نعم، أريد النشر":"Yes, I want to publish","لا، سأستكشف أولًا":"No, I'll explore first","انشر ما تصنعه":"Publish what you make","الإضاءة والألوان":"Lighting & colors","✕ إغلاق":"✕ Close","⛶ ملء الشاشة":"⛶ Fullscreen","↺ إعادة ضبط":"↺ Reset","الحساب":"Account","اسم الحساب":"Account name","اختيار صورة":"Choose photo","حفظ":"Save","مشروع 3D":"3D project","تسجيل خروج":"Log out","أعمالي في استوديو جيم":"My works in Game Studio","مشاريعي ثلاثية الأبعاد":"My 3D projects","لا يوجد حاليا":"Nothing yet","حذف":"Delete","تطوير / إضافة":"Develop / Add","حسابي":"My account"});Object.assign(fr,{"استوديو جيم":"Studio de jeux","بحث":"Rechercher","الألعاب":"Jeux","اللعبة":"Jeu","نشر اللعبة":"Publier le jeu","تنزيل اللعبة":"Télécharger le jeu","تشغيل اللعبة":"Lancer le jeu","تطوير اللعبة":"Développer le jeu","مواصفات اللعبة":"Caractéristiques du jeu","التعليقات":"Commentaires","نشر التعليق":"Publier le commentaire","اكتب تعليقك...":"Écrivez votre commentaire...","اسمك (اختياري)":"Votre nom (facultatif)","اسم اللعبة":"Nom du jeu","اكتب اسم اللعبة":"Saisissez le nom du jeu","قيّم اللعبة":"Notez le jeu","خيارات الألعاب":"Options des jeux","نتائج البحث":"Résultats de recherche","تحميل":"Télécharger","تنزيل ملف اللعبة":"Télécharger le fichier du jeu","فتح اللعبة في نافذة جديدة":"Ouvrir le jeu dans une nouvelle fenêtre","الانتقال إلى الموقع":"Aller au site","حذف المشروع":"Supprimer le projet","نشر المشروع":"Publier le projet","عنوان المشروع":"Titre du projet","تقييم المشروع":"Note du projet","مشروع":"Projet","إزالة":"Retirer","أضف فيديو":"Ajouter une vidéo","فيديو":"Vidéo","تغيير الصورة":"Changer l'image","معاينة البطاقة":"Aperçu de la carte","سيظهر وصف اللعبة هنا.":"La description du jeu apparaîtra ici.","جاري تحميل المعاينة…":"Chargement de l'aperçu…","جاري تجهيز المعاينة...":"Préparation de l'aperçu...","لا يوجد تقييم بعد":"Aucune note pour l'instant","اضغط لعرض كل التعليقات":"Cliquez pour voir tous les commentaires","📷 إرفاق صورة للعبة":"📷 Joindre une image du jeu","لم نعثر على لعبة بهذا الاسم. يمكنك نشر لعبة جديدة من استوديو جيم.":"Aucun jeu trouvé avec ce nom. Vous pouvez publier un nouveau jeu depuis Studio de jeux.","ملف اللعبة أو التطبيق":"Fichier du jeu ou de l'application","رابط اللعبة (اختياري)":"Lien du jeu (facultatif)","صورة اللعبة (غلاف)":"Image du jeu (couverture)","أضف صورة للعبة":"Ajouter une image du jeu","ابحث عن أي نموذج أو مشروع...":"Rechercher un modèle ou un projet...","ابحث عن نموذج ثلاثي الأبعاد":"Rechercher un modèle 3D","البحث في الموقع":"Rechercher sur le site","مرحبًا بك!":"Bienvenue !","هل أنت مستخدم جديد؟":"Êtes-vous un nouvel utilisateur ?","نعم، أنا جديد":"Oui, je suis nouveau","لا، أريد المتابعة":"Non, je veux continuer","نعم، أريد النشر":"Oui, je veux publier","لا، سأستكشف أولًا":"Non, j'explore d'abord","انشر ما تصنعه":"Publiez ce que vous créez","الإضاءة والألوان":"Éclairage et couleurs","✕ إغلاق":"✕ Fermer","⛶ ملء الشاشة":"⛶ Plein écran","↺ إعادة ضبط":"↺ Réinitialiser","الحساب":"Compte","اسم الحساب":"Nom du compte","اختيار صورة":"Choisir une photo","حفظ":"Enregistrer","مشروع 3D":"Projet 3D","تسجيل خروج":"Se déconnecter","أعمالي في استوديو جيم":"Mes œuvres dans Studio de jeux","مشاريعي ثلاثية الأبعاد":"Mes projets 3D","لا يوجد حاليا":"Rien pour le moment","حذف":"Supprimer","تطوير / إضافة":"Développer / Ajouter","حسابي":"Mon compte"});Object.assign(zh,{"استوديو جيم":"游戏工作室","بحث":"搜索","الألعاب":"游戏","اللعبة":"游戏","نشر اللعبة":"发布游戏","تنزيل اللعبة":"下载游戏","تشغيل اللعبة":"运行游戏","تطوير اللعبة":"开发游戏","مواصفات اللعبة":"游戏规格","التعليقات":"评论","نشر التعليق":"发布评论","اكتب تعليقك...":"写下你的评论...","اسمك (اختياري)":"你的名字（可选）","اسم اللعبة":"游戏名称","اكتب اسم اللعبة":"输入游戏名称","قيّم اللعبة":"为游戏评分","خيارات الألعاب":"游戏选项","نتائج البحث":"搜索结果","تحميل":"下载","تنزيل ملف اللعبة":"下载游戏文件","فتح اللعبة في نافذة جديدة":"在新窗口打开游戏","الانتقال إلى الموقع":"前往网站","حذف المشروع":"删除项目","نشر المشروع":"发布项目","عنوان المشروع":"项目标题","تقييم المشروع":"项目评分","مشروع":"项目","إزالة":"移除","أضف فيديو":"添加视频","فيديو":"视频","تغيير الصورة":"更换图片","معاينة البطاقة":"卡片预览","سيظهر وصف اللعبة هنا.":"游戏描述将显示在这里。","جاري تحميل المعاينة…":"正在加载预览…","جاري تجهيز المعاينة...":"正在准备预览...","لا يوجد تقييم بعد":"暂无评分","اضغط لعرض كل التعليقات":"点击查看所有评论","📷 إرفاق صورة للعبة":"📷 附加游戏图片","لم نعثر على لعبة بهذا الاسم. يمكنك نشر لعبة جديدة من استوديو جيم.":"未找到该名称的游戏。你可以在游戏工作室发布新游戏。","ملف اللعبة أو التطبيق":"游戏或应用文件","رابط اللعبة (اختياري)":"游戏链接（可选）","صورة اللعبة (غلاف)":"游戏图片（封面）","أضف صورة للعبة":"添加游戏图片","ابحث عن أي نموذج أو مشروع...":"搜索任何模型或项目...","ابحث عن نموذج ثلاثي الأبعاد":"搜索 3D 模型","البحث في الموقع":"站内搜索","مرحبًا بك!":"欢迎！","هل أنت مستخدم جديد؟":"你是新用户吗？","نعم، أنا جديد":"是的，我是新用户","لا، أريد المتابعة":"不，我想继续","نعم، أريد النشر":"是的，我想发布","لا، سأستكشف أولًا":"不，我先看看","انشر ما تصنعه":"发布你的作品","الإضاءة والألوان":"灯光与颜色","✕ إغلاق":"✕ 关闭","⛶ ملء الشاشة":"⛶ 全屏","↺ إعادة ضبط":"↺ 重置","الحساب":"账户","اسم الحساب":"账户名称","اختيار صورة":"选择照片","حفظ":"保存","مشروع 3D":"3D 项目","تسجيل خروج":"退出登录","أعمالي في استوديو جيم":"我在游戏工作室的作品","مشاريعي ثلاثية الأبعاد":"我的 3D 项目","لا يوجد حاليا":"暂无","حذف":"删除","تطوير / إضافة":"开发 / 添加","حسابي":"我的账户"});Object.assign(ur,{"استوديو جيم":"گیم اسٹوڈیو","بحث":"تلاش","الألعاب":"گیمز","اللعبة":"گیم","نشر اللعبة":"گیم شائع کریں","تنزيل اللعبة":"گیم ڈاؤن لوڈ کریں","تشغيل اللعبة":"گیم چلائیں","تطوير اللعبة":"گیم ڈیولپ کریں","مواصفات اللعبة":"گیم کی تفصیلات","التعليقات":"تبصرے","نشر التعليق":"تبصرہ شائع کریں","اكتب تعليقك...":"اپنا تبصرہ لکھیں...","اسمك (اختياري)":"آپ کا نام (اختیاری)","اسم اللعبة":"گیم کا نام","اكتب اسم اللعبة":"گیم کا نام لکھیں","قيّم اللعبة":"گیم کی ریٹنگ دیں","خيارات الألعاب":"گیم کے اختیارات","نتائج البحث":"تلاش کے نتائج","تحميل":"ڈاؤن لوڈ","تنزيل ملف اللعبة":"گیم فائل ڈاؤن لوڈ کریں","فتح اللعبة في نافذة جديدة":"گیم نئی ونڈو میں کھولیں","الانتقال إلى الموقع":"سائٹ پر جائیں","حذف المشروع":"پروجیکٹ حذف کریں","نشر المشروع":"پروجیکٹ شائع کریں","عنوان المشروع":"پروجیکٹ کا عنوان","تقييم المشروع":"پروجیکٹ ریٹنگ","مشروع":"پروجیکٹ","إزالة":"ہٹائیں","أضف فيديو":"ویڈیو شامل کریں","فيديو":"ویڈیو","تغيير الصورة":"تصویر تبدیل کریں","معاينة البطاقة":"کارڈ کا پیش منظر","سيظهر وصف اللعبة هنا.":"گیم کی تفصیل یہاں ظاہر ہوگی۔","جاري تحميل المعاينة…":"پیش منظر لوڈ ہو رہا ہے…","جاري تجهيز المعاينة...":"پیش منظر تیار ہو رہا ہے...","لا يوجد تقييم بعد":"ابھی کوئی ریٹنگ نہیں","اضغط لعرض كل التعليقات":"تمام تبصرے دیکھنے کے لیے کلک کریں","📷 إرفاق صورة للعبة":"📷 گیم کی تصویر منسلک کریں","لم نعثر على لعبة بهذا الاسم. يمكنك نشر لعبة جديدة من استوديو جيم.":"اس نام کا کوئی گیم نہیں ملا۔ آپ گیم اسٹوڈیو سے نیا گیم شائع کر سکتے ہیں۔","ملف اللعبة أو التطبيق":"گیم یا ایپ فائل","رابط اللعبة (اختياري)":"گیم لنک (اختیاری)","صورة اللعبة (غلاف)":"گیم کی تصویر (کور)","أضف صورة للعبة":"گیم کی تصویر شامل کریں","ابحث عن أي نموذج أو مشروع...":"کوئی بھی ماڈل یا پروجیکٹ تلاش کریں...","ابحث عن نموذج ثلاثي الأبعاد":"3D ماڈل تلاش کریں","البحث في الموقع":"سائٹ میں تلاش کریں","مرحبًا بك!":"خوش آمدید!","هل أنت مستخدم جديد؟":"کیا آپ نئے صارف ہیں؟","نعم، أنا جديد":"جی ہاں، میں نیا ہوں","لا، أريد المتابعة":"نہیں، میں جاری رکھنا چاہتا ہوں","نعم، أريد النشر":"جی ہاں، میں شائع کرنا چاہتا ہوں","لا، سأستكشف أولًا":"نہیں، پہلے دیکھوں گا","انشر ما تصنعه":"اپنی تخلیقات شائع کریں","الإضاءة والألوان":"روشنی اور رنگ","✕ إغلاق":"✕ بند کریں","⛶ ملء الشاشة":"⛶ فل اسکرین","↺ إعادة ضبط":"↺ ری سیٹ","الحساب":"اکاؤنٹ","اسم الحساب":"اکاؤنٹ کا نام","اختيار صورة":"تصویر منتخب کریں","حفظ":"محفوظ کریں","مشروع 3D":"3D پروجیکٹ","تسجيل خروج":"لاگ آؤٹ","أعمالي في استوديو جيم":"گیم اسٹوڈیو میں میرے کام","مشاريعي ثلاثية الأبعاد":"میرے 3D پروجیکٹس","لا يوجد حاليا":"فی الحال کچھ نہیں","حذف":"حذف کریں","تطوير / إضافة":"ڈیولپ / شامل کریں","حسابي":"میرا اکاؤنٹ"});
  Object.assign(X, A); Object.assign(Z, zh); Object.assign(U, ur); Object.assign(F, fr);
  const T = {ar:A,en:A,zh:zh,ur:ur,fr:fr};
  // English uses A; Arabic uses identity.
  const identity = {}; Object.keys(A).forEach(k => identity[k] = k); T.ar = identity;

  const reverse = Object.create(null);
  for (const lang of Object.keys(T)) {
    for (const [key,val] of Object.entries(T[lang])) {
      if (val && !reverse[norm(val)]) reverse[norm(val)] = key;
    }
  }

  let lang = localStorage.getItem('toryak-language') || 'ar';
  if (!T[lang]) lang = 'ar';
  let translatingNow = false;
  let translationTimer = null;
  const nodeKeys = new WeakMap();
  const attrKeys = new WeakMap();

  function norm(s){ return String(s ?? '').replace(/\s+/g,' ').trim(); }
  function canonical(text){ const n=norm(text); return n && (Object.prototype.hasOwnProperty.call(A,n) ? n : reverse[n]) || null; }
  function shouldSkipText(node){
    const p=node && node.parentElement;
    if(!p) return true;
    if(p.closest('script,style,noscript,template,canvas,input,textarea,select,option,[data-no-translate]')) return true;
    return false;
  }
  function translateNode(node,target){
    if(!node || node.nodeType!==3 || shouldSkipText(node)) return;
    let key=nodeKeys.get(node);
    if(!key){ key=canonical(node.nodeValue); if(!key) return; nodeKeys.set(node,key); }
    const table=T[target] || T.ar;
    const value=table[key] ?? key;
    const raw=node.nodeValue || '';
    const leading=raw.match(/^\s*/)?.[0] || '';
    const trailing=raw.match(/\s*$/)?.[0] || '';
    const next=leading + value + trailing;
    if(raw!==next) node.nodeValue=next;
  }
  function translateAttr(el,attr,target){
    if(!el || !el.hasAttribute(attr)) return;
    let store=attrKeys.get(el); if(!store){store={};attrKeys.set(el,store);}
    if(!store[attr]){ const key=canonical(el.getAttribute(attr)); if(!key) return; store[attr]=key; }
    const key=store[attr]; const table=T[target] || T.ar; const value=table[key] ?? key;
    el.setAttribute(attr,value);
  }
  function walk(root,target){
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{
      acceptNode(node){ return shouldSkipText(node) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; }
    });
    const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
    for(const n of nodes) translateNode(n,target);
  }
  function translateTree(target){
    if(translatingNow || !T[target]) return;
    translatingNow=true;
    observer?.disconnect();
    try{
      walk(document.body,target);
      document.querySelectorAll('input,textarea,[title],[aria-label]').forEach(el=>{
        translateAttr(el,'placeholder',target); translateAttr(el,'title',target); translateAttr(el,'aria-label',target);
      });
      // Search keywords stay bilingual regardless of UI language.
      const pistol=document.querySelector('.pistol-card');
      if(pistol) pistol.dataset.model='service pistol pistol مسدس مسدس خدمة';
      const lighter=document.getElementById('lighterCard');
      if(lighter) lighter.dataset.model='lighter vintage lighter ولاعة ولاعة كلاسيكية';
      const circuit=document.getElementById('circuitCard');
      if(circuit) circuit.dataset.model='circuit board pcb electronic circuit board لوحة دوائر لوحة دوائر إلكترونية دائرة إلكترونية';
      const jerry=document.getElementById('jerrycanCard');
      if(jerry) jerry.dataset.model='jerrycan metal jerrycan canister container جالون جالون معدني عبوة معدنية';
      const rtl=(target==='ar'||target==='ur');
      document.documentElement.lang=target==='ar'?'ar':target;
      document.documentElement.dir=rtl?'rtl':'ltr';
      document.documentElement.classList.toggle('lang-en',target==='en');
      document.body.dir=rtl?'rtl':'ltr';
      document.body.classList.toggle('lang-en',target==='en');
      document.body.classList.toggle('lang-zh',target==='zh');
      document.body.classList.toggle('lang-ur',target==='ur');
      document.body.classList.toggle('lang-fr',target==='fr');
      document.body.classList.toggle('lang-rtl',rtl);
      document.body.classList.toggle('lang-ltr',!rtl);
      localStorage.setItem('toryak-language',target);
      lang=target;
    } finally {
      translatingNow=false;
      observer?.observe(document.body,{subtree:true,childList:true,characterData:true});
    }
  }
  function translateAdded(root){
    if(!root || root.nodeType!==1) return;
    walk(root,lang);
    if(root.matches?.('input,textarea,[title],[aria-label]')){
      translateAttr(root,'placeholder',lang); translateAttr(root,'title',lang); translateAttr(root,'aria-label',lang);
    }
    root.querySelectorAll?.('input,textarea,[title],[aria-label]').forEach(el=>{
      translateAttr(el,'placeholder',lang); translateAttr(el,'title',lang); translateAttr(el,'aria-label',lang);
    });
  }

  window.setSiteLanguage=function(target){
    if(!T[target]) return;
    translateTree(target);
    try{window.__tgRenderStats&&window.__tgRenderStats();}catch(_){}
  };

  const observer=new MutationObserver(muts=>{
    if(translatingNow) return;
    clearTimeout(translationTimer);
    translationTimer=setTimeout(()=>{
      for(const m of muts){
        if(m.type==='characterData') translateNode(m.target,lang);
        else if(m.type==='childList') m.addedNodes.forEach(n=>{
          if(n.nodeType===3) translateNode(n,lang);
          else if(n.nodeType===1) translateAdded(n);
        });
      }
    },120);
  });
  observer.observe(document.body,{subtree:true,childList:true,characterData:true});

  function init(){ translateTree(lang); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();
